var refreshTimeObejct;
function refreshTimeFunction(){
	refreshTimeObejct=setTimeout(function(){refreshTimeFunction()},15*1000);
    if(lockScreenFlag==false){
        Ext.Ajax.request({
            url:'monitor/query/getDataChange',
//		headers:{'Authorization':sessionStorage.omcToken},
            success:function(response, option){
                var json = Ext.JSON.decode(response.responseText);
                if(json.success){
                    var result=json.root
                    for(var i=0;i<result.length;i++){
                        var json=result[i];
                        refreshPanelFunction(json);
                    }
                }else{
                    alert(json.msg);
                    goToLogin();
//            	Ext.MessageBox.confirm("警告",json.msg,function(btn1){
//    				if(btn1=='yes'){
//    					goToLogin();
//    			}});
                }
            },
            // failure:function(response,option){
            //         goToLogin();
            // }
        })
    };
}

//websocket相关
var ws = null;
function openWebsocket(){
	if ('WebSocket' in window) {
		ws=new WebSocket('ws://'+window.url2+'/websocket');
		ws.onopen=function(){
	        //ws.send("sdf");
	    };
	    ws.onmessage=function(event){
	    	// if(event && event.data){
	    	var	json=JSON.parse(event.data);
	    	// }
	    	refreshPanelFunction(json);
	    };
	    ws.onclose=function(event){
	//        alert('Info: connection closed.');
	    	console.log('Info: connection closed.');
	//    	goToLogin();
	    };
	  }else{
	  	alert('当前浏览器 Not support websocket')
	  }
}
//处理方法
function addDeviceMonitor(deviceId){
//	if(ws)ws.send("addDeviceId:"+panel.device.get('id'));
	Ext.Ajax.request({  
		url:'monitor/query/addDeviceMonitor',
//		headers:{'Authorization':sessionStorage.omcToken},
		params:{deviceId:deviceId},
	});
}
function removeDeviceMonitor(deviceId){
//	if(ws)ws.send("delDeviceId:"+json.deviceId);
	Ext.Ajax.request({  
		url:'monitor/query/removeDeviceMonitor',
//		headers:{'Authorization':sessionStorage.omcToken},
		params:{deviceId:deviceId},
	});
}
function refreshPanelFunction(json){
	// if(json.msgType==0){//首页界面刷新
		
	// }else if(json.msgType==1){//监控界面刷新
	// 	var deviceIds=json.deviceIds;
	// 	for(var index=0;index<deviceIds.length;index++){
	// 		var temp=Ext.getCmp('tab_monitor_'+deviceIds[index]);
	// 		if(temp!=null){
	// 			temp.getParamsStore.load(function(records){
 //                    deviceParamReloadData(temp,records);
	// 				// if(records!=null){
	// 				// 	var rs=[];
 //                     //    temp.timeslotHis=[];
	// 				// 	for(var i=0;i<records.length;i++){
 //                     //        if (records[i].get('groupName')=='hideinfo' && records[i].get('name').indexOf('时隙占用率历史')!=-1)
 //                     //            temp.timeslotHis.push(records[i]);
	// 				// 		if(records[i].get('groupName')==temp.typeCombo.getValue())
	// 				// 			rs.push(records[i]);
	// 				// 	}
	// 				// 	temp.store.loadData(rs);
	// 				// 	temp.down('grid').getSelectionModel().deselectAll();
	// 				// }
	// 			});
	// 		}else{
	// 			removeDeviceMonitor(deviceIds[index]);
	// 		}
	// 	}
	// }else if(json.msgType==2){//轮询任务界面刷新
	// 	var temp=Ext.getCmp('pollingResult_GridBar');
	// 	if(temp!=null){
	// 		temp.doRefresh();
	// 	}
	// }else if(json.msgType==3){//最新告警刷新
 //        playSound();
	// 	Ext.getStore('main.CurAlarmStore').loadData([{
	// 		name:'设备ID',value:json.device.id
	// 	},{
	// 		name:'设备名称',value:json.device.name
	// 	},{
	// 		name:'告警名称',value:json.root.name
	// 	},{
	// 		name:'告警类型',value:json.root.alarmType
	// 	},{
	// 		name:'告警级别',value:json.root.grade
	// 	},{
	// 		name:'告警时间',value:json.root.updateTimeString
	// 	}]);
	// }else if(json.msgType==4){
	// 	Ext.getStore('main.WorkStatusStore').loadData([{
	// 		name:"在线",count:json.workNormalCount
	// 	},{
	// 		name:"离线",count:json.workUnknowCount
	// 	}]);
	// 	Ext.getStore('main.MonitorStatusStore').loadData([{
	// 		name:"正常",count:json.monitorNormalCount
	// 	},{
	// 		name:"一级告警",count:json.monitorAlarm1Count
	// 	},{
	// 		name:"二级告警",count:json.monitorAlarm2Count
	// 	},{
	// 		name:"三级告警",count:json.monitorAlarm3Count
	// 	},{
	// 		name:"四级告警",count:json.monitorAlarm4Count
	// 	}]);
	// }else if(json.msgType==5){
 //        var temp=Ext.getCmp('map_mapContiner');
 //        if(temp!=null){
 //            Ext.getStore('node.GetAreaTreeStore').load();
 //            alert("配置数据已变更，请注意刷新!")
 //        }
 //    }
 	if(json.msgType==1){
 		var temp=Ext.getCmp('plan_OutWeekPlanListGridBar');
 		if(temp!=null){
			if(json.msg=='1'){
				Ext.getCmp('plan_OutWeekPlanListGridBar').doRefresh();
				Ext.Msg.alert('提示', '【周计划】上传文件处理完成，数据已刷新！');
			}else{
				Ext.Msg.alert('警告', '【周计划】上传文件失败！'+json.msg);
			}
 		}
 	}
}