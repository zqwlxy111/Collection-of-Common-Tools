Ext.require([
    '*'
]);

Ext.onReady(function() {
	// sessionStorage清空
	sessionStorage.clear();

	var username=getUrlParam('username');
	var password=getUrlParam('password');
	if(username!=null&&password!=null){
		Ext.Ajax.request({  
			url:window.url+'/safe/user/login',
			params:{
				username:username,
				password:password
			},
			success:function(response,option){
				var result=Ext.JSON.decode(response.responseText);
				if(result.success){
                    sessionStorage.omcFunctions=result.functions;
                    sessionStorage.omcIsAdmin=result.admin;
                    sessionStorage.omcToken=result.token;
                    sessionStorage.omcLoginName=username;
					window.location.href="main.html";
				}else {
					alert(result.msg);
                }
			}
		});
	}else{
		var bodyWidth = document.documentElement.clientWidth;
		var bodyHeight = document.documentElement.clientHeight;
		var vp=Ext.create('Ext.container.Viewport',{
			renderTo:'loginBody',
			id:'loginPanel',
			bodyPadding:7,
			title:'Basic Panel',
			collapsible:true,
			width:'100%',
			height:'100%',
			layout:'absolute',
			items:[{
				xtype:'imagecomponent',
				width:'100%',
				height:'100%',
				margins:'0 0',
				src:'res/icons/login/login_bg.jpg'
			},{
				xtype:'form',
				id:'loginform',
				border:false,
				x:(bodyWidth-300)/2,
				y:(bodyHeight-200)/2,
				width:300,
				bodyCls:'panelBodyCls1',
				defaults:{
					margin:"20,5,20,5"
				},
				items:[{
					xtype:'hidden',
					name:'loginType',
					value:0
				},{
					xtype:'panel',
					border:false,
					width:'100%',
					layout:'hbox',
					bodyCls:'panelBodyCls3',
					items:[{
						xtype:'imagecomponent',
						width:39,
						src:'res/icons/login/login_username.png'
					},{
						id:'loginNameId',
						xtype:'textfield',
						name:"username",
						flex:1,
						height:38,
						allowBlank:false,
						emptyText:'帐号',
						emptyCls:'textfield-emptyCls',
						enforceMaxLength:20,
						maxLength:20,
						blankText:'请输入用户名'
					}]
				},{
					xtype:'panel',
					border:false,
					width:'100%',
					layout:'hbox',
					bodyCls:'panelBodyCls3',
					items:[{
						xtype:'imagecomponent',
						width:39,
						src:'res/icons/login/login_password.png'
					},{
						xtype:'textfield',
						name:"password",
						inputType:"password",
						flex:1,
						height:38,
						allowBlank:false,
						emptyText:'密码',
						enforceMaxLength:20,
						maxLength:20,
						blankText:'请输入密码'
					}]
				},{
					xtype:'toolbar',
					border:false,
					width:'100%',
					baseCls:'panelBodyColorCls4',
					items:["->",{
						xtype:'button',
//					style:{background:'#f7b756'},
						html:'<input type="button" value="登 录" class="buttonWHCls1 buttonColorCls1 buttonCls1"/>',
						width:120,
						height:42,
						padding:'0',
						margins:'0',
						border:false,
						handler:onLogin
// 					},{
// 						xtype:'button',
// //					style:{background:'#f7b756'},
// 						html:'<input type="button" value="忘记密码" class="buttonWHCls1 buttonColorCls1 buttonCls1"/>',
// 						width:120,
// 						height:42,
// 						padding:'0',
// 						margins:'0',
// 						border:false,
// 						handler:goToRegister
					},
					"->"]
				}]
			}]
		});
		window.onresize = bodyLoad;
		document.onkeydown=function(event){
			var e=event||window.event||arguments.callee.caller.arguments[0];
			if(e && e.keyCode==13){// enter 键
				onLogin();
			}
		}; 
	}
});
function bodyLoad(){
	var lf=Ext.getCmp('loginform');
	var bodyWidth = document.documentElement.clientWidth;
	var bodyHeight = document.documentElement.clientHeight;
	lf.setX((bodyWidth-300)/2);
	lf.setY((bodyHeight-200)/2);
}
function getUrlParam(name){
	var reg=new RegExp('(^|&)'+name+'=([^&]*)(&|$)');
    var r=window.location.search.substr(1).match(reg);
    if (r!=null) return unescape(r[2]); return null;
}
function goToRegister(){
	
}
function onLogin(){
	var f=Ext.getCmp('loginform');
	if(f && f.isValid()){
		f.submit({
			waitMsg :'正在登录...',
			url:window.url+'/safe/user/login',
			success:function(form, action){
				Ext.getCmp('loginPanel').setDisabled(true);
				sessionStorage.omcFunctions=action.result.functions;
				sessionStorage.omcIsAdmin=action.result.isAdmin;
				sessionStorage.omcToken=action.result.token;
                sessionStorage.omcLoginName=Ext.getCmp('loginNameId').getValue();
                sessionStorage.omcChangePwd=action.result.changePwd+"";
				window.location.href="main.html";
			},
			failure:function(form, action){
				if(action.failreType === "connect"){
					Ext.Msg.alert('错误1', '状态:'+action.response.status+':'+
					action.response.statusText, Ext.Msg.ERROR);
					return;
				}
				if(action.result){
					if(action.result.msg){
						Ext.Msg.alert('温馨提示',action.result.msg);
					}
				}
			}
		});
	}
}