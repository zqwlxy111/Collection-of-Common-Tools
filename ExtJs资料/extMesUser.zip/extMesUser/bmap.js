var map;
var bdary;
var map_btses=[];
var map_sites=[];
var map_devices=[];
var map_polylines=[];
function setMap(){
	try{if(BMap==null){
		return;
	}}catch(error){
		console.log("百度地图加载失败:"+error);
		return;
	}
	map=new BMap.Map("map_mapContiner");
	bdary=new BMap.Boundary();
	map.centerAndZoom("深圳", 13);
	map.enableScrollWheelZoom();// 启用地图滚轮放大缩小
//	zoomProvinceFun();
}
function map_addMark(point,i,node){
	var ic = "res/icons/building-"+i+".gif";
	var myIcon=new BMap.Icon(ic, new BMap.Size(40, 40));
	var marker=new BMap.Marker(point,{icon: myIcon});// 创建标注
	var label;
	var size=new BMap.Size(0,-20);
	if(i==1){
		map_sites.push(marker);
		label=new BMap.Label('站点:'+node.get('name'),{offset:size});
	}else if(i==2){
		map_btses.push(marker);
		label=new BMap.Label('基站:'+node.get('name'),{offset:size});
	}else if(i==3){
		map_devices.push(marker);
		label=new BMap.Label('设备:'+node.get('name'),{offset:size});
		var monitorStatus=node.get('monitorStatus');
		if(monitorStatus==0){
			label.setStyle({color:"#0ee40b"});
		}else if(monitorStatus==1){
			label.setStyle({color:"#ff0000"});
		}else if(monitorStatus==2){
			label.setStyle({color:"#ff00ff"});
		}else if(monitorStatus==3){
			label.setStyle({color:"#e97a21"});
		}else if(monitorStatus==4){
			label.setStyle({color:"#e6e614"});
		}
	}
	marker.nodeData=node;
	map.addOverlay(marker);// 将标注添加到地图中
	marker.setLabel(label);
	var markerMenu=new BMap.ContextMenu();
	markerMenu.addItem(new BMap.MenuItem('维护',function(){
		if(i==1){
			Ext.widget('updatesitewin',{
    			dataRecord:node
    		});
		}else if(i==2){
			Ext.widget('updatebtswin',{
    			dataRecord:node
    		});
		}else if(i==3){
			Ext.widget('updatedevicewin',{
    			dataRecord:node
    		});
		}
	}));
	if(i==3){
		markerMenu.addItem(new BMap.MenuItem('监控',function(){
			var tabId="tab_monitorPanel";
			addTab(Ext.getCmp('mainTab'),tabId,
					{id:tabId,title:'设备监控',xtype:'monitorpanel',closable:true});
			
			var monitorId='tab_monitor_'+node.get('id');
			addTab(Ext.getCmp('monitor_tabPanel'),monitorId,{
				id:monitorId,
				title:node.get('name'),
				xtype:'deviceparampanel',
				device:node,
				closable:true
			});
		}));
		marker.addContextMenu(markerMenu);
		marker.addEventListener("click",function(){
			var getParamsStore=Ext.create('Mvc.store.monitor.GetParamsStore');
			getParamsStore.proxy.extraParams={'deviceId':node.get('id')};
			getParamsStore.load(function(records){
				if(records!=null){
					var rs1=[];
					var rs2=[];
					for(var i=0;i<records.length;i++){
						if(records[i].get('groupName')=='告警和状态'&&records[i].get('displayValue')=="告警")
							rs1.push(records[i]);
						
						if(records[i].get('groupName')=='实时采样数据')
							rs2.push(records[i]);
					}
					Ext.getCmp('map_alarmParamList').store.loadData(rs1);
					Ext.getCmp('map_dataParamList').store.loadData(rs2);
				}
			});
		});
	}
	marker.addContextMenu(markerMenu);
}
function selectAreaInMap(area){
    if(map!=null){
        if(area.get('depth')==2){
            map.centerAndZoom(area.get('text'),13);
        }else if(area.get('depth')==3){
            map.centerAndZoom(area.get('text'),14);
        }
    }
}