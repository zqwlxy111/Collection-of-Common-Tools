// window.url="http://172.20.248.220:8088/dms/safe_usercenter";
window.url="http://172.20.73.16:8899/safe_usercenter";
// window.url1="http://172.20.248.220:8088/dms/mes";
window.url1="http://172.20.73.13:8080/mes";
// window.url1="http://172.20.73.16:8080/mes";
// window.url="http://172.20.73.13:8763";
// window.url2='172.20.248.220:8088/dms/mes';
window.url2='172.20.73.13:8080/mes';
// window.url2='172.20.73.16:8080/mes';

//六日计划的接口地址：
window.url3='http://172.20.73.16:8080/mes';
// window.url3='http://172.20.248.220:8080/mes';
// window.url3="http://172.20.248.220:8088/dms/mes";
//邱晓峰本地公共地址：
window.url4='http://172.20.73.16:8080/safe_usercenter';
// window.url4="http://172.20.248.220:8088/dms/safe_usercenter";
// window.url4='http://172.20.248.220:8080/safe_server';
function addTab(cmp,tabId,temp){
	var tab=cmp.getComponent(tabId);
    if(!tab)
    {
        tab=cmp.add(temp);
    }
    cmp.setActiveTab(tab);
    // cmp.on('tabchange',function(tabpanel,ntab,otab){
    //     console.log(ntab.xtype,'pp');
    //     // Ext.getCmp('west-region-container').down('treepanel').
    // })
}
function goToLogin(){
	window.location.href="login.html";
}
function checkSession(){
//	Ext.Ajax.request({  
//		url:'safe/user/checkSession',
//		success:function(response ,option){
//			var data=Ext.JSON.decode(response.responseText);
//			if(data.success){
//				createLeftMenu(data.functions,data.admin);
//				refreshTimeFunction();
//			}else{
//                if(lockScreenFlag==false) {
//                	goToLogin();
//                }
//			}
//		},
//		failure:function(response,option){
//            if(lockScreenFlag==false){
//            	goToLogin();
//            }
//		}
//	});
}
function createLeftMenu(functions,isAdmin){
	var fm1=Ext.getCmp('functionMenu1');
	// var fm2=Ext.getCmp('functionMenu2');
	var fm3=Ext.getCmp('functionMenu3');
//	lm.removeAll();
	// if((functions==null || functions.length<1) && !isAdmin)
	// 	return;
	// if(isAdmin || functions.hasOwnProperty("1"))
	// 	fm1.add({text:'设备列表',action:"openDeviceListPanel",iconAlign:'left'});//,iconCls:'system'
    
    // if(isAdmin || functions.indexOf("\"2\":")!=-1)
        // fm1.add({text:'外销周计划',action:"openOutWeekPlanPanel",iconAlign:'left'});
    // fm1.add('-');
    // if(isAdmin || functions.indexOf("\"3\":")!=-1)
        // fm1.add({text:'六日计划',action:"openMonitorPanel",iconAlign:'left'});   
	// if(isAdmin || functions.indexOf("\"2\":")!=-1)
	// 	fm1.add({text:'节点维护',action:"openNodePanel",iconAlign:'left'});
	// fm1.add('-');
	// if(isAdmin || functions.indexOf("\"3\":")!=-1)
	// 	fm1.add({text:'设备监控',action:"openMonitorPanel",iconAlign:'left'});
	// if(isAdmin || functions.indexOf("\"4\":")!=-1)
	// 	fm1.add({text:'轮询处理',action:"openPollingPanel",iconAlign:'left'});
	// fm1.add('-');
	// if(isAdmin || functions.indexOf("\"5\":")!=-1)
	// 	fm1.add({text:'批采任务',action:"openBatchPlanPanel",iconAlign:'left'});
	// if(isAdmin || functions.indexOf("\"6\":")!=-1)
	// 	fm1.add({text:'远程升级',action:"openUpgradePlanPanel",iconAlign:'left'});
	
	// if(isAdmin || functions.indexOf("\"9\":")!=-1)
	// 	fm2.add({text:'实时告警列表',action:"openCurAlarmPanel",iconAlign:'left'});
 //    if(isAdmin || functions.indexOf("\"8\":")!=-1)
 //        fm2.add({text:'历史告警列表',action:"openHisAlarmPanel",iconAlign:'left'});
	// fm2.add('-');
	// if(isAdmin || functions.indexOf("\"10\":")!=-1)
	// 	fm2.add({text:'告警设置',action:"openAlarmGradePanel",iconAlign:'left'});
	// fm2.add('-');
	// if(isAdmin || functions.indexOf("\"11\":")!=-1)
	// 	fm2.add({text:'数据字典',action:"openItemPanel",iconAlign:'left'});
	// fm2.add('-');
	// if(isAdmin || functions.indexOf("\"12\":")!=-1)
	// 	fm2.add({text:'系统设置',action:"openSystemSettingPanel",iconAlign:'left'});
	// if(isAdmin || functions.indexOf("\"13\":")!=-1)
	// 	fm2.add({text:'数据备份',action:"openBackupPlanPanel",iconAlign:'left'});
	
	// if(isAdmin || functions.indexOf("\"15\":")!=-1)
	// 	fm3.add({text:'版本管理',action:"openVersionPanel",iconAlign:'left'});
	// fm3.add('-');
	// if(isAdmin || functions.indexOf("\"16\":")!=-1)
	// 	fm3.add({text:'用户管理',action:"openUserPanel",iconAlign:'left'});
	// if(isAdmin || functions.indexOf("\"17\":")!=-1)
	// 	fm3.add({text:'用户组管理',action:"openGroupPanel",iconAlign:'left'});
 //    if(isAdmin || functions.indexOf("\"16\":")!=-1)
 //        fm3.add({text:'部门管理',action:"openDepartmentPanel",iconAlign:'left'});
	// if(isAdmin || functions.indexOf("\"18\":")!=-1)
	// 	fm3.add({text:'功能管理',action:"openFunctionPanel",iconAlign:'left'});
	// fm3.add('-');
	// if(isAdmin || functions.indexOf("\"19\":")!=-1)
	// 	fm3.add({text:'安全日志',action:"openSafeLogPanel",iconAlign:'left'});
	// if(isAdmin || functions.indexOf("\"20\":")!=-1)
	// 	fm3.add({text:'操作日志',action:"openOperateLogPanel",iconAlign:'left'});
	// if(isAdmin || functions.indexOf("\"21\":")!=-1)
	// 	fm3.add({text:'上报日志',action:"openReportLogPanel",iconAlign:'left'});
 //    fm3.add('-');
 //    if(isAdmin || functions.indexOf("\"23\":")!=-1)
 //    	fm3.add({text:'性能监控',action:"openPerformancePanel",iconAlign:'left'});
};
//创建地图标注
/*function createMapData(id){
    if(map!=null){
        map.clearOverlays();
        var getSitesStore=Ext.getStore('node.GetSitesStore');
        getSitesStore.proxy.extraParams.areaId=id;
        getSitesStore.load(function(records){
            for(var i=0;i<records.length;i++){
                map_addMark(new BMap.Point(records[i].get('lng'), records[i].get('lat')),1,records[i]);
            }
        });
        var getBtsesStore=Ext.getStore('node.GetBtsesStore');
        getBtsesStore.proxy.extraParams.areaId=id;
        getBtsesStore.load(function(records){
            for(var i=0;i<records.length;i++){
                map_addMark(new BMap.Point(records[i].get('lng'), records[i].get('lat')),2,records[i]);
            }
        });
        var getDevicesStore=Ext.getStore('monitor.GetDeviceExListStore');
        getDevicesStore.proxy.extraParams.areaId=id;
        getDevicesStore.load(function(records){
            for(var i=0;i<records.length;i++){
                map_addMark(new BMap.Point(records[i].get('lng'), records[i].get('lat')),3,records[i]);
            }
        });
    }
}*/
//刷新设备监控界面数据
function deviceParamReloadData(win,records){
    if(records!=null){
        var rs=[];
        win.timeslotHis=[];
        for(var i=0;i<records.length;i++){
            if (records[i].get('groupName')=='hideinfo' && records[i].get('name').indexOf('时隙占用率历史')!=-1)
                win.timeslotHis.push(records[i]);
            if(records[i].get('groupName')==win.typeCombo.getValue())
                rs.push(records[i]);
        }
        win.store.loadData(rs);
    }
}
//时间方法
function getMyDate(d,boo){
	var date = new Date();
	date.setTime(d);
	var yyVal = date.getFullYear();
	var mmVal = getzf(date.getMonth()+1);
	var date_dd = getzf(date.getDate());
    var time_hh = getzf(date.getHours());
    var time_mm = getzf(date.getMinutes());
    var time_sec = getzf(date.getSeconds());
    if(boo){
    	return yyVal+"-"+mmVal+"-"+date_dd;
    }else{
    	return yyVal+"-"+mmVal+"-"+date_dd+" "+time_hh+":"+time_mm+":"+time_sec;
    }
    
};
function getMyTime(d){
    var date = new Date();
    date.setTime(d);
    var time_hh = getzf(date.getHours());
    var time_mm = getzf(date.getMinutes());
    var time_sec = getzf(date.getSeconds());
    return time_hh+":"+time_mm+":"+time_sec;
}
function getzf(num){
    if(parseInt(num) < 10)
    { num = '0'+num;}
    return num;
};
//检查文件是否存在，存在就下载
var fileURL;
function openUrl(){
	$.ajax({
		url:fileURL,
//		url:'http://192.168.5.10:8080/omc/file/export/JSworkerspaces.rar',
		type:'HEAD',
		complete:function(response){
			if(response.status == 200) {
				window.open(fileURL);
			} else {
				setTimeout(openUrl, 5000);
			}
		}
	});
}
//编辑轮询计划时检查选中的设备
function checkStoreForPollingPlan(records){
	var temp=[]
	for(var i=0; i<records.length; i++){
		Ext.getCmp('task_PollingPlan_selectGrid').store.each(function(record){
			if(record.get('id')==records[i].get('id'))
				temp.push(record)
		});
	}
	Ext.getCmp('task_PollingPlan_unSelectGrid').store.remove(temp);
}
//页面渲染方法
function workStatusRender(val){
	if(val==1){
        return '<span style="color:#0ee40b;">在线</span>';
    }else if(val==0) {
        return '<span style="color:#000000;">离线</span>';
    }
    return val;
};
function monitorStatusRender(val){
    if(val==0){
        return '<span style="color:#0ee40b;">正常</span>';
    }else if(val==1) {
        return '<span style="color:#ff0000;">一级告警</span>';
    }else if(val==2) {
        return '<span style="color:#ff00ff;">二级告警</span>';
    }else if(val==3) {
        return '<span style="color:#e97a21;">三级告警</span>';
    }else if(val==4) {
        return '<span style="color:#e6e614;">四级告警</span>';
    }
    return val;
};
function displayParamValueRender(val){
	if(val=='正常'){
        return '<span style="color:#0ee40b;">正常</span>';
    }else if(val=='告警'){
        return '<span style="color:#ea2c2c;">告警</span>';
    }
    return val;
}
function displayAlarmValueRender(val){
	if(val=='正常'){
        return '<span style="color:#0ee40b;">告警恢复</span>';
    }else if(val=='告警'){
        return '<span style="color:#ea2c2c;">告警</span>';
    }
    return val;
}
function displayUserStatusRender(val) {
    if (val == 1) {
        return '<span style="color:#0ee40b;">启用</span>';
    } else if (val == 2) {
        return '<span style="color:#ea2c2c;">禁用</span>';
    }
    return val;
}
function boolLackRender(val){
    if(val==true ||val =="true"){
        return '是';
    }else{
        return '否';
    }
}
function stateRender(val){
    if(val==1){
        return '未完成';
    }else if(val==2){
        return '已完成';
    }else if(val==0){
        return '全部';
    }else if(val==3){
        return '失效';
    }
}
window.AudioContext = window.AudioContext || window.webkitAudioContext;
function playSound(){
    if (!window.AudioContext) {
        alert('当前浏览器不支持Web Audio API');
        return;
    }

    // 按钮元素
    var eleButton = document.getElementById('button');

    // 创建新的音频上下文接口
    var audioCtx = new AudioContext();

    // 发出的声音频率数据，表现为音调的高低
    var arrFrequency = [196.00, 220.00, 246.94, 261.63, 293.66, 329.63, 349.23, 392.00, 440.00, 493.88, 523.25, 587.33, 659.25, 698.46, 783.99, 880.00, 987.77, 1046.50];

    // 音调依次递增或者递减处理需要的参数
    var start = 0, direction = 1;

    // 当前频率
    var frequency = arrFrequency[start];
    // 如果到头，改变音调的变化规则（增减切换）
    if (!frequency) {
        direction = -1 * direction;
        start = start + 2 * direction;
        frequency = arrFrequency[start];
    }
    // 改变索引，下一次hover时候使用
    start = start + direction;

    // 创建一个OscillatorNode, 它表示一个周期性波形（振荡），基本上来说创造了一个音调
    var oscillator = audioCtx.createOscillator();
    // 创建一个GainNode,它可以控制音频的总音量
    var gainNode = audioCtx.createGain();
    // 把音量，音调和终节点进行关联
    oscillator.connect(gainNode);
    // audioCtx.destination返回AudioDestinationNode对象，表示当前audio context中所有节点的最终节点，一般表示音频渲染设备
    gainNode.connect(audioCtx.destination);
    // 指定音调的类型，其他还有sine|square|triangle|sawtooth
    oscillator.type = 'triangle';
    // 设置当前播放声音的频率，也就是最终播放声音的调调
    oscillator.frequency.value = frequency;
    // 当前时间设置音量为0
    gainNode.gain.setValueAtTime(0, audioCtx.currentTime);
    // 0.01秒后音量为1
    gainNode.gain.linearRampToValueAtTime(1, audioCtx.currentTime + 0.01);
    // 音调从当前时间开始播放
    oscillator.start(audioCtx.currentTime);
    // 1秒内声音慢慢降低，是个不错的停止声音的方法
    gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 4);
    // 1秒后完全停止声音
    oscillator.stop(audioCtx.currentTime + 4);
}