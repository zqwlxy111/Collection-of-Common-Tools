Ext.Loader.setConfig({enabled: true,paths:{'Mvc': 'mvc'}});
Ext.require('Mvc.Application');
Ext.onReady(function(){Ext.create("Mvc.Application");});