/**
 * Created by justinguo on 2018/7/30.
 */
var mapUtils;
var map_btses= new HashMap();
var map_sites=new HashMap();
var map_devices=new HashMap();
var map_polylines=new HashMap();

var _interval_id;
_interval_id = window.setInterval("setMap()",100);

function setMap(){
    if(document.getElementById("oMap")) {
        try {
            options.mapElementId = "oMap";
            options.showContextMenu = true;
            mapUtils = new gisApp.MapUtils(this.window, options);
            mapUtils.InitMap(gisApp.MAP_STATE.INIT);
            
            createMapData(1);

        } catch (error) {
            console.log("地图加载失败:" + error);
            return;
        }
        window.clearInterval(_interval_id);
    }
}

function map_addMark(point,i,node){
    var ic = "res/icons/building-"+i+".gif";
    var monitorStatus=node.get('monitorStatus');
    var feature = new ol.Feature();
    var id = node.get("id") + i.toString();
    feature.setGeometry(point);
    feature.set("name",node.get("name"));
    feature.set("type",i);
    feature.set("status",monitorStatus);
    feature.set("uid",node.get("id"));
    feature.setId(id);
    feature.set("parentId",node.get("parentId"));
    feature.set("nodeData",node);

    if(i==1){
        feature.set("btsId", node.get("btsId"));
        if(!map_sites.containsKey(id)) map_sites.put(id,feature);
    }else if(i==2){

        if(!map_btses.containsKey(id)) map_btses.put(id,feature);
    }else if(i==3){
        feature.set("siteId", node.get("siteId"));
        feature.set("btsId", node.get("btsId"));
        if(!map_devices.containsKey(id)) map_devices.put(id,feature);
    }
    mapUtils.source_cars.addFeature(feature);
}

function createMapData(id){
    if(mapUtils){
        //map.clearOverlays();
        mapUtils.source_cars.clear();

        var getSitesStore=Ext.getStore('node.GetSitesStore');
        getSitesStore.proxy.extraParams.areaId=id;
        getSitesStore.load(function(records){
            for(var i=0;i<records.length;i++){
                map_addMark(new ol.geom.Point([records[i].get('lng'),records[i].get('lat')]),1,records[i]);
            }
        });
        var getBtsesStore=Ext.getStore('node.GetBtsesStore');
        getBtsesStore.proxy.extraParams.areaId=id;
        getBtsesStore.load(function(records){
            for(var i=0;i<records.length;i++){
                map_addMark(new ol.geom.Point([records[i].get('lng'),records[i].get('lat')]),2,records[i]);
            }
        });
        var getDevicesStoreForMap=Ext.getStore('monitor.GetDeviceExListForMapStore');
        getDevicesStoreForMap.proxy.extraParams.areaId=id;
        getDevicesStoreForMap.load(function(records){
            for(var i=0;i<records.length;i++){
                map_addMark(new ol.geom.Point([records[i].get('lng'),records[i].get('lat')]),3,records[i]);
            }
        });
    }
}

function showMantainanceDialog(){
    var feature = mapUtils.hoveringFeature;
    if(!feature) return;
    if(feature.get('type')==1){
        Ext.widget('updatesitewin',{
            dataRecord: feature.get("nodeData")
        });
    }else if(feature.get('type')==2){
        Ext.widget('updatebtswin',{
            dataRecord: feature.get("nodeData")
        });
    }else if(feature.get('type')==3){
        Ext.widget('updatedevicewin',{
            dataRecord: feature.get("nodeData")
        });
    }
}

function showMonitorDialog(){
    var feature = mapUtils.hoveringFeature;
    if(!feature) return;
    if(feature.get("type")==3){
        var tabId="tab_monitorPanel";
        addTab(Ext.getCmp('mainTab'),tabId,
            {id:tabId,title:'设备监控',xtype:'monitorpanel',closable:true});

        var monitorId='tab_monitor_'+ feature.get('uid');
        addTab(Ext.getCmp('monitor_tabPanel'),monitorId,{
            id:monitorId,
            title: feature.get('name'),
            xtype:'deviceparampanel',
            device: feature.get("nodeData"),
            closable:true
        });


    }//
}

function selectAreaInMap(area){
    var city = new HashMap();
    city.put("深圳",[114.065537,22.553855]);
    city.put("南山区",[113.930037,22.529889]);
    city.put("广州",[113.271943,23.136371])

    var name = area.get('text');
    if(city.containsKey(name))
        mapUtils.panToPoint(city.get(name));
}