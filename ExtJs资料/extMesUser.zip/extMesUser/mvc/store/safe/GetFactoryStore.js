Ext.define('Mvc.store.safe.GetFactoryStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.safe.DepartmentModel',
	// autoLoad:false,
	pageSize:50,
	proxy:{
		type:'ajax',
		url:window.url+'/safe/department/getFactory',
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'root',
			totalProperty:'totalProperty'
		}
	}
});