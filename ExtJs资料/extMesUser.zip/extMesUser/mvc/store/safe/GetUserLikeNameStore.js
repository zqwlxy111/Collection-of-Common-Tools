Ext.define('Mvc.store.safe.GetUserLikeNameStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.safe.UserModel',
	// autoLoad:true,
	//	pageSize:35,
	proxy:{
		type:'ajax',
		url:window.url+'/safe/user/getUserLikeName',
		extraParams:{'name':''},
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'result',
			totalProperty:'total'
		}
	}
});