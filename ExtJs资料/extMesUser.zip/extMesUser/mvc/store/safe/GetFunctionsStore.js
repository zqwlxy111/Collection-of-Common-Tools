Ext.define('Mvc.store.safe.GetFunctionsStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.safe.FunctionModel',
	autoLoad:true,
//	pageSize:35,
	proxy:{
		type:'ajax',
		url:'safe/function/getFunctions',
		extraParams:{'flag':-1},
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'root',
			totalProperty:'totalProperty'
		}
	}
});