Ext.define('Mvc.store.safe.GetRolesTreeStore',{
	extend:'Ext.data.TreeStore',
	// autoLoad:false,
	proxy:{
		type:'ajax',
		url:window.url+'/safe/function/getFunctionTreeByRoleId',
		headers:{'token':sessionStorage.omcToken},
		actionMethods:{read:'GET'},
		extraParams:{'roleId':0},
		reader:'json',
		extractResponseData:function(response){
			response=Ext.JSON.decode(response.responseText);
			var root={};
			root.children=response;
			return root;
		}
	}
});