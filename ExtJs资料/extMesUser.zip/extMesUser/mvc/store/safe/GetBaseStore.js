 Ext.define('Mvc.store.safe.GetBaseStore',{
	extend:'Ext.data.Store',
	fields:['id','name','code','bak','status'],
	autoLoad:true,
	// pageSize:50,
	proxy:{
		type:'ajax',
		url:window.url+'/base/getBase',
		actionMethods:{read:'GET'},
		reader:{
			type:'json',
			// root:'result',
			root:'root',
			totalProperty:'total'
		}
	}
});