Ext.define('Mvc.store.safe.GetDepartmentTreeStore',{
	extend:'Ext.data.TreeStore',
	// model:'Mvc.model.safe.DepartmentModel',
	// autoLoad:true,
	proxy:{
		type:'ajax',
		url:window.url+'/safe/department/getDepartmentTree',
		headers:{'token':sessionStorage.omcToken},
		actionMethods:{read:'GET'},
		reader:'json',
		extractResponseData:function(response){
			response=Ext.JSON.decode(response.responseText);
			var root={};
			root.children=response;
			return root;
		}
	}
});