 
// var data={
// 	result:{
// 		content:[
// 			{
// 				id:44,
// 				name:"qi12n23wr81eds",
// 				password:null,
// 				tel:"13800138000",
// 				email:null,
// 				realName:"管理员",
// 				status:0,
// 				createTime:1547176216096,
// 				bak:null,
// 				employeeNumber:"sy123",
// 			}
// 		],
// 		totalElements:'1'
// 	}
// }

Ext.define('Mvc.store.safe.GetUsersStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.safe.UserModel',
	// autoLoad:true,
	pageSize:50,
	// data:data,
	proxy:{
		type:'ajax',
		// type:'memory',
		// url:'safe/user/getUsers',
		url:window.url+'/safe/user/getUsersList',
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			// root:'result.content',
			// totalProperty:'result.totalElements'
			root:'result',
			totalProperty:'total'
		}
	}
});