Ext.define('Mvc.store.safe.GetLineStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.safe.DepartmentModel',
	// autoLoad:true,
	pageSize:50,
	proxy:{
		type:'ajax',
		url:window.url+'/safe/department/getLine',
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'root',
			totalProperty:'totalProperty'
		}
	}
});