Ext.define('Mvc.store.safe.GetFunctionsByFlagStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.safe.FunctionModel',
//	autoLoad:true,
//	pageSize:35,
	proxy:{
		type:'ajax',
		url:window.url+'/safe/function/getFunctions',
		extraParams:{'flag':1},
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'root',
			totalProperty:'totalProperty'
		}
	}
});