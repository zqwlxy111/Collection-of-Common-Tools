Ext.define('Mvc.store.safe.GetDepartmentParentStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.safe.DepartmentModel',
	// autoLoad:true,
//	pageSize:35,
	proxy:{
		type:'ajax',
		url:window.url+'/safe/department/getDeparmentsLikeName',
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'result',
			totalProperty:'total'
		}
	}
});