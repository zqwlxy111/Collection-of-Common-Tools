Ext.define('Mvc.store.safe.GetRolesStore',{
	extend:'Ext.data.Store',
	fields:['id','name','bak','status','systemId'],
	// autoLoad:true,
	pageSize:50,
	proxy:{
		type:'ajax',
		url:window.url+'/safe/role/getRoles',
		actionMethods:{read:'GET'},
		reader:{
			type:'json',
			root:'result',
			totalProperty:'total'
		},
	},
});