Ext.define('Mvc.store.safe.GetDictionaryStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.safe.DictionaryModel',
	autoLoad:true,
	pageSize:100,
	proxy:{
		type:'ajax',
		url:window.url+'/dict/getTitles',
		actionMethods:{read:'GET'},
		reader:{
			type:'json',
			root:'result',
			totalProperty:'total',
			idProperty: 'callTime',//id不要重复
		}
	}
});