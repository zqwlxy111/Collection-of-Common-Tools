Ext.define('Mvc.store.node.GetBtsesStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.node.BtsModel',
//	autoLoad:true,
	pageSize:50,
	proxy:{
		type:'ajax',
		extraParams:{'areaId':0},
		url:'node/bts/getBtses',
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'root',
			totalProperty:'totalProperty'
		}
	}
});