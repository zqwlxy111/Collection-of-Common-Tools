Ext.define('Mvc.store.node.GetAreasLikeNameStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.node.AreaModel',
//	autoLoad:true,
//	pageSize:35,
	proxy:{
		type:'ajax',
		url:'node/area/getAreasLikeName',
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'root',
			totalProperty:'totalProperty'
		}
	}
});