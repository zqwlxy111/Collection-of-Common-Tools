Ext.define('Mvc.store.node.GetDevicesLikeNameStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.node.DeviceModel',
//	autoLoad:true,
//	pageSize:35,
	proxy:{
		type:'ajax',
		url:'node/device/getDevicesLikeName',
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'root',
			totalProperty:'totalProperty'
		}
	}
});