Ext.define('Mvc.store.node.GetSitesStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.node.SiteModel',
//	autoLoad:true,
	pageSize:50,
	proxy:{
		type:'ajax',
		extraParams:{'areaId':0},
		url:'node/site/getSites',
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'root',
			totalProperty:'totalProperty'
		}
	}
});