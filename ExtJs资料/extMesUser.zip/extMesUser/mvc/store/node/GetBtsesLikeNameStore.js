Ext.define('Mvc.store.node.GetBtsesLikeNameStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.node.BtsModel',
//	autoLoad:true,
//	pageSize:35,
	proxy:{
		type:'ajax',
		url:'node/bts/getBtsesLikeName',
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'root',
			totalProperty:'totalProperty'
		}
	}
});