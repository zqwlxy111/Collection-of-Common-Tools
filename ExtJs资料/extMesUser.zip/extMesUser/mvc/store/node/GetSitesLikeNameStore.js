Ext.define('Mvc.store.node.GetSitesLikeNameStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.node.SiteModel',
//	autoLoad:true,
//	pageSize:35,
	proxy:{
		type:'ajax',
		url:'node/site/getSitesLikeName',
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'root',
			totalProperty:'totalProperty'
		}
	}
});