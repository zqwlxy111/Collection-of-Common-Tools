Ext.define('Mvc.store.node.GetAreaTreeStore',{
	extend: 'Ext.data.TreeStore',
//	root:{
//		text: '网管中心',
//		expanded: true
//	},
	autoLoad:true,
	proxy:{
		type:'ajax',
		url:'node/area/getAreaTree',
		headers:{'Authorization':sessionStorage.omcToken},
		actionMethods:{read:'POST'},
	}
});