Ext.define('Mvc.store.base.GetSynServiceListStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.base.SynServiceListModel',
	// autoLoad:true,
	pageSize:50,
	proxy:{
		type:'ajax',
		url:'base/synServiceList/getSynServiceList',
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'root',
			totalProperty:'totalProperty'
		}
	}
});