Ext.define('Mvc.store.base.GetItemsStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.base.ItemModel',
//	autoLoad:true,
//	pageSize:35,
	proxy:{
		type:'ajax',
		url:'base/item/getItems',
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'root',
			totalProperty:'totalProperty'
		}
	}
});