Ext.define('Mvc.store.base.GetAlarmReasonsForComboStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.base.AlarmReasonModel',
//	autoLoad:true,
	proxy:{
		type:'ajax',
		url:'base/alarmReason/getAlarmReasons',
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'root',
			totalProperty:'totalProperty'
		}
	}
});