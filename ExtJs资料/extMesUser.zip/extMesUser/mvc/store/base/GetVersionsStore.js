Ext.define('Mvc.store.base.GetVersionsStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.base.VersionModel',
//	autoLoad:true,
	pageSize:50,
	proxy:{
		type:'ajax',
		url:'base/version/getVersions',
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'root',
			totalProperty:'totalProperty'
		}
	}
});