Ext.define('Mvc.store.base.GetControlParameterStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.base.ControlParameterModel',
//	autoLoad:true,
	pageSize:50,
	proxy:{
		type:'ajax',
		url:'base/controlParameter/getControlParameter',
		//headers:{'Authorization':sessionStorage.omcToken},
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'root',
			totalProperty:'totalProperty'
		}
	}
});