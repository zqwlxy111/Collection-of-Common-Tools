Ext.define('Mvc.store.base.GetAlarmGradesStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.base.AlarmGradeModel',
//	autoLoad:true,
	pageSize:50,
	proxy:{
		type:'ajax',
		extraParams:{'typeId':0,'paramId':0},
		url:'base/alarmGrade/getAlarmGrades',
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'root',
			totalProperty:'totalProperty'
		}
	}
});