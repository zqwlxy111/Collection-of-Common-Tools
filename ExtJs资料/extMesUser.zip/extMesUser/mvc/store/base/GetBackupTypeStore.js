Ext.define('Mvc.store.base.GetBackupTypeStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.base.ItemModel',
	autoLoad:true,
//	pageSize:35,
	proxy:{
		type:'ajax',
		extraParams:{'itemTitle':"备份类型"},
		url:'base/item/getItemsByTitle',
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'root',
			totalProperty:'totalProperty'
		}
	}
});