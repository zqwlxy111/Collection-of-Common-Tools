Ext.define('Mvc.store.base.GetItemTitleStore',{
	extend:'Ext.data.Store',
	fields:['itemTitle'],
//	autoLoad:true,
//	pageSize:35,
	proxy:{
		type:'ajax',
		url:'base/item/getItemTitles',
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'root',
			totalProperty:'totalProperty'
		}
	}
});