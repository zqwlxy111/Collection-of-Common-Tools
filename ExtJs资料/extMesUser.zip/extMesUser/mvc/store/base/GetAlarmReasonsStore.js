Ext.define('Mvc.store.base.GetAlarmReasonsStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.base.AlarmReasonModel',
//	autoLoad:true,
	pageSize:50,
	proxy:{
		type:'ajax',
		url:'base/alarmReason/getAlarmReasons',
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'root',
			totalProperty:'totalProperty'
		}
	}
});