Ext.define('Mvc.store.log.GetOperateLogsStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.log.OperateLogModel',
//	autoLoad:true,
	pageSize:50,
	proxy:{
		type:'ajax',
		url:'log/log/getOperateLogs',
		extraParams:{'sd':0,'ed':0},
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'root',
			totalProperty:'totalProperty'
		}
	}
});