Ext.define('Mvc.store.log.GetSafeLogsStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.log.SafeLogModel',
//	autoLoad:true,
	pageSize:50,
	proxy:{
		type:'ajax',
		url:'log/log/getSafeLogs',
		extraParams:{'sd':0,'ed':0},
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'root',
			totalProperty:'totalProperty'
		}
	}
});