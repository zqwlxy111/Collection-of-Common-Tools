Ext.define('Mvc.store.log.GetReportLogsStore',{
	extend:'Ext.data.Store',
	model:'Mvc.model.log.ReportLogModel',
//	autoLoad:true,
	pageSize:50,
	proxy:{
		type:'ajax',
		url:'log/log/getReportLogs',
		extraParams:{'sd':0,'ed':0,'reportType':''},
		actionMethods:{read:'POST'},
		reader:{
			type:'json',
			root:'root',
			totalProperty:'totalProperty'
		}
	}
});