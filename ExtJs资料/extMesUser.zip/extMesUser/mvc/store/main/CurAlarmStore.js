Ext.define('Mvc.store.main.CurAlarmStore',{
	extend:'Ext.data.Store',
	fields:['name','value']
})