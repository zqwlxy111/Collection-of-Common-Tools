Ext.define('Mvc.store.main.WorkStatusStore',{
	extend:'Ext.data.Store',
	fields:['name','count'],
//	autoLoad:true,
//	data: [{
//		name:"正常",count:62
//	},{
//		name:"未知",count:12
//	}]
})