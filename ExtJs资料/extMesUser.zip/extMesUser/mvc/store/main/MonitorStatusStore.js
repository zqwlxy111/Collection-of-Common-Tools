Ext.define('Mvc.store.main.MonitorStatusStore',{
	extend:'Ext.data.Store',
	fields:['name','count'],
//	autoLoad:true,
//	data: [{
//		name:"正常",count:26
//	},{
//		name:"一级告警",count:16
//	},{
//		name:"二级告警",count:8
//	},{
//		name:"三级告警",count:6
//	},{
//		name:"四级告警",count:6
//	}]
})