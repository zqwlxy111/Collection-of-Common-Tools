Ext.define('Mvc.view.safe.RolesPanel',{
	extend:'Ext.panel.Panel',
	alias:'widget.rolespanel',
	layout:'border',
	autoShow:true,
	border:false,
	maxinizable:true,
	closeAction:'close',
	initComponent:function(){
		var me=this;
		me.getRolesStore=Ext.getStore('safe.GetRolesStore').load();
		me.getRolesTreeStore=Ext.getStore('safe.GetRolesTreeStore').load();		
		// me.getRolesTreeStore=Ext.create('Ext.data.TreeStore', {
		//     // storeId:'departmentDetailStore',
		//     root: {
		// 		expanded:true,
		// 		checked:true,
		// 		children: [
		// 			{text:"detention",leaf:true,checked:true},
		// 			{text:"homework", expanded:true,checked:true, children: [
		// 				{text:"book report",leaf:false,expanded: true,checked:true , children: [
		// 					{text:"下级1",leaf:true,checked:true },
		// 					{ text:"下级2",leaf:true,checked:true}
		// 				]},
		// 				{ text:"alegrbra",leaf:true,checked:true}
		// 			]},
		// 			{text: "buy lottery tickets", leaf: true,checked:true}
		// 		]
		// 	}
		// });		
		this.items=[
			Ext.widget("treepanel",{
				id:'safe_rolesTree',
				region:'center',
				collapsible:false,
			    animCollapse:true,
			    split:true,
			    width:'100%',
			    height:'80%',
			    border:true,
				rootVisible:false,
				expanded:true,
				multiSelect:true,
				title:'角色详情',
				store:me.getRolesTreeStore,
				listeners:{ 
					checkchange:function(node,isChecked,opts){
						var roleJson={'roleId':me.rolesId,'item':[
								{'functionId':node.get('id'),'selected':isChecked}
							]};					
						Ext.Ajax.request({
							url:window.url+'/safe/function/updateRoleFunctions',
							headers:{'Content-Type':'application/json'},
							params:JSON.stringify(roleJson),
							method:'POST',
							success:function(response,option){
								var result=Ext.JSON.decode(response.responseText);
								if(result.success){
									// Ext.getCmp('safe_rolesTree').getStore().load();
								}else{
									Ext.Msg.alert('温馨提示',result.msg);
								}
							}
						});
					}
				},
			}),
			Ext.widget("panel",{
				region:'west',
				split:true,
				flex:1,
				height:'20%',
				multiSelect:false,
			    defaults:{
			    	xtype:'grid',
			    	width:'100%',
					height:'100%',
					border:false,
				},
			    items:[{
			    	id:'safe_RolesGrid',
					region:'center',
					title:'角色列表',
					store:me.getRolesStore,
					columnLines:true,
					stripeRows:true,
					columns:[{
						header:'角色Id',dataIndex:'id',flex:1,align:'center'
					},{
						header:'角色名称',dataIndex:'name',flex:1,align:'center'
					},{
						header:'所属系统',dataIndex:'systemId',flex:1,align:'center'
					},{
						header:'使用状态',dataIndex:'status',flex:1,align:'center',
						// renderer:displayUserStatusRender,
							editor:{
								xtype:'textfield',
								readOnly:true
							}
					},{
						header:'备注',dataIndex:'bak',flex:1,align:'center'
					}],
					listeners:{
						itemclick:function(_this,record){
							me.rolesId=record.get('id');
							Ext.getStore('safe.GetRolesTreeStore').proxy.extraParams.roleId=me.rolesId;
							me.getRolesTreeStore=Ext.getStore('safe.GetRolesTreeStore').load();				
						},
					},
					bbar:Ext.create('Ext.PagingToolbar',{
						id:'node_siteGridBar',
						store:me.getRolesStore,
						displayInfo:true,
						displayMsg:'显示{0}-{1}条,共计{2}条',
						emptyMsg:'没有数据',
						firstText:'第一页',
						lastText:'最后一页',
						afterPageText:'/{0}页',
						beforePageText:'第',
						nextText:'下一页',
						prevText:'上一页',
						refreshText:'刷新'
					}),
					viewConfig:{
						loadMask:{
							msg :'加载数据中，请稍候...'
					}}
				}]
			}),
		];
		this.callParent(arguments);
	}
});