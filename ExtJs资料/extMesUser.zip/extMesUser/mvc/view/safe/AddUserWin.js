Ext.define('Mvc.view.safe.AddUserWin',{
	extend:'Ext.window.Window',
	alias:'widget.adduserwin',
	border:false,
	layout:'fit',
	modal:true,
	autoShow:true,
	closable:false,
	width:600,
	// height:'100%',
	title:'新增用户',
	initComponent:function(){
		var me=this;
		me.getDepartmentTreeStore=Ext.getStore('safe.GetDepartmentTreeStore').load();
		me.systemStr='';
		// function changeAllCheck(obj,isChecked){
		// 	var array = obj.up("checkboxgroup").items;
		// 	if(isChecked){
		// 		//全选
		// 			array.each(function(item){  
		// 				item.setValue(true);  
		// 			});  
		// 	}else{
		// 		//全不选
		// 			array.each(function(item){  
		// 				item.setValue(false);  
		// 		}); 
		// 	}
		//  }
		me.items=[{
			xtype:'form',
			margins:"5,5,5,5",
			width:'100%',
			height:'100%',
			defaults:{
				labelWidth:100,
				width:560,
				padding:'5 0 0 5'
			},
			items:[{
				xtype:'textfield',
				name:"name",
				fieldLabel:"账号名称",
				emptyText:'账号名称',
				allowBlank:false,
				enforceMaxLength:45,
				maxLength:45,
				blankText:'请输入账号名称'
			},{
				xtype:'textfield',
				id:"addUser_password",
				name:"password",
				fieldLabel:"登录密码",
				emptyText:'密码由6-16位的数字,字母,下划线组成',
				inputType:"password",
				allowBlank:false,
				enforceMaxLength:16,
				maxLength:16,
				blankText:'请输入登录密码,密码由6-16位的数字,字母,下划线组成',
				regex:/^[A-Za-z0-9_]{6,16}$/,
                regexText:'密码应由6-16位的数字,字母,下划线组成',
			},{
				xtype:'textfield',
				submitValue:false,
				fieldLabel:"确认登陆密码",
				emptyText:'密码由6-16位的数字,字母,下划线组成',
				inputType:"password",
				allowBlank:false,
				enforceMaxLength:16,
				maxLength:16,
				blankText:'请输入登录密码,密码由6-16位的数字,字母,下划线组成',
				regex:/^[A-Za-z0-9_]{6,16}$/,
				regexText:'密码应由6-16位的数字,字母,下划线组成',
				listeners:{
						blur:function(testfield){
							if(Ext.getCmp('addUser_password').getValue()!=testfield.getValue()) {
								Ext.Msg.alert("两次输入的密码不同，请重新输入密码!");
								}
						}
				}
			},{
				xtype:'textfield',
				name:"realName",
				fieldLabel:"用户姓名",
				emptyText:'用户姓名',
				allowBlank:true,
				enforceMaxLength:30,
				maxLength:30,
				blankText:'请输入用户姓名'
			},{
				xtype:'textfield',
				name:"tel",
				fieldLabel:"电话",
				emptyText:'电话',
				allowBlank:true,
				enforceMaxLength:20,
				maxLength:20,
				blankText:'请输入电话',
				regex:/^[0-9-()]{8,20}$/,
        regexText:'请输入正确的电话',
			},{
				xtype:'textfield',
				name:"email",
				fieldLabel:"邮箱",
				emptyText:'邮箱',
				allowBlank:true,
				enforceMaxLength:45,
				maxLength:45,
				blankText:'请输入邮箱'
			},{
				xtype:'textfield',
				name:"code",
				fieldLabel:"工号",
				emptyText:'用户工号',
				allowBlank:true,
				enforceMaxLength:30,
				maxLength:30,
				blankText:'请输入用户工号'
			// },{
			// 	xtype:'combo',
			// 	name:"department",
			// 	fieldLabel:'部门',
			// 	allowBlank:true,
			// 	emptyText:'输入部门',
			// 	blankText:'请输入部门',
			// 	//submitValue:false,不参与表单提交
			// 	valueField:'id',
			// 	displayField:'name',
			// 	hiddenName:'name',
			// 	store:'safe.GetDepartmentParentStore',
			// 	forceSelection:false,
			// 	hideTrigger:true,
			// 	typeAhead:true,
			// 	minChars:1,
			// 	enforceMaxLength:45,
			// 	maxLength:45,
			// 	triggerAction:'all',
			// 	queryMode:'remote',
			// 	queryParam:'name',
			},{
				xtype:'comboboxTree',
				fieldLabel:'部门',
				allowBlank:true,
				emptyText:'输入部门',
				blankText:'请输入部门',
				submitValue:false,
				valueField:'id',
				displayField:'name',
				multiSelect:true,
				editable:false,
				treeObj:Ext.widget("treepanel",{
					collapsible:false,
					animCollapse:true,
					split:true,
					width:'100%',
					height:150,
					border:true,
					rootVisible:false,
					multiSelect:true,
					// title:'部门组织架构',
					store:me.getDepartmentTreeStore,
					// listeners:{ 
					// 	checkchange:function(_this,td,cellindex,record){
					// 		me.cellRecord=record;
					// 		var rs=[];
					// 		var ritem={};
					// 		ritem.id=me.cellRecord.raw.obj.id;
					// 		ritem.name=me.cellRecord.raw.obj.name;
					// 		ritem.code=me.cellRecord.raw.obj.code;
					// 		ritem.parentId=me.cellRecord.raw.obj.parentId==0?'无':me.cellRecord.raw.obj.parentName;
					// 		ritem.parentName=me.cellRecord.raw.obj.parentName;
					// 		ritem.bak=me.cellRecord.raw.obj.bak;
					// 		rs.push(ritem);					
					// 	},
					// },
				}),
			},{
        xtype:'hidden',
				id:'safe_addUser_departmentId',
				name:'departments',
			},{
				xtype:'datefield',
				fieldLabel:"用户有效期",
				emptyText:'用户有效期',
				submitValue:false,
				format:'Y-m-d',
				editable:false,
				allowBlank:true,
				listeners:{
					change:function(datefield,nv){
						Ext.getCmp('safe_addUser_userValidity').setValue(nv.getTime());
					}
			  }
      },{
        xtype:'hidden',
				id:'safe_addUser_userValidity',
				name:'userValidity'
      },{
				xtype:'datefield',
				fieldLabel:"密码有效期",
				emptyText:'密码有效期',
				submitValue:false,
				format:'Y-m-d',
				editable:false,
				allowBlank:true,
				listeners:{
					change:function(datefield,nv){
						Ext.getCmp('safe_addUser_pwdValidity').setValue(nv.getTime());
					}
				}
			},{
				xtype:'hidden',
				id:'safe_addUser_pwdValidity',
				name:'pwdValidity'
			},{
				xtype:'checkboxgroup',
				fieldLabel:"所属系统",
				id:'adduserwin_systems',
				submitValue:false,
				columns:2,
				items:[
					// {
					// 	boxLabel: '全选' ,checked:false,
					// 	listeners:{  
					// 		'change':function(obj,isChecked){
					// 					changeAllCheck(obj,isChecked);
					// 			}  
					// 		} 
					// }
				],
				listeners:{
					afterrender:function(checkboxgroup){
						Ext.Ajax.request({
							url : window.url+'/safe/syss/getSystems',
							method : 'GET',
							success : function(response, options) {
								var result=JSON.parse(response.responseText);
								result=result.result;
								var checkboxgroup = Ext.getCmp("adduserwin_systems");
								for (var i = 0; i < result.length; i++) {
									var checkbox = new Ext.form.Checkbox(
									  {
										  boxLabel: result[i].name,
										  name: result[i].id,
										  inputValue: result[i].id,   
										  checked: false,
										  listeners:{
											  change:function(cb){
													var systemsValue=Ext.getCmp('adduserwin_systems').getChecked();
													me.systemArr=[]; 
													me.systemSubmitArr=[];  
													for(var i in systemsValue){
														me.systemArr.push(systemsValue[i].inputValue);
														me.systemSubmitArr.push({'name':systemsValue[i].name,'id':result[i].id});
													}
													me.systemStr=me.systemArr.join(',');
													Ext.getStore('safe.GetRolesStore').proxy.extraParams.systemIds=me.systemStr;
													Ext.getStore('safe.GetRolesStore').load();
													Ext.getCmp('safe_adduser_roles_select').setValue('');
													// 提交的数据形式，需要问下丘晓锋
													// Ext.getCmp('safe_adduser_systems').setValue(me.systemSubmitArr);
													Ext.getCmp('safe_adduser_systems').value=me.systemSubmitArr;
											  }
										  },
									  });
									checkboxgroup.items.add(checkbox);
								}
								Ext.getCmp("adduserwin_systems").doLayout(); //重新调整版面布局  
							},
							failure : function() {
								Ext.Msg.alert("提示", "删除失败！");
							}
						});
					}
				}
		},{
			xtype:'hidden',
			id:'safe_adduser_systems',
			name:"systems",
		},{
				xtype:'combobox',
				id:'safe_adduser_roles_select',
				fieldLabel:'角色',
				emptyText:'角色',
				valueField:'id',
				displayField:'name',
				store:'safe.GetRolesStore',
				multiSelect:true,
				editable:false,
				allowBlank:true,
				submitValue:false,
				listeners:{
					change:function(combo,nv,ov,eopts){
						//需要从邱晓峰那里知道传参格式
						var comboValue=combo.getValue();
						var comboArr=[];
						me.getRolesStore=Ext.getStore('safe.GetRolesStore');
						me.getRolesStore.load(function(records){
							for(var i in records){
								for(var j in comboValue){
									if(records[i].data.id==comboValue[j]){
										comboArr.push({'name':records[i].data.name,'id':comboValue[j]});
									}
								}
							}
							Ext.getCmp('safe_adduser_roles').value=comboArr;
						})
					}
				}
		},{
			xtype:'hidden',
			id:'safe_adduser_roles',
			name:"roles",
			// },{
			// 	xtype:'combobox',
			// 	fieldLabel:'角色',
			// 	emptyText:'角色',
			// 	name:'roles',
			// 	value:[],
			// 	valueField:'id',
			// 	displayField:'name',
			// 	hiddenName:'name',
			// 	// store:'safe.GetGroupsStore',
			// 	store:getRoleStore,
			// 	multiSelect:true,
			// 	editable:false,
			// 	allowBlank:true,
			// 	queryMode:'local',
			}]
		}];
		me.buttonAlign='center',
		me.buttons=[{
			text:'保存',
			width:150,
			height:22,
			padding:'0',
			margins:'0',
			border:false,
			handler:function(btn){
				var f=btn.up('window').down('form');	
				if(f && f.isValid()){
					var json=f.getValues();
					json.departments=Ext.getCmp('safe_addUser_departmentId').value?Ext.getCmp('safe_addUser_departmentId').value:[];
					json.systems=Ext.getCmp('safe_adduser_systems').value?Ext.getCmp('safe_adduser_systems').value:[];
					json.roles=Ext.getCmp('safe_adduser_roles').value?Ext.getCmp('safe_adduser_roles').value:[];
					Ext.Ajax.request({
							url:window.url+'/safe/user/addUser',
							method:'POST',
		    			headers:{'Content-Type':'application/json'},
		    			params:JSON.stringify(json),
		    			success:function(response,option){
		    				var result=Ext.JSON.decode(response.responseText);
		    				if(result.success){
		    					f.up('window').close();
		    					Ext.getCmp('safe_userGridBar').doRefresh();
		    				}else
		    					alert(result.msg);
		    			}
		    		});
				}
			}   
		},{
			text:'关闭',
			width:150,
			height:22,
			padding:'0',
			margins:'0',
			border:false,
			scope:this,
			handler:this.close
		}]
		this.callParent(arguments);
	}
});