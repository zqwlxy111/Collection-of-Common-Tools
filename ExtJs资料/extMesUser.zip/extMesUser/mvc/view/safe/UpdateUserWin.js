Ext.define('Mvc.view.safe.UpdateUserWin',{
	extend:'Ext.window.Window',
	alias:'widget.updateuserwin',
	border:false,
	layout:'fit',
	modal:true,
	autoShow:true,
	closable:false,
	width:360,
	title:'修改用户信息',
	initComponent:function(){
		var me=this;
		me.getDepartmentTreeStore=Ext.getStore('safe.GetDepartmentTreeStore').load();
		me.items=[{
			xtype:'form',
			margins:"5,5,5,5",
			width:'100%',
			height:'100%',
			defaults:{
				width:330,
				padding:'5 0 0 5'
			},
			listeners:{ 
				afterrender:function(form){
					form.loadRecord(me.dataRecord);
				},
			},
			items:[{
        		xtype:'hidden',
				name:'id',
				// value:me.dataRecord.get('id')
			},{
				xtype:'textfield',
				name:"name",
				fieldLabel:"账号名称",
				emptyText:'账号名称',
				allowBlank:false,
				enforceMaxLength:45,
				maxLength:45,
				blankText:'请输入账号名称',
			},{
				xtype:'textfield',
				name:"realName",
				fieldLabel:"用户姓名",
				emptyText:'用户姓名',
				allowBlank:true,
				enforceMaxLength:30,
				maxLength:30,
				blankText:'请输入用户姓名',
			},{
				xtype:'textfield',
				name:"tel",
				fieldLabel:"电话",
				emptyText:'电话',
				allowBlank:true,
				enforceMaxLength:20,
				maxLength:20,
				blankText:'请输入电话',
				regex:/^[0-9-()]{8,20}$/,
				regexText:'请输入正确的电话',
			},{
				xtype:'textfield',
				name:"email",
				fieldLabel:"邮箱",
				emptyText:'邮箱',
				allowBlank:true,
				enforceMaxLength:45,
				maxLength:45,
				blankText:'请输入邮箱',
				regex:/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/,
				regexText:'请输入正确的邮箱格式',
			// },{
			// 	xtype:'combo',
			// 	name:"department",
			// 	fieldLabel:'部门',
			// 	allowBlank:true,
			// 	emptyText:'输入部门',
			// 	blankText:'请输入部门',
			// 	submitValue:false,
			// 	valueField:'id',
			// 	displayField:'name',
			// 	hiddenName:'name',
			// 	store:'safe.GetDepartmentParentStore',
			// 	forceSelection:false,
			// 	hideTrigger:true,
			// 	typeAhead:true,
			// 	minChars:1,
			// 	enforceMaxLength:45,
			// 	maxLength:45,
			// 	triggerAction:'all',
			// 	queryMode:'remote',
			// 	queryParam:'name',
			// 	multiSelect:true,
			// 	listeners:{
			// 		afterrender:function(combo){
			// 			// if(me.dataRecord.raw.obj.parentName!=null && me.dataRecord.raw.obj.parentName!=''){
			// 				combo.setValue(me.dataRecord.get('departmentString'));
			// 			// }		
			// 		},
			// 		select:function(combo,records){
			// 			var v=combo.lastSelection[0];
			// 				Ext.getCmp('safe_updateUser_department').setValue(v.get('id'));
			// 				Ext.getCmp('safe_updateUser_departmentString').setValue(v.get('name'));
			// 		},
			// 		change:function(combo,nv,ov){
			// 			if(nv==null){
			// 				Ext.getCmp('safe_updateUser_department').setValue();
			// 				Ext.getCmp('safe_updateUser_departmentString').setValue();
			// 			}
			// 		}
			// 	}
			},{
				xtype:'comboboxTree',
				fieldLabel:'部门',
				allowBlank:true,
				emptyText:'输入部门',
				blankText:'请输入部门',
				submitValue:false,
				valueField:'id',
				displayField:'name',
				hiddenName:'name',
				multiSelect:true,
				editable:false,
				treeObj:Ext.widget("treepanel",{
					collapsible:false,
				  	animCollapse:true,
					split:true,
					width:'100%',
					height:150,
					border:true,
					rootVisible:false,
					multiSelect:true,
					store:me.getDepartmentTreeStore,
				}),
				listeners:{
					afterrender:function(combo){
						combo.setValue(me.dataRecord.get('departmentsStr'));
					}
				}
			},{
				xtype:'hidden',
				id:'safe_updateUser_departments',
				name:"departments",
			},{
				xtype:'datefield',
				fieldLabel:"用户有效期",
				emptyText:'用户有效期',
				submitValue:false,
				format:'Y-m-d',
				editable:false,
				allowBlank:true,
				listeners:{
					afterrender:function(df){
						var userValidityStr=me.dataRecord.get('userValidity')==null?null:getMyDate(me.dataRecord.get('userValidity'),true);
						df.setValue(userValidityStr);
					},
					change:function(datefield,nv){
						Ext.getCmp('safe_updateUser_userValidity').setValue(nv.getTime());
					}
			  }
			},{
				xtype:'hidden',
				id:'safe_updateUser_userValidity',
				name:'userValidity',
			},{
				xtype:'datefield',
				fieldLabel:"密码有效期",
				emptyText:'密码有效期',
				submitValue:false,
				format:'Y-m-d',
				editable:false,
				allowBlank:true,
				listeners:{
					afterrender:function(df){
						var pwdValidityStr=me.dataRecord.get('pwdValidity')==null?null:getMyDate(me.dataRecord.get('pwdValidity'),true);
						df.setValue(pwdValidityStr);
					},
					change:function(datefield,nv){
						Ext.getCmp('safe_updateUser_pwdValidity').setValue(nv.getTime());
					}
			  }
			},{
				xtype:'hidden',
				id:'safe_updateUser_pwdValidity',
				name:'pwdValidity'
			}]
		}];
		me.buttonAlign='center',
		me.buttons=[{
			text:'保存',
			width:150,
			height:22,
			padding:'0',
			margins:'0',
			border:false,
			handler:function(btn){
				var f=btn.up('window').down('form');
				var json=f.getValues();
				json.departments=Ext.getCmp('safe_updateUser_departments').value1?
				Ext.getCmp('safe_updateUser_departments').value1:me.dataRecord.get('departments');
				console.log(Ext.getCmp('safe_updateUser_departments').value1,json.departments,'rrr')
				json.pwdValidity=json.pwdValidity?json.pwdValidity:me.dataRecord.get('pwdValidity');
				json.userValidity=json.userValidity?json.userValidity:me.dataRecord.get('userValidity');
				if(f && f.isValid()){
					Ext.Ajax.request({
						url:window.url+'/safe/user/updateUser',
						method:'POST',
		    			headers:{'Content-Type':'application/json'},
		    			params:JSON.stringify(json),
		    			success:function(response,option){
		    				var result=Ext.JSON.decode(response.responseText);
		    				if(result.success){
		    					f.up('window').close();
		    					Ext.getCmp('safe_userGridBar').doRefresh();
		    					Ext.getCmp('safe_userGrid').getSelectionModel().deselectAll();
							}
		    			}
		    		});
				}
			}
		},{
			text:'关闭',
			width:150,
			height:22,
			padding:'0',
			margins:'0',
			border:false,
			scope:this,
			handler:this.close
		}]
		this.callParent(arguments);
	}
});