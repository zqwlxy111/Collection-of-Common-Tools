Ext.define('Mvc.view.safe.AddDepartmentWin',{
	extend:'Ext.window.Window',
	alias:'widget.adddepartmentwin',
	border:false,
	layout:'fit',
	modal:true,
	autoShow:true,
	closable:false,
	width:370,
	title:'新增普通部门',
	initComponent:function(){
		var me=this;
		me.getUserLikeNameStore=Ext.create('Mvc.store.safe.GetUserLikeNameStore');
        // var dataTypeStore=Ext.create('Ext.data.Store', {
	    //     fields: ['typeKey', 'typeName'],
	    //     data : [
	    //         {"typeKey":"0", "typeName":"其他"},
	    //         {"typeKey":"1", "typeName":"工厂"},
	    //         {"typeKey":"2", "typeName":"产线"},
	    //     ]
	    // });
		me.items=[{
			xtype:'form',
			margins:"5,5,5,5",
			width:'100%',
			height:'100%',
			defaults:{
				labelWidth:90,
				width:330,
				padding:'5 0 0 5'
			},
			items:[{
				xtype:'textfield',
				name:"name",
				fieldLabel:"部门名称",
				emptyText:'部门名称',
				allowBlank:false,
				enforceMaxLength:45,
				maxLength:45,
				blankText:'请输入部门名称'
			},{
				xtype:'textfield',
				name:"code",
				fieldLabel:"部门编号",
				emptyText:'请输入部门编号',
				allowBlank:false,
				enforceMaxLength:45,
				maxLength:45,
				blankText:'请输入部门编号',
				listeners:{
					blur:function(_field){
						var textCode=_field.getValue();
						Ext.Ajax.request({
							url:window.url+'/base/checkCode'+'?code='+textCode,
							method:'GET',
							success:function(response,option){
								var result=Ext.JSON.decode(response.responseText);
								if(result.success && result.result==false){
									Ext.Msg.alert('温馨提示', '【部门编号】不能重复！！');
								}
							}
						});
					}
				}
			},{
				xtype:'hidden',
				name:"parentId",
				value:me.dataRecord.raw.id,
			// },{
			// 	xtype:'combo',
			// 	name:"parentId",
			// 	fieldLabel:'上级部门',
			// 	allowBlank:true,
			// 	emptyText:'直属上级部门',
			// 	blankText:'请输入直属上级部门',
			// 	//submitValue:false,不参与表单提交
			// 	valueField:'id',
			// 	displayField:'name',
			// 	store:'safe.GetDepartmentParentStore',
			// 	forceSelection:false,
			// 	hideTrigger:true,
			// 	typeAhead:true,
			// 	enforceMaxLength:45,
			// 	maxLength:45,
			// 	triggerAction:'all',
			// 	queryMode:'remote',
			// 	queryParam:'name',
			// 	minChars:1,
			// },{
			// 	xtype:'combo',
			// 	name:"dataType",
			// 	fieldLabel:"数据类型",
			// 	emptyText:'请选择数据类型',
			// 	allowBlank:false,
			// 	blankText:'请选择数据类型',				
            //     allowBlank:false,
            //     editable:false,
            //     forceSelection:true,
            //     minChars:1,
            //     triggerAction:'all',
            //     store:dataTypeStore,
            //     queryMode:'local',
            //     hiddenName:'typeName',
            //     displayField:'typeName',
            //     valueField: 'typeKey',
            //     queryParam:'typeKey',
            //     listeners:{
            //         select:function(combo){
            //             var v=combo.lastSelection[0];
            //             var dataTypeName=v.get('typeName');
            //             Ext.getCmp('safe_addDeparetmentType').setValue(dataTypeName);                     
            //         }
            //     }
            // },{
            // 	xtype:'hidden',
			// 	id:'safe_addDeparetmentType',
			// 	name:'dataTypeString',
			// },{
			// 	xtype:'textfield',
			// 	name:"headOfUnit",
			// 	fieldLabel:"部门负责人",
			// 	emptyText:'请输入部门负责人',
			// 	allowBlank:true,
			// 	enforceMaxLength:30,
			// 	maxLength:30,
			// 	blankText:'请输入部门负责人'
			},{
				xtype:'combo',
				name:"headOfUnit",
				fieldLabel:'部门负责人',
				allowBlank:true,
				emptyText:'请输入部门负责人',
				blankText:'请输入部门负责人',
				//submitValue:false,不参与表单提交
				valueField:'id',
				displayField:'realName',
				store:'safe.GetUserLikeNameStore',
				forceSelection:true,
				hideTrigger:true,
				typeAhead:true,
				enforceMaxLength:45,
				maxLength:45,
				triggerAction:'all',
				queryMode:'remote',
				queryParam:'name',
				minChars:1,
			// },{
			// 	xtype:'hidden',
			// 	name:"headOfUnitName",
			},{
				xtype:'combo',
				name:"salveOfUnit",
				fieldLabel:'部门第二负责人',
				allowBlank:true,
				emptyText:'请输入部门第二负责人',
				blankText:'请输入部门第二负责人',
				//submitValue:false,不参与表单提交
				valueField:'id',
				displayField:'realName',
				store:'safe.GetUserLikeNameStore',
				forceSelection:true,
				hideTrigger:true,
				typeAhead:true,
				enforceMaxLength:45,
				maxLength:45,
				triggerAction:'all',
				queryMode:'remote',
				queryParam:'name',
				minChars:1,
			// },{
			// 	xtype:'hidden',
			// 	name:"salveOfUnitName",
			},{
            	xtype:'hidden',
				name:'status',
				value:1,
			},{
				xtype:'textfield',
				name:"bak",
				fieldLabel:"备注",
				emptyText:'备注',
				allowBlank:true,
				enforceMaxLength:50,
				maxLength:50,
				blankText:'请输入备注',
			}]
		}];
		me.buttonAlign='center',
		me.buttons=[{
			text:'保存',
			width:150,
			height:22,
			padding:'0',
			margins:'0',
			border:false,
			handler:function(btn){
				var f=btn.up('window').down('form');
				if(f && f.isValid()){
					var json=f.getValues();
					var url='';
					if(me.dataRecord.raw.obj.dataType==1){
						url='/base/addCompany';
					}else if(me.dataRecord.raw.obj.dataType==2){
						url='/base/addManufCenter';
					}else if(me.dataRecord.raw.obj.dataType==3){
						url='/base/addCompanyDepartment';
					}else if(me.dataRecord.raw.obj.dataType==4){
						url='/base/addFactroySubDepartment';
					}else if(me.dataRecord.raw.obj.dataType==41){
						url='/base/addOffice';
					}else{
						Ext.Msg.alert('温馨提示','请选择【正确的上级部门】以及【正确的新增按钮】！');
						return false;
					}
					Ext.Ajax.request({
		    			url:window.url+url,
		    			headers:{'Content-Type':'application/json'},
		    			params:JSON.stringify(json),
		    			success:function(response,option){
		    				var result=Ext.JSON.decode(response.responseText);
		    				if(result.success){
		    					f.up('window').close();
		    					Ext.getStore('safe.GetDepartmentTreeStore').load();
							}
		    			}
		    		});
				}
			}
		},{
			text:'关闭',
			width:150,
			height:22,
			padding:'0',
			margins:'0',
			border:false,
			scope:this,
			handler:this.close
		}]
		this.callParent(arguments);
	}
});