Ext.define('Mvc.view.safe.DepartmentPanel',{
	extend:'Ext.panel.Panel',
	alias:'widget.departmentpanel',
	layout:'border',
	autoShow:true,
	border:false,
	maxinizable:true,
	closeAction:'close',
	initComponent:function(){
		var me=this;
		me.getDepartmentTreeStore=Ext.getStore('safe.GetDepartmentTreeStore').load();
		Ext.create('Ext.data.Store', {
		    storeId:'departmentDetailStore',
		    fields:['id','name','code','parentId','bak','parentName','headOfUnit','headOfUnitName','salveOfUnit','salveOfUnitName','status'],
		});
		this.items=[
			Ext.widget("treepanel",{
				id:'safe_departmentTree',
				region:'center',
				collapsible:false,
			    animCollapse:true,
			    split:true,
			    width:'100%',
			    height:'80%',
			    border:true,
				rootVisible:false,
				multiSelect:true,
				title:'部门组织架构',
				tbar:["->",{text:'刷新', action:'refreshDepartmentAction',
			},'   ',{
					text:'新增普通部门', action:'addDepartmentAction',
				},{
					text:'新增工厂', action:'addDepartmentFactoryAction',
				},{
					text:'新增产线', action:'addDepartmentLineAction',
				},{
					text:'修改部门',action:'updateDepartmentAction'
				// },{
				// 	text:'删除部门',action:'deleteDepartmentAction'
				}],
				store:me.getDepartmentTreeStore,
				listeners:{ 
					cellclick:function(_this,td,cellindex,record){
						me.cellRecord=record;
						var rs=[];
						var ritem={};
						ritem.id=me.cellRecord.raw.obj.id;
						ritem.name=me.cellRecord.raw.obj.name;
						ritem.code=me.cellRecord.raw.obj.code;
						ritem.parentId=me.cellRecord.raw.obj.parentId;
						ritem.parentName=me.cellRecord.raw.obj.parentName;
						ritem.bak=me.cellRecord.raw.obj.bak;
						ritem.headOfUnit=me.cellRecord.raw.obj.headOfUnit;
						ritem.headOfUnitName=me.cellRecord.raw.obj.headOfUnitName;
						ritem.salveOfUnit=me.cellRecord.raw.obj.salveOfUnit;
						ritem.salveOfUnitName=me.cellRecord.raw.obj.salveOfUnitName;
						ritem.status=me.cellRecord.raw.obj.status;
						rs.push(ritem);
						Ext.getCmp('safe_DepartmentGrid').getStore().loadData(rs);					
					},
				},
			}),
			Ext.widget("panel",{
				// layout:'vbox',
				region:'south',
				split:true,
				flex:1,
				height:'20%',
				multiSelect:false,
			    defaults:{
			    	xtype:'grid',
			    	width:'100%',
					height:'100%',
					border:false,
				},
			    items:[{
			    	id:'safe_DepartmentGrid',
					region:'center',
					title:'部门详情',
					store:'departmentDetailStore',
					columnLines:true,
					columns:[{
						header:'编号',dataIndex:'id',width:40,align:'center'
					},{
						header:'部门名称',dataIndex:'name',flex:1,align:'center'
					},{
						header:'部门编号',dataIndex:'code',flex:1,align:'center'
					},{
						header:'上级部门',dataIndex:'parentName',flex:1,align:'center'
					},{
						header:'部门负责人',dataIndex:'headOfUnitName',flex:1,align:'center'
					},{
						header:'使用状态',dataIndex:'status',flex:1,align:'center',renderer:displayUserStatusRender,
							editor:{
								xtype:'textfield',
								readOnly:true
							}
					},{
						header:'备注',dataIndex:'bak',flex:1,align:'center'
					}],
					plugins:[Ext.create('Ext.grid.plugin.CellEditing',{
				        clicksToEdit:1,
				        listeners:{
				        	beforeedit:function(editor,e,ops){
			        			if(e.column.dataIndex=='status'){
			        				e.column.setEditor({
			        					xtype:'combo',
			        					valueField:'value',
			        					displayField:'key',
			        					store:Ext.create("Ext.data.Store",{
			        						fields:["key","value"],
			        						data:[{key:'禁用',value:2},{key:'启用',value:1}]
			        					}),
			        					editable:false,
			        					listeners:{
			        						select:function(combo){
			        							editor.completeEdit();
			        						}
			        					}
			        				});
			        			}
				        	},
				        	edit:function(editor,e,ops){
				        		Ext.Ajax.request({  
									// url:window.url+'/safe/department/updateDepartment',
									url:window.url+'/base/updateOrganize',
									headers:{'Content-Type':'application/json'},
									params:JSON.stringify(e.record.data),
									success:function(response,option){
										var result=Ext.JSON.decode(response.responseText);
										if(result.success){
											Ext.getStore('safe.GetDepartmentTreeStore').load()
										}else{
											alert(result.msg);
										}
									}
								});
				        	}
				        }
				    })],
					// bbar:Ext.create('Ext.PagingToolbar',{
					// 	id:'node_siteGridBar',
					// 	store:me.getSitesStore,
					// 	displayInfo:true,
					// 	displayMsg:'显示{0}-{1}条,共计{2}条',
					// 	emptyMsg:'没有数据',
					// 	firstText:'第一页',
					// 	lastText:'最后一页',
					// 	afterPageText:'/{0}页',
					// 	beforePageText:'第',
					// 	nextText:'下一页',
					// 	prevText:'上一页',
					// 	refreshText:'刷新'
					// }),
					viewConfig:{
						loadMask:{
							msg :'加载数据中，请稍候...'
					}}
				}]
			}),
		];
		this.callParent(arguments);
	}
});