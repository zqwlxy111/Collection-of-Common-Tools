Ext.define('Mvc.view.safe.UpdateDepartmentWin',{
	extend:'Ext.window.Window',
	alias:'widget.updatedepartmentwin',
	border:false,
	layout:'fit',
	modal:true,
	autoShow:true,
	closable:false,
	width:370,
	title:'修改部门',
	initComponent:function(){
		var me=this;
		me.baseData=[];
		me.baseStore=Ext.create('Ext.data.Store', {
	        fields: ['id','name','code','bak','status'],
	        data : me.baseData,
	    });
		me.items=[{
			xtype:'form',
			margins:"5,5,5,5",
			width:'100%',
			height:'100%',
			defaults:{
				labelWidth:90,
				width:330,
				padding:'5 0 0 5'
			},
			listeners:{
				afterrender:function(form){
					var item1,item2;
					if(me.dataRecord.raw.obj.dataType==6){
						item1={
							xtype:'numberfield',
							name:'capacity',
							fieldLabel:'线体产能',
							emptyText:'请输线体产能',
							allowBlank:true,
							enforceMaxLength:30,
							maxLength:30,
							minValue:0,
							blankText:'请输入线体产能',
							value:me.dataRecord.raw.obj.capacity
						}
						form.add(item1);
					}	
					if(me.dataRecord.raw.obj.dataType==4){
						item2={
							xtype:'combobox',
							name:"base",
							fieldLabel:"基地",
							emptyText:'请输入基地',
							allowBlank:false,
							editable:false,
							blankText:'请输入基地',
							valueField:'id',
							displayField:'name',
							store:me.baseStore,
							forceSelection:false,
							typeAhead:true,
							minChars:1,
							queryMode:'local',
							id:'updateDepartmentWin_base',
						}
						form.add(item2);
						Ext.Ajax.request({
							url:window.url+'/base/getBase',
							method:'GET',
							success:function(response,option){
								var result=Ext.JSON.decode(response.responseText);
								me.baseStore.loadData(result);
								Ext.getCmp('updateDepartmentWin_base').setValue(me.dataRecord.raw.obj.base);
							}
						});
					}			
				}
			},
			items:[{
				xtype:'hidden',
				name:'id',
				value:me.dataRecord.raw.obj.id
			},{
				xtype:'textfield',
				name:"name",
				fieldLabel:"部门名称",
				emptyText:'部门名称',
				allowBlank:false,
				enforceMaxLength:45,
				maxLength:45,
				blankText:'请输入部门名称',
				value:me.dataRecord.raw.obj.name,
			},{
				xtype:'textfield',
				name:"code",
				fieldLabel:"部门编号",
				emptyText:'请输入部门编号',				
				allowBlank:false,
				enforceMaxLength:30,
				maxLength:30,
				blankText:'请输入部门编号',
				value:me.dataRecord.raw.obj.code,
				listeners:{
					blur:function(_field){
						var textCode=_field.getValue();
						Ext.Ajax.request({
							url:window.url+'/base/checkCode'+'?code='+textCode,
							method:'GET',
							success:function(response,option){
								var result=Ext.JSON.decode(response.responseText);
								if(result.success && result.result==false){
									Ext.Msg.alert('温馨提示', ' 【部门编号】 不能重复！！');
								}
							}
						});
					}
				}
			// },{
			// 	xtype:'combo',
			// 	fieldLabel:'上级部门ID',
			// 	allowBlank:true,
			// 	emptyText:'直属上级部门',
			// 	blankText:'上级部门',
			// 	submitValue:false,
			// 	valueField:'id',
			// 	displayField:'name',
			// 	store:'safe.GetDepartmentParentStore',
			// 	forceSelection:false,
			// 	hideTrigger:true,
			// 	typeAhead:true,
			// 	enforceMaxLength:45,
			// 	maxLength:45,
			// 	triggerAction:'all',
			// 	queryMode:'remote',
			// 	queryParam:'name',
			// 	listeners:{
			// 		afterrender:function(combo){
			// 			if(me.dataRecord.raw.obj.parentName!=null && me.dataRecord.raw.obj.parentName!=''){
			// 				combo.setValue(me.dataRecord.raw.obj.parentName);
			// 			}		
			// 		},
			// 		select:function(combo,records){
			// 			var v=combo.lastSelection[0];
			// 				Ext.getCmp('safe_updateDepartment_parentId').setValue(v.get('id'));
			// 				Ext.getCmp('safe_updateDepartment_parentName').setValue(v.get('name'));
			// 		},
			// 		change:function(combo,nv,ov){
			// 			if(nv==null){
			// 				Ext.getCmp('safe_updateDepartment_parentId').setValue();
			// 				Ext.getCmp('safe_updateDepartment_parentName').setValue();
			// 			}
			// 		}
			//     }
            // },{
			// 	xtype:'hidden',
			// 	id:'safe_updateDepartment_parentId',
			// 	name:"parentId",
			// 	value:me.dataRecord.raw.obj.parentId
			},{
				xtype:'hidden',
				id:'safe_updateDepartment_parentId',
				name:"parentId",
				value:me.dataRecord.raw.obj.parentId
			},{
				xtype:'combo',
				name:"headOfUnit",
				fieldLabel:'部门负责人',
				allowBlank:true,
				emptyText:'请输入部门负责人',
				blankText:'请输入部门负责人',
				valueField:'id',
				displayField:'realName',
				store:'safe.GetUserLikeNameStore',
				forceSelection:false,
				hideTrigger:true,
				typeAhead:true,
				enforceMaxLength:45,
				maxLength:45,
				triggerAction:'all',
				queryMode:'remote',
				queryParam:'name',
				minChars:1,
				listeners:{
					afterrender:function(combo){
						me.hasChangeHeadName=false;
						if(me.dataRecord.raw.obj.headOfUnitName!=null && me.dataRecord.raw.obj.headOfUnitName!=''){
							combo.setValue(me.dataRecord.raw.obj.headOfUnitName);
						}						
					},
					select:function(combo){
						me.hasChangeHeadName=true;
					}
				}
			},{
				xtype:'combo',
				name:"salveOfUnit",
				fieldLabel:'部门第二负责人',
				allowBlank:true,
				emptyText:'请输入部门第二负责人',
				blankText:'请输入部门第二负责人',
				valueField:'id',
				displayField:'realName',
				store:'safe.GetUserLikeNameStore',
				forceSelection:false,
				hideTrigger:true,
				typeAhead:true,
				enforceMaxLength:45,
				maxLength:45,
				triggerAction:'all',
				queryMode:'remote',
				queryParam:'name',
				minChars:1,
				listeners:{
					afterrender:function(combo){
						me.hasChangeSalveName=false;
						if(me.dataRecord.raw.obj.salveOfUnitName!=null && me.dataRecord.raw.obj.salveOfUnitName!=''){
							combo.setValue(me.dataRecord.raw.obj.salveOfUnitName);
						}							
					},
					select:function(combo){
						me.hasChangeSalveName=true;
					}
				}
			},{
            	xtype:'hidden',
				name:'status',
				value:me.dataRecord.raw.obj.useStatus,
			},{
				xtype:'textfield',
				name:"bak",
				fieldLabel:"备注",
				emptyText:'备注',
				value:me.dataRecord.raw.obj.bak,
				allowBlank:true,
				enforceMaxLength:50,
				maxLength:50,
				blankText:'请输入备注',
			}]
		}];
		me.buttonAlign='center',
		me.buttons=[{
			text:'保存',
			width:150,
			height:22,
			padding:'0',
			margins:'0',
			border:false,
			handler:function(btn){
				var f=btn.up('window').down('form');
				if(f && f.isValid()){
					var json=f.getValues();
					// if(json.parentId==''){
					// 	json.parentId=0;
					// }
					//判断是否做了修改
					if(me.hasChangeHeadName==false){
						json.headOfUnit=me.dataRecord.raw.obj.headOfUnit;
					}
					if(me.hasChangeSalveName==false){
						json.salveOfUnit=me.dataRecord.raw.obj.salveOfUnit;
					}
					// if(json.headOfUnit==me.dataRecord.raw.obj.headOfUnitName && json.salveOfUnit==me.dataRecord.raw.obj.salveOfUnitName){
					// 	Ext.Msg.alert('温馨提示','没有做任何修改');
					// 	return false;
					// }
					Ext.Ajax.request({
		    			url:window.url+'/base/updateOrganize',
		    			headers:{'Content-Type':'application/json'},
		    			params:JSON.stringify(json),
		    			success:function(response,option){
		    				var result=Ext.JSON.decode(response.responseText);
		    				if(result.success){
		    					f.up('window').close();
								Ext.getStore('safe.GetDepartmentTreeStore').load();
								Ext.getCmp('safe_departmentTree').getSelectionModel().clearSelections();
		    				}else{
								Ext.Msg.alert('温馨提示',result.msg);
							}
		    			}
		    		});
				}
					
			}
		},{
			text:'关闭',
			width:150,
			height:22,
			padding:'0',
			margins:'0',
			border:false,
			scope:this,
			handler:this.close
		}]
		this.callParent(arguments);
	}
});