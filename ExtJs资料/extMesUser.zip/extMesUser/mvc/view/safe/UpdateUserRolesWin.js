Ext.define('Mvc.view.safe.UpdateUserRolesWin',{
	extend:'Ext.window.Window',
	alias:'widget.updateuserroleswin',
	border:false,
	layout:'fit',
	modal:true,
	autoShow:true,
	closable:false,
	width:360,
	title:'修改用户系统/角色',
	initComponent:function(){
		var me=this;
		//me.checkAllLabel=false的时候，不经过change时间的全选和全不选，说明是操作全选之外的其他item
		// me.checkAllLabel=true;
		// function changeAllCheck(obj,isChecked){
		// 	var array = obj.up("checkboxgroup").items;
		// 	if(isChecked){
		// 		//全选
		// 			array.each(function(item){  
		// 				item.setValue(true);  
		// 			});  
		// 	}else{
		// 		//全不选
		// 			array.each(function(item){  
		// 				item.setValue(false); 
		// 		}); 
		// 	}
		//  }
		me.items=[{
			xtype:'form',
			margins:"5,5,5,5",
			width:'100%',
			height:'100%',
			defaults:{
				width:330,
				padding:'5 0 0 5'
			},
			listeners:{ 
				afterrender:function(form){
					form.loadRecord(me.dataRecord);
				},
			},
			items:[{
            	xtype:'hidden',
				name:'id'
			},{
				xtype:'textfield',
				name:"name",
				fieldLabel:"账号名称",
				readOnly:true,
				submitValue:false,
			},{
				xtype:'checkboxgroup',
				fieldLabel:"所属系统",
				id:'updateuserrolseswin_systems',
				submitValue:false,
				columns:2,
				items:[
					// {
					// 	boxLabel: '全选' ,
					// 	checked:false,
					// 	id:'updateUserRolesWin_allcheck',
					// 	inputValue:0,
					// 	// listeners:{  
					// 	// 	'change':function(obj,isChecked){
					// 	// 				if(me.checkAllLabel){										
					// 	// 					changeAllCheck(obj,isChecked);
					// 	// 				}
					// 	// 		}  
					// 	// 	} 
					// }
				],
				listeners:{
					afterrender:function(checkboxgroup){
						Ext.Ajax.request({
							url : window.url+'/safe/syss/getSystems',
							method : 'GET',
							success : function(response, options) {
								var result=JSON.parse(response.responseText);
								result=result.result;
								var checkboxgroup = Ext.getCmp("updateuserrolseswin_systems");
								for (var i = 0; i < result.length; i++) {
									var checkbox = new Ext.form.Checkbox(
									  {
										  boxLabel: result[i].name,
										  name: result[i].id,
										  inputValue: result[i].id,   
										  checked: false,
										  listeners:{
											   afterrender:function(cb){
												   var checkSystems=me.dataRecord.get('systems');
													if(checkSystems.length>0){
														for(var i in checkSystems){
															if(checkSystems[i].id==cb.inputValue){
																cb.setValue(true);
															}
														}
													}
													// if(checkSystems.length==2){
													// 	Ext.getCmp('updateUserRolesWin_allcheck').setValue(true);
													// }
											   },
											   change:function(cb){
												  	// if(cb.getValue()==false){
													// 	me.checkAllLabel=false;
													// 	Ext.getCmp('updateUserRolesWin_allcheck').setValue(false);	
													// 	me.checkAllLabel=true;													
													// }													
													var systemsValue=Ext.getCmp('updateuserrolseswin_systems').getChecked();
													me.systemArr=[];  
													var isAllCheck=false; 
													//result.length=2,当systemsValue=2的时候，全选按钮要选上
													for(var i in systemsValue){
														if(systemsValue.length==result.length){
															isAllCheck=true;
														}
														me.systemArr.push(systemsValue[i].inputValue);
													}
													// if(isAllCheck==true){
													// 	Ext.getCmp('updateUserRolesWin_allcheck').setValue(true);
													// 	// me.systemArr.push(0);
													// }
													me.systemStr=me.systemArr.join(',');
													Ext.getStore('safe.GetRolesStore').proxy.extraParams.systemIds=me.systemStr;
													Ext.getStore('safe.GetRolesStore').load();
													Ext.getCmp('safe_updateuserroles_select').setValue('');
													// 提交的数据形式，需要问下丘晓锋
													Ext.getCmp('safe_updateuserroles_systems').setValue(me.systemStr);
											  }
										  },
									  });
									checkboxgroup.items.add(checkbox);
								}
								Ext.getCmp("updateuserrolseswin_systems").doLayout(); //重新调整版面布局  
							},
							failure : function() {
								Ext.Msg.alert("提示", "删除失败！");
							}
						});
					}
				}
		},{
			xtype:'hidden',
			id:'safe_updateuserroles_systems',
			name:"systemIds",
		},{
			xtype:'combobox',
			id:'safe_updateuserroles_select',
			fieldLabel:'角色',
			emptyText:'角色',
			value:[],
			valueField:'id',
			displayField:'name',
			store:'safe.GetRolesStore',
			multiSelect:true,
			editable:false,
			allowBlank:true,
			submitValue:false,
			listeners:{
				afterrender:function(combo){
					var comboRoles=me.dataRecord.get('roles');
					if(comboRoles.length>0){
						var idList=[];
						for(var i in comboRoles){
							idList.push(comboRoles[i].id);
						}
						combo.setValue(idList);
					}
					Ext.getCmp('safe_updateuserroles_roles').setValue(combo.getValue());
				},
				change:function(combo){
					//需要从邱晓峰那里知道传参格式
					Ext.getCmp('safe_updateuserroles_roles').setValue(combo.getValue());
				}
			}
		},{
			xtype:'hidden',
			id:'safe_updateuserroles_roles',
			name:"roleIds",
			}]
		}];
		me.buttonAlign='center',
		me.buttons=[{
			text:'保存',
			width:150,
			height:22,
			padding:'0',
			margins:'0',
			border:false,
			handler:function(btn){
				var f=btn.up('window').down('form');
				var json=f.getValues();
				Ext.Ajax.request({
	    			url:window.url+'/safe/user/updateRoleAndSystem',
	    			// params:{
	    			// 	id:me.dataRecord.get('id'),
					// },
					params:{
						'id':json.id,
						'systemIds':json.systemIds,
						'roleIds':json.roleIds,
					},
	    			success:function(response,option){
	    				var result=Ext.JSON.decode(response.responseText);
	    				if(result.success){
	    					f.up('window').close();
	    					Ext.getCmp('safe_userGridBar').doRefresh();
	    					Ext.getCmp('safe_userGrid').getSelectionModel().deselectAll();
	    				}else{
							alert(result.msg);
						}
	    			}
	    		});
			}
		},{
			text:'关闭',
			width:150,
			height:22,
			padding:'0',
			margins:'0',
			border:false,
			scope:this,
			handler:this.close
		}]
		this.callParent(arguments);
	}
});