Ext.define('Mvc.view.Viewport',{
	extend:'Ext.container.Viewport',
	layout:'border',
	initComponent:function(){
		var me=this;
		me.items=[{
//			region:'west',
//          xtype:'leftmenu'
//		},{
			region:'center',
			layout:'border',
			border:false,
			//bodyCls:'panelBodyCls2',
			//baseCls:'panelBodyColorCls1',
			flex:5,
			items:[{
				region:'center',
				xtype:'maintab',
				border:false,
				flex:1
			}]
		},{
            title : 'West Region is collapsible',
            region : 'west',
            xtype : 'panel',
            width : 180,
            collapsible : true, // 设置可折叠
            id : 'west-region-container',
            layout : 'fit',
            margins : '0 0 0 0',
            layout : 'accordion',
            title : '菜单',
            split : true,
            collapsible : true,
            layoutConfig : {
                animate : true
            },     
            items : [{
                    title : '系统设置',
                    xtype : 'treepanel',
                    expanded : true,
                    animate : true,
                    enableDD : false,
                    border : false,
                    containerScroll : true,
                    rootVisible:false,
                    id:'root2',
                    root:{
                    	children : [{
                                text : '用户设置',
                                action:"openUserPanel",
                                // id : 'outsideweekplan.html',
                                leaf : true,
                            // }, {
                            //     text : '用户组设置',
                            //     action:"openGroupPanel",
                            //     leaf : true,
                            }, {
                                text : '部门设置',
                                action:"openDepartmentPanel",
								leaf : true,
							}, {
                                text : '角色设置',
                                action:"openRolesPanel",
								leaf : true,
							}, {
                                text : '字典配置',
                                action:"openDictionaryPanel",
                                leaf : true,
                            }]
                    }
                }]
		},{
			region:'north',
			xtype:'toolbar',
			id:'titleToolbar',
			width:'100%',
			height:50,
			split: false,
            border:false,
			items:[{
				xtype:"imagecomponent",
				height:22,
				padding:'0 0 0 5',
				src:'res/icons/logo.png'
			},"->",{
                text:'当前版本:v1.0.0',
            },{ 
                text:sessionStorage.omcLoginName?'hello,'+sessionStorage.omcLoginName+'!':'hello，请重新登录！',
    //         },{
				// // text:'网元和监控',
				// text:'周计划',
				// width:150,
				// height:32,
				// menu:{
				// 	xtype:'menu',
		  //           plain:true,
		  //           id:'functionMenu1',
		  //           items:[]
				// }
			// },{
			// 	// text:'告警和设置',
			// 	width:150,
			// 	height:32,
			// 	menu:{
			// 		xtype:'menu',
		 //            plain:true,
		 //            id:'functionMenu2',
		 //            items:[]
			// 	}
			// },{
			// 	text:'系统和日志',
			// 	width:150,
			// 	height:32,
			// 	menu:{
			// 		xtype:'menu',
		 //            plain:true,
		 //            id:'functionMenu3',
		 //            items:[]
			// 	}
			},{
				text:'用户操作',
				width:150,
				height:32,
				menu:{
					xtype:'menu',
		            plain:true,
		            items:[{
						text:'个人信息',
						iconCls:'user_edit',
						handler:function(btn){
                            Ext.widget('updateuserinfowin',{

							});
						}
					},{
						text:'重置密码',
						iconCls:'password',
						handler:function(btn){
                            Ext.widget('resetpasswordwin2');
						}
					// },{
     //                    text:'锁屏',
     //                    iconCls:'lock',
     //                    handler:function(btn){
     //                        Ext.Ajax.request({
     //                            url:'safe/user/logout',
     //                            success:function(response ,option){
     //                                Ext.widget('LockScreen',{
     //                                    title:'锁屏中，请输入用户名和密码解锁'
     //                                })
					// 				lockScreenFlag=true;
     //                            }
     //                        });
     //                    }
                    },{
						text: '注销',
						iconCls:'signout',
						handler:function(btn){
							Ext.Ajax.request({  
								url:window.url+'/safe/user/logout',
								success:function(response ,option){
									goToLogin();
								}
							});
						}
		            // },{
              //           text: '帮助',
              //           iconCls:'help',
              //           handler:function(btn){
              //               window.open("help/help_index.html","帮助文档","");
              //           }
                    }]
				}
			}]
		}],
		this.callParent(arguments);
	}
});
