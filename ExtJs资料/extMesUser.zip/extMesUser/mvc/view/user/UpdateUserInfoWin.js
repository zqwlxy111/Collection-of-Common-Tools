Ext.define('Mvc.view.user.UpdateUserInfoWin',{
	extend:'Ext.window.Window',
	alias:'widget.updateuserinfowin',
	border:false,
	layout:'fit',
	modal:true,
	autoShow:true,
	closable:false,
	width:360,
	title:'修改用户信息',
	initComponent:function(){
		var me=this;
		me.items=[{
			xtype:'form',
			margins:"5,5,5,5",
			width:'100%',
			height:'100%',
			defaults:{
				width:330,
				padding:'5 0 0 5'
			},
			listeners:{ 
				afterrender:function(form){
                    Ext.Ajax.request({
                        url:window.url+'/safe/user/getUserExByToken',
                        success:function(response,option){
                            var result=Ext.JSON.decode(response.responseText);
                            Ext.getCmp('updateUserInfo_id').setValue(result.id);
                            Ext.getCmp('updateUserInfo_userName').setValue(result.username);
                            Ext.getCmp('updateUserInfo_realName').setValue(result.realName);
                            Ext.getCmp('updateUserInfo_tel').setValue(result.tel);
                            Ext.getCmp('updateUserInfo_email').setValue(result.email);
                            // Ext.getCmp('updateUserInfo_department').setValue(result.departmentString);
                        }
                    });
				},
			},
			items:[{
            	xtype:'hidden',
				name:'id',
                id:'updateUserInfo_id'
			},{
				xtype:'textfield',
				name:"userName",
				fieldLabel:"账号名称",
				emptyText:'账号名称',
				allowBlank:false,
				emptyCls:'textfield-emptyCls',
				enforceMaxLength:45,
				maxLength:45,
				blankText:'请输入账号名称',
				id:'updateUserInfo_userName'
			},{
				xtype:'textfield',
				name:"realName",
				fieldLabel:"用户姓名",
				emptyText:'用户姓名',
				allowBlank:true,
				emptyCls:'textfield-emptyCls',
				enforceMaxLength:30,
				maxLength:30,
				blankText:'请输入用户姓名',
                id:'updateUserInfo_realName'
			},{
				xtype:'textfield',
				name:"tel",
				fieldLabel:"电话",
				emptyText:'电话',
				allowBlank:true,
				emptyCls:'textfield-emptyCls',
				enforceMaxLength:20,
				maxLength:20,
				blankText:'请输入电话',
				regex:/^[0-9-()]{8,20}$/,
                regexText:'请输入正确的电话',
                id:'updateUserInfo_tel'
			},{
				xtype:'textfield',
				name:"email",
				fieldLabel:"邮箱",
				emptyText:'邮箱',
				allowBlank:true,
				emptyCls:'textfield-emptyCls',
				enforceMaxLength:45,
				maxLength:45,
				blankText:'请输入邮箱',
                id:'updateUserInfo_email'
			// },{
			// 	xtype:'textfield',
			// 	name:"department",
			// 	fieldLabel:"部门",
			// 	allowBlank:true,
			// 	emptyText:'部门',
			// 	emptyCls:'textfield-emptyCls',
			// 	enforceMaxLength:45,
			// 	maxLength:45,
			// 	blankText:'请输入部门',
   //              id:'updateUserInfo_department'
			}]
		}];
		me.buttonAlign='center',
		me.buttons=[{
			text:'保存',
			width:150,
			height:22,
			padding:'0',
			margins:'0',
			border:false,
			handler:function(btn){
				var f=btn.up('window').down('form');
				if(f && f.isValid()){
					Ext.Ajax.request({
		    			url:window.url+'/safe/user/updateUserInfo',
		    			headers:{'Content-Type':'application/json'},
		    			params:JSON.stringify(f.getValues()),
		    			success:function(response,option){
		    				var result=Ext.JSON.decode(response.responseText);
		    				if(result.success){
		    					// sessionStorage.omcToken=result.token;
		    					// Ext.Ajax.defaultHeaders={'token':sessionStorage.omcToken};
		    					f.up('window').close();
		    					window.location.href="login.html";
		    				}else
		    					alert(result.msg);
		    			}
		    		});
				}
			}
		},{
			text:'关闭',
			width:150,
			height:22,
			padding:'0',
			margins:'0',
			border:false,
			scope:this,
			handler:this.close
		}]
		this.callParent(arguments);
	}
});