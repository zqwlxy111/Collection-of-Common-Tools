Ext.define('Mvc.view.main.FirstPage',{
	extend:'Ext.panel.Panel',
	alias:'widget.firstpage',
	layout:'border',
	split:true,
	autoShow:true,
	maxinizable:true,
	closeAction:'close',
	config:{
	},
	initComponent:function(){
		var me = this;
        me.getOutWeekPlanListStore=Ext.getStore('plan.GetOutWeekPlanListStore').load();
		// var rightClick=new Ext.menu.Menu({
		//     items:[{
		// 		text:'刷新', 
		// 		handler:function(btn){
		// 			me.down('treepanel').store.load();
		// 		}
		// 	},{
  //               text:'新增',
  //               handler:function(btn){
  //                   var sel=me.down('treepanel').getSelectionModel().getSelection();
  //                   Ext.widget('addareawin',{ });

  //               }
		//     }]
  //   	});
		this.items=[
			// Ext.widget("panel",{
			// 	region:'east',
			// 	width:300,
   //              height:'100%',
			// 	layout:'vbox',
			// 	collapsible:true,
			//     animCollapse:true,
			//     split:true,
			// 	items:[{
			// 		xtype:'panel',
			// 		flex:1,
   //                  width:300,
			// 		title:'当前设备状态',
			// 		layout:'fit',
			// 		items:[{
			// 			xtype:'workstatuspiechart',
			// 			chartStore:Ext.getStore('main.WorkStatusStore'),
			// 			flex:1,
			// 			chartItemclickFun:function(item){
		 //            		console.log(item);
		 //            	}  
			// 		}]
			// 	},{
			// 		xtype:'panel',
			// 		flex:1,
   //                  width:300,
			// 		title:'当前告警状态',
			// 		layout:'fit',
			// 		items:[{
			// 			xtype:'monitorstatuspiechart',
			// 			chartStore:Ext.getStore('main.MonitorStatusStore'),
			// 			flex:1,
			// 			chartItemclickFun:function(item){
		 //            		console.log(item);
		 //            	} 
			// 		}]
			// 	},{
			// 		xtype:'grid',
			// 		title:'最新告警情况',
			// 		flex:1,
   //                  width:300,
			// 		stripeRows:true,
			// 	    columnLines:true,
			// 		store:Ext.getStore('main.CurAlarmStore'),
			// 		hideHeaders:true,
			// 		columns:[{
			// 			header:'参数名称',dataIndex:'name',flex:1,align:'center'
			// 		},{
			// 			header:'参数值',dataIndex:'value',flex:2,align:'center'
			// 		}]
			// 	}]
			// }),
			Ext.widget("panel",{
				region:'center',
                height:'100%',
                layout:'fit',
				flex:1,
                items:[{
				    xtype:'grid',
                    // id:'monitor_deviceListGrid',
                    id:'plan_OutWeekPlanListGrid',
                    // tbar:[{
                    //     xtype:'textfield',
                    //     emptyText:'订单号',
                    //     },{
                    //     xtype:'textfield',
                    //     emptyText:'订单类型',
                    //     },{
                    //     xtype:'textfield',
                    //     emptyText:'机芯',
                    //     },{
                    //     xtype:'textfield',
                    //     emptyText:'机型',
                    //     },{
                    //     xtype:'textfield',
                    //     emptyText:'国家',
                    //     },{
                    //     xtype:'textfield',
                    //     emptyText:'品牌',
                    //     },{
                    //     xtype:'datefield',
                    //     emptyText:'出货开始时间',
                    //     },'~',{
                    //     xtype:'datefield',
                    //     emptyText:'出货结束时间',
                    //     },{
                    //     xtype:'datefield',
                    //     emptyText:'量产开始时间',
                    //     },'~',{
                    //     xtype:'datefield',
                    //     emptyText:'量产结束时间',
                    //     // emptyCls:'textfield-emptyCls',
                    //     // enforceMaxLength:11,
                    //     // maxLength:11,
                    //     // regex:/^\d{0,11}$/,
                    //     // regexText:'请输入正确格式的直放站编号',
                    //     // listeners:{
                    //     //     change:function(tf,nv,ov){
                    //     //         me.getDeviceExListStore.proxy.extraParams.repeaterId=(nv==""?0:nv);
                    //     //         me.getDeviceExListStore.load();
                    //     //     }
                    //     // }
                        
                    //     // xtype:'combo',
                    //     // allowBlank:true,
                    //     // emptyText:'地区过滤',
                    //     // valueField:'id',
                    //     // displayField:'name',
                    //     // hiddenName:'name',
                    //     // store:Ext.getStore('node.GetAreasLikeNameStore'),
                    //     // forceSelection:false,
                    //     // hideTrigger:true,
                    //     // typeAhead:true,
                    //     // minChars:1,
                    //     // triggerAction:'all',
                    //     // queryMode:'remote',
                    //     // queryParam:'name',
                    //     // listeners:{
                    //     //     select:function(combo){
                    //     //         var v=combo.lastSelection[0];
                    //     //         me.getDeviceExListStore.proxy.extraParams.areaId=v.get('id');
                    //     //         me.getDeviceExListStore.load();
                    //     //     }
                    //     // }
                    //     // },{
                    //     //     xtype:'textfield',
                    //     //     emptyText:'直放站编号过滤',
                    //     //     emptyCls:'textfield-emptyCls',
                    //     //     enforceMaxLength:11,
                    //     //     maxLength:11,
                    //     //     regex:/^\d{0,11}$/,
                    //     //     regexText:'请输入正确格式的直放站编号',
                    //     //     listeners:{
                    //     //         change:function(tf,nv,ov){
                    //     //             me.getDeviceExListStore.proxy.extraParams.repeaterId=(nv==""?0:nv);
                    //     //             me.getDeviceExListStore.load();
                    //     //         }
                    //     //     }
                    //     // },{
                    //     //     xtype:'textfield',
                    //     //     emptyText:'设备名称过滤',
                    //     //     emptyCls:'textfield-emptyCls',
                    //     //     enforceMaxLength:45,
                    //     //     maxLength:45,
                    //     //     listeners:{
                    //     //         change:function(tf,nv,ov){
                    //     //             me.getDeviceExListStore.proxy.extraParams.name=nv
                    //     //             me.getDeviceExListStore.load();
                    //     //         }
                    //     //     }
                    //     // },{
                    //     //     xtype:'textfield',
                    //     //     emptyText:'设备类型过滤',
                    //     //     emptyCls:'textfield-emptyCls',
                    //     //     enforceMaxLength:45,
                    //     //     maxLength:45,
                    //     //     listeners:{
                    //     //         change:function(tf,nv,ov){
                    //     //             me.getDeviceExListStore.proxy.extraParams.productType=nv
                    //     //             me.getDeviceExListStore.load();
                    //     //         }
                    //     //     }
                    //     },"->",{
                    //         text:'导入',
                    //         listeners:{
                    //             // click:function(btn){
                    //             //     var sel=Ext.getCmp('monitor_deviceListGrid').getSelectionModel().getSelection();
                    //             //     if(sel.length == 0){
                    //             //         alert('请选择至少一个设备!');
                    //             //     }else{
                    //             //         var tabId="tab_monitorPanel";
                    //             //         addTab(Ext.getCmp('mainTab'),tabId,
                    //             //             {id:tabId,title:'设备监控',xtype:'monitorpanel',closable:true});

                    //             //         var monitorId='tab_monitor_'+sel[0].get('id');
                    //             //         addTab(Ext.getCmp('monitor_tabPanel'),monitorId,{
                    //             //             id:monitorId,
                    //             //             title:sel[0].get('name'),
                    //             //             xtype:'deviceparampanel',
                    //             //             device:sel[0],
                    //             //             closable:true
                    //             //         });
                    //             //     }
                    //             // }
                    //         }
                    //         // action:'monitorAction'
                    //     },{
                    //         text:'导出Excel',
                    //         listeners:{
                    //             click:function(btn){
                    //                 Ext.MessageBox.confirm('请确认','确定要导出excel吗?', function(btn){
                    //                     if(btn=='yes'){
                    //                         var store=Ext.getStore('monitor.GetDeviceExListStore');
                    //                         window.open('monitor/monitor/exportDevicesInExcel'+
                    //                             '?areaId='+store.proxy.extraParams.areaId+
                    //                             '&repeaterId='+store.proxy.extraParams.repeaterId+
                    //                             '&name='+store.proxy.extraParams.name+
                    //                             '&areaName='+store.proxy.extraParams.areaName+
                    //                             '&token='+sessionStorage.omcToken);
                    //                     }
                    //                 });
                    //             }
                    //         }
                    //         // action:'exportExcelAction'
                    //     },{
                    //         text:'新增订单',
                    //         listeners:{
                    //             // click:function(btn){
                    //             //     Ext.widget('batchsettingwin',{
                    //             //         title:'批量设置参数'
                    //             //     });
                    //             // }
                    //         }
                    //     },{
                    //         text:'删除订单',
                    //         listeners:{
                    //             // click:function(btn){
                    //             //     Ext.widget('batchsettingwin',{
                    //             //         title:'批量设置参数'
                    //             //     });
                    //             // }
                    //         }
                    //     },{
                    //         text:'缺料分析',
                    //         listeners:{
                    //             // click:function(btn){
                    //             //     Ext.widget('batchsettingwin',{
                    //             //         title:'批量设置参数'
                    //             //     });
                    //             // }
                    //         }
                    //     // action:'batchSettingAction'
                    // }],
                    tbar:{
                        xtype:"container",
                        border:false,
                        items:[{
                             //tbar第一行工具栏
                            xtype:"toolbar",
                            border:false,
                            items:[{
                                    xtype:'textfield',
                                    emptyText:'订单号',
                                    maxLength:20,
                                    listeners:{
                                            change:function(ts,nv,ov){
                                                var json=JSON.parse(me.getOutWeekPlanListStore.proxy.extraParams.filterRules);
                                                json.id=((nv==null || nv=='')?null:nv);
                                                me.getOutWeekPlanListStore.proxy.extraParams.filterRules=JSON.stringify(json);
                                                me.getOutWeekPlanListStore.load();
                                            }
                                    }
                                },{
                                    xtype:'textfield',
                                    emptyText:'订单类型',
                                    listeners:{
                                            change:function(ts,nv,ov){
                                                var json=JSON.parse(me.getOutWeekPlanListStore.proxy.extraParams.filterRules);
                                                json.orderType=((nv==null || nv=='')?null:nv);
                                                me.getOutWeekPlanListStore.proxy.extraParams.filterRules=JSON.stringify(json);
                                                me.getOutWeekPlanListStore.load();
                                            }
                                    }
                                },{
                                    xtype:'textfield',
                                    emptyText:'机芯',
                                    listeners:{
                                            change:function(ts,nv,ov){
                                                var json=JSON.parse(me.getOutWeekPlanListStore.proxy.extraParams.filterRules);
                                                json.module=((nv==null || nv=='')?null:nv);
                                                me.getOutWeekPlanListStore.proxy.extraParams.filterRules=JSON.stringify(json);
                                                me.getOutWeekPlanListStore.load();
                                            }
                                    }
                                },{
                                    xtype:'textfield',
                                    emptyText:'机型',
                                    listeners:{
                                            change:function(ts,nv,ov){
                                                var json=JSON.parse(me.getOutWeekPlanListStore.proxy.extraParams.filterRules);
                                                json.type=((nv==null || nv=='')?null:nv);
                                                me.getOutWeekPlanListStore.proxy.extraParams.filterRules=JSON.stringify(json);
                                                me.getOutWeekPlanListStore.load();
                                            }
                                    }
                                },{
                                    xtype:'textfield',
                                    emptyText:'国家',
                                    listeners:{
                                            change:function(ts,nv,ov){
                                                var json=JSON.parse(me.getOutWeekPlanListStore.proxy.extraParams.filterRules);
                                                json.country=((nv==null || nv=='')?null:nv);
                                                me.getOutWeekPlanListStore.proxy.extraParams.filterRules=JSON.stringify(json);
                                                me.getOutWeekPlanListStore.load();
                                            }
                                    }
                                },{
                                    xtype:'textfield',
                                    emptyText:'品牌',
                                    listeners:{
                                            change:function(ts,nv,ov){
                                                var json=JSON.parse(me.getOutWeekPlanListStore.proxy.extraParams.filterRules);
                                                json.brank=((nv==null || nv=='')?null:nv);
                                                me.getOutWeekPlanListStore.proxy.extraParams.filterRules=JSON.stringify(json);
                                                me.getOutWeekPlanListStore.load();
                                            }
                                    }         
                                // emptyCls:'textfield-emptyCls',
                                // enforceMaxLength:11,
                                // maxLength:11,
                                // regex:/^\d{0,11}$/,
                                // regexText:'请输入正确格式的直放站编号',
                                // listeners:{
                                //     change:function(tf,nv,ov){
                                //         me.getDeviceExListStore.proxy.extraParams.repeaterId=(nv==""?0:nv);
                                //         me.getDeviceExListStore.load();
                                //     }
                                // }
                                
                                // xtype:'combo',
                                // allowBlank:true,
                                // emptyText:'地区过滤',
                                // valueField:'id',
                                // displayField:'name',
                                // hiddenName:'name',
                                // store:Ext.getStore('node.GetAreasLikeNameStore'),
                                // forceSelection:false,
                                // hideTrigger:true,
                                // typeAhead:true,
                                // minChars:1,
                                // triggerAction:'all',
                                // queryMode:'remote',
                                // queryParam:'name',
                                // listeners:{
                                //     select:function(combo){
                                //         var v=combo.lastSelection[0];
                                //         me.getDeviceExListStore.proxy.extraParams.areaId=v.get('id');
                                //         me.getDeviceExListStore.load();
                                //     }
                                // }
                                // },{
                                //     xtype:'textfield',
                                //     emptyText:'直放站编号过滤',
                                //     emptyCls:'textfield-emptyCls',
                                //     enforceMaxLength:11,
                                //     maxLength:11,
                                //     regex:/^\d{0,11}$/,
                                //     regexText:'请输入正确格式的直放站编号',
                                //     listeners:{
                                //         change:function(tf,nv,ov){
                                //             me.getDeviceExListStore.proxy.extraParams.repeaterId=(nv==""?0:nv);
                                //             me.getDeviceExListStore.load();
                                //         }
                                //     }
                                // },{
                                //     xtype:'textfield',
                                //     emptyText:'设备名称过滤',
                                //     emptyCls:'textfield-emptyCls',
                                //     enforceMaxLength:45,
                                //     maxLength:45,
                                //     listeners:{
                                //         change:function(tf,nv,ov){
                                //             me.getDeviceExListStore.proxy.extraParams.name=nv
                                //             me.getDeviceExListStore.load();
                                //         }
                                //     }
                                // },{
                                //     xtype:'textfield',
                                //     emptyText:'设备类型过滤',
                                //     emptyCls:'textfield-emptyCls',
                                //     enforceMaxLength:45,
                                //     maxLength:45,
                                //     listeners:{
                                //         change:function(tf,nv,ov){
                                //             me.getDeviceExListStore.proxy.extraParams.productType=nv
                                //             me.getDeviceExListStore.load();
                                //         }
                                //     }
                                },"->",{
                                    text:'导入',
                                    // html:'<input type="file" style="opacity:0;width:100%;height:100%;position:absolute;top:0;left:0;cursor:pointer;z-index:10" />',
                                    listeners:{
                                        click:function(btn){
                                            Ext.widget('weekplanuploadwin',{}) 
                                        }                           
                                    }
                                    // action:'monitorAction'
                                },{
                                    text:'导出Excel',
                                    listeners:{
                                        click:function(btn){
                                            Ext.MessageBox.confirm('请确认','确定要导出excel吗?', function(btn){
                                                if(btn=='yes'){
                                                    var store=Ext.getStore('monitor.GetDeviceExListStore');
                                                    window.open('monitor/monitor/exportDevicesInExcel'+
                                                        '?areaId='+store.proxy.extraParams.areaId+
                                                        '&repeaterId='+store.proxy.extraParams.repeaterId+
                                                        '&name='+store.proxy.extraParams.name+
                                                        '&areaName='+store.proxy.extraParams.areaName+
                                                        '&token='+sessionStorage.omcToken);
                                                }
                                            });
                                        }
                                    }
                                },{
                                    text:'新增订单',
                                    listeners:{
                                        click:function(btn){
                                           Ext.widget('addweekplanwin',{}) 
                                        }
                                    }
                                },{
                                    text:'删除订单',
                                    listeners:{
                                        click:function(btn){
                                            var sel=Ext.getCmp('plan_OutWeekPlanListGrid').getSelectionModel().getSelection();
                                            if(sel.length == 0){
                                                alert('请选择一个用户!');
                                            }else{
                                                Ext.MessageBox.confirm("请确认","所选的订单["+sel[0].get('id')+"]将会被删除，确认继续?",function(btn1){
                                                    if(btn1=='yes'){
                                                        Ext.Ajax.request({  
                                                            url:window.url1+'/owpWeekPlan/delete',
                                                            params:{id:sel[0].get('id')},
                                                            success:function(response,option){
                                                                var result=Ext.JSON.decode(response.responseText);
                                                                if(result.success)
                                                                    Ext.getCmp('plan_OutWeekPlanListGridBar').doRefresh();
                                                                else
                                                                    alert(result.msg);
                                                            }
                                                        });
                                                }});
                                            }
                                        }
                                    }
                                },{
                                    text:'缺料分析',
                                    listeners:{
                                        // click:function(btn){
                                        //     Ext.widget('batchsettingwin',{
                                        //         title:'批量设置参数'
                                        //     });
                                        // }
                                    }
                                // action:'batchSettingAction'
                            }]
                        },{
                             //tbar第二行工具栏
                            xtype:"toolbar",
                            border:false,
                            items:['出货时间:',
                                {  
                                    xtype:'datefield',
                                    emptyText:'出货开始时间',
                                    listeners:{
                                            change:function(ts,nv,ov){
                                                if(nv!=null || nv!=''){
                                                    nv=Ext.util.Format.date(nv,'Y-m-d');
                                                }
                                                var json=JSON.parse(me.getOutWeekPlanListStore.proxy.extraParams.filterRules);
                                                json.dtsd=((nv==null || nv=='')?null:nv);
                                                me.getOutWeekPlanListStore.proxy.extraParams.filterRules=JSON.stringify(json);
                                                me.getOutWeekPlanListStore.load();
                                            }
                                    }
                                },'~',{
                                    xtype:'datefield',
                                    emptyText:'出货结束时间',
                                    listeners:{
                                            change:function(ts,nv,ov){
                                                if(nv!=null || nv!=''){
                                                    nv=Ext.util.Format.date(nv,'Y-m-d');
                                                }
                                                var json=JSON.parse(me.getOutWeekPlanListStore.proxy.extraParams.filterRules);
                                                json.dted=((nv==null || nv=='')?null:nv);
                                                me.getOutWeekPlanListStore.proxy.extraParams.filterRules=JSON.stringify(json);
                                                me.getOutWeekPlanListStore.load();
                                            }
                                    }
                                },'量产时间:',{
                                    xtype:'datefield',
                                    emptyText:'量产开始时间',
                                    listeners:{
                                            change:function(ts,nv,ov){
                                                if(nv!=null || nv!=''){
                                                    nv=Ext.util.Format.date(nv,'Y-m-d');
                                                }
                                                var json=JSON.parse(me.getOutWeekPlanListStore.proxy.extraParams.filterRules);
                                                json.ctsd=((nv==null || nv=='')?null:nv);
                                                me.getOutWeekPlanListStore.proxy.extraParams.filterRules=JSON.stringify(json);
                                                me.getOutWeekPlanListStore.load();
                                            }
                                    }
                                },'~',{
                                    xtype:'datefield',
                                    emptyText:'量产结束时间',
                                    listeners:{
                                            change:function(ts,nv,ov){
                                                if(nv!=null || nv!=''){
                                                    nv=Ext.util.Format.date(nv,'Y-m-d');
                                                }
                                                var json=JSON.parse(me.getOutWeekPlanListStore.proxy.extraParams.filterRules);
                                                json.cted=((nv==null || nv=='') ?null:nv);
                                                me.getOutWeekPlanListStore.proxy.extraParams.filterRules=JSON.stringify(json);
                                                me.getOutWeekPlanListStore.load();
                                            }
                                    }
                                // },'->',{
                                //     'text':'清空查询',
                                //     'iconCls':'close',
                                //     listeners:{
                                //         click:function(btn){
                                //             var defaultQueryData={id:null,module:null,country:null,dtsd:null,ctsd:null,orderType:null,type:null,brank:null,dted:null,cted:null}
                                //             me.getOutWeekPlanListStore.proxy.extraParams.filterRules=JSON.stringify(defaultQueryData);
                                //             me.getOutWeekPlanListStore.load();

                                //         }
                                //     }
                            }]
                        }]


                        },
                    store:me.getOutWeekPlanListStore,
                    columnLines:true,
                    stripeRows:true,
                    columns:{
                        defaults: {
                            align:'center'
                        },
                        items:[{
                            header:'销售订单号',dataIndex:'id',width:100,
                            // editor: {
                            //         xtype: 'textfield',
                            //         allowBlank: false,
                            //         readOnly:true,
                            //     }
                        },{
                            header:'计划月',dataIndex:'planMonth',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'销单创建时间',dataIndex:'createTime',width:100,
                                renderer: Ext.util.Format.dateRenderer('Y-m-d'),
                                editor: {
                                    xtype: 'datefield',
                                    allowBlank: false,
                                    // format:'Y-m-d',
                                }
                        },{
                            header:'一次评审时间',dataIndex:'reviewTime',width:100,
                                renderer: Ext.util.Format.dateRenderer('Y-m-d'),
                                editor: {
                                    xtype: 'datefield',
                                    allowBlank: false
                                }
                        },{
                            header:'货品形式',dataIndex:'hpxs',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'周次',dataIndex:'planWeek',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'订单类型',dataIndex:'orderType',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'配屏编码',dataIndex:'screen',width:150,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'玻璃编码',dataIndex:'glass',width:150,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'pid',dataIndex:'pid',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'机芯',dataIndex:'module',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'机型',dataIndex:'type',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'订单量',dataIndex:'orderQuantity',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'未报工数量',dataIndex:'unreportedQuantity',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'未入库数量',dataIndex:'unstorageQuantity',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'品牌',dataIndex:'brank',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'销往国家',dataIndex:'country',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'跟单员',dataIndex:'merchandiser',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'加工方式',dataIndex:'working',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'转工单时间',dataIndex:'transferTime',width:100,
                                renderer: Ext.util.Format.dateRenderer('Y-m-d'),
                                editor: {
                                    xtype: 'datefield',
                                    allowBlank: false
                                }
                        },{
                            header:'出货时间',dataIndex:'deliveryTime',width:100,
                                renderer: Ext.util.Format.dateRenderer('Y-m-d'),
                                editor: {
                                    xtype: 'datefield',
                                    allowBlank: false
                                }
                        },{
                            header:'新品',dataIndex:'newProduct',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'问题点',dataIndex:'problems',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'量产完工时间',dataIndex:'completeTime',width:100,
                                renderer: Ext.util.Format.dateRenderer('Y-m-d'),
                                editor: {
                                    xtype: 'datefield',
                                    allowBlank: false
                                }
                        },{
                            header:'要求软件确认时间',dataIndex:'softConfirmTime',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'软件状态',dataIndex:'softStatus',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'预计释放时间',dataIndex:'softReleaseTime',width:100,
                                renderer: Ext.util.Format.dateRenderer('Y-m-d'),
                                editor: {
                                    xtype: 'datefield',
                                    allowBlank: false
                                }
                        },{
                            header:'软件进度',dataIndex:'softSchedule',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'软件跟进部门',dataIndex:'softGjbm',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'要求美工确认时间',dataIndex:'artistConfirmTime',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'美工状态',dataIndex:'artistStatus',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'美工编号',dataIndex:'artistCode',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:'编号完成时间',dataIndex:'artistCompleteTime',width:100,
                                editor: {
                                    xtype: 'datefield',
                                    allowBlank: false
                                }
                        },{
                            header:'美工资料',dataIndex:'artistInfo',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:"美工跟进部门",dataIndex:'artistGjbm',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:"玻璃1210",dataIndex:'boli',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:"装饰条",dataIndex:'zst',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:"备注",dataIndex:'bak',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:"屏生产",dataIndex:'screenProduction',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        },{
                            header:"屏尺寸",dataIndex:'screenSize',width:100,
                                editor: {
                                    xtype: 'textfield',
                                    allowBlank: false
                                }
                        }]
                    },
                    plugins:[Ext.create('Ext.grid.plugin.CellEditing', {
                        clicksToEdit:1,
                        ptype: 'cellediting',
                        listeners:{
                            edit:function(editor,e,ops){
                                if(e.field=='planMonth' && (parseInt(e.value)==0 || parseInt(e.value)<0 || parseInt(e.value)>12)){
                                    alert('请输入1到12之间的整数');
                                    return false;
                                }
                                var fieldArr=[];
                                var valueArr=[];
                                fieldArr.push(e.field);
                                valueArr.push(e.value);
                                fieldArr.toString();
                                valueArr.toString();
                                Ext.Ajax.request({  
                                    url:window.url1+'/owpWeekPlan/update',
                                    // headers:{'Content-Type':'application/json'},
                                    // params:JSON.stringify(e.record.data),
                                    params:{'id':e.record.data.id,'propertys':fieldArr,'values':valueArr},
                                    success:function(response,option){
                                        var result=Ext.JSON.decode(response.responseText);
                                        if(result.success){
                                            Ext.getCmp('plan_OutWeekPlanListGridBar').doRefresh();
                                        }else
                                            alert(result.msg);
                                    }
                                });
                            }
                        }
                    })],
                    bbar:Ext.create('Ext.PagingToolbar',{
                        store:me.getOutWeekPlanListStore,
                        id:'plan_OutWeekPlanListGridBar',
                        displayInfo:true,
                        displayMsg:'显示{0}-{1}条,共计{2}条',
                        emptyMsg:'没有数据',
                        firstText:'第一页',
                        lastText:'最后一页',
                        afterPageText:'/{0}页',
                        beforePageText:'第',
                        nextText:'下一页',
                        prevText:'上一页',
                        refreshText:'刷新'
                    }),
                    viewConfig:{
                        stripeRows: true,
                        loadMask:{
                            msg :'加载数据中，请稍候...'
                        }}
                }]
			})
		];
		this.callParent(arguments);
	}
});