Ext.define('Mvc.view.main.MonitorStatusPieChart',{
	extend:'Ext.chart.Chart',
	alias:'widget.monitorstatuspiechart',
	width:'100%',
	height:'100%',
//	style:'background:#fff',
//	legend:{
//		position:'right'
//	},
	animate:{
        easing:'bounceOut',
        duration:750
    },
	shadow:false,
	insetPadding: 20,
	theme:'Base:gradients',
	config:{
		unit:'',
	},
	initComponent:function(){
		var me=this;
		me.store=me.chartStore;
        me.series=[{
            type:'pie',
            field:'count',
            showInLegend:true,
            donut:false,
            style:{
            	colors:['#0ee40b','#e6e614','#e97a21','#ff00ff','#ff0000']
            },
            renderer:function(sprite,record,attr,index,store){
                var name=record.get('name');
                var color;
                if(name=='正常'){
                	color = '#0ee40b';
                }else if(name=='四级告警'){
                	color = '#e6e614';
                }else if(name=='三级告警'){
                	color = '#e97a21';
                }else if(name=='二级告警'){
                	color = '#ff00ff';
                }else if(name=='一级告警'){
                	color = '#ff0000';
                }
                return Ext.apply(attr,{
                    fill:color
                });
            },
            listeners:{
            	itemmouseup:me.chartItemclickFun
            },
            tips:{
            	trackMouse:true,
            	width:150,
            	height:20,
            	renderer:function(storeItem,item){
        			var total = 0;
        			me.chartStore.each(function(rec){
        				total += rec.get('count');
        			});
        			this.setTitle(storeItem.get('name')+': '+storeItem.get('count')+me.unit+", 占"+Math.round(storeItem.get('count')/total*100)+'%');
            	}
            },
            highlight:{
            	segment:{
            		margin:10
            	}
            },
            donut:20,
//            label: {
//                field: 'data',
//                display: 'rotate',
//                contrast: true,
//                font: '16px Arial'
//            }
        }];
		this.callParent(arguments);
	}
})