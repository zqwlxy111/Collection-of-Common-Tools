Ext.define('Mvc.view.main.MainTab',{
	extend:'Ext.tab.Panel',
	alias:'widget.maintab',
	id:'mainTab',
	initComponent:function(){
		var me=this;
		// resizeTabs:true;
		// enableTabScroll:true;
		// defaults=[{
		// 	autoScroll:true,
		// 	bodyPadding:10
		// }];
		pages=[];
		pages.push({
			title:'首页',
			xtype:'firstpage',
			closable:false
		});
		me.items=pages;
		// me.on('close',function(ts){
		// 	console.log(ts,'pp')
		// })
		this.callParent(arguments);
	}
});

