Ext.define('Mvc.view.main.WorkStatusPieChart',{
	extend:'Ext.chart.Chart',
	alias:'widget.workstatuspiechart',
	width:'100%',
	height:'100%',
//	style:'background:#fff',
//	legend:{
//		position:'left'
//	},
	animate:{
        easing:'bounceOut',
        duration:750
    },
	shadow:false,
	insetPadding: 20,
	theme:'Base:gradients',
	config:{
		unit:'',
	},
	initComponent:function(){
		var me=this;
		me.store=me.chartStore;
        me.series=[{
            type:'pie',
            field:'count',
            showInLegend:true,
            donut:false,
            renderer:function(sprite,record,attr,index,store){
                var name=record.get('name');
                var color;
                if(name=='在线'){
                	color = '#0ee40b';
                }else if(name=='离线'){
                	color = '#000000';
                }
                return Ext.apply(attr,{
                    fill:color
                });
            },
            listeners:{
            	itemmouseup:me.chartItemclickFun
            },
            tips:{
            	trackMouse:true,
            	width:150,
            	height:20,
            	renderer:function(storeItem,item){
        			var total = 0;
        			me.chartStore.each(function(rec){
        				total += rec.get('count');
        			});
        			this.setTitle(storeItem.get('name')+': '+storeItem.get('count')+me.unit+", 占"+Math.round(storeItem.get('count')/total*100)+'%');
            	}
            },
            highlight:{
            	segment:{
            		margin:10
            	}
            },
            donut:20,
//            label: {
//                field: 'data',
//                display: 'rotate',
//                contrast: true,
//                font: '16px Arial'
//            }
        }];
		this.callParent(arguments);
	}
})