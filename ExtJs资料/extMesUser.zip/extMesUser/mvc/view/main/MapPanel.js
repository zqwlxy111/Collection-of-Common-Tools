Ext.define('Mvc.view.main.MapPanel',{
    extend:'Ext.panel.Panel',
    alias:'widget.mappanel',
    layout:'border',
    autoShow:true,
    maxinizable:true,
    closeAction:'close',
    initComponent:function(){
        var me = this;
        var rightClick=new Ext.menu.Menu({
            items:[{
                text:'刷新',
                handler:function(btn){
                    me.down('treepanel').store.load();
                }
            },{
                text:'新增',
                handler:function(btn){
                    var sel=me.down('treepanel').getSelectionModel().getSelection();
                    Ext.widget('addareawin',{ });

                }
            }]
        });
        this.items=[
            Ext.widget("treepanel",{
                id:'map_areaTree',
                region:'west',
                collapsible:true,
                animCollapse:true,
                split:true,
                width:250,
                rootVisible:false,
                title:'地区',
                tbar:["->",{
                    text:'刷新',
                    handler:function(btn){
                        btn.up('treepanel').store.load()
                    }
                }],
                listeners:{
                    //右键菜单代码
                    itemcontextmenu:function(grid,record,item,index,e){
                        e.preventDefault();
                        rightClick.showAt(e.getXY());
                    }
                },
                store:'node.GetAreaTreeStore'
            }),
            Ext.widget("panel",{
                id:'map_mapContiner',
                region:'center',
                flex:1,
                html:'<div id="oMap"></div>',
                tbar:Ext.widget("toolbar",{
                    region:'north',
                    height:40,
                    items:[{
                        xtype:'checkbox',
                        checked:true,
                        boxLabel:'显示站点',
                        listeners:{
                            change:function(cb,nv,ov){
                                for(var i=0;i<map_sites.values().length;i++){
                                    var f = map_sites.values()[i];
                                    if(nv)
                                        mapUtils.source_cars.addFeature(f);
                                    else
                                        mapUtils.source_cars.removeFeature(f);
                                }
//	    						console.log(map_sites);
//	    						console.log(nv);
                            }
                        }
                    },{
                        xtype:'checkbox',
                        checked:true,
                        boxLabel:'显示基站',
                        listeners:{
                            change:function(cb,nv,ov){

                                for(var i=0;i<map_btses.values().length;i++){
                                    var f = map_btses.values()[i];
                                    if(nv)
                                        mapUtils.source_cars.addFeature(f);
                                    else
                                        mapUtils.source_cars.removeFeature(f);
                                }
                            }
                        }
                    },{
                        xtype:'checkbox',
                        checked:true,
                        boxLabel:'显示设备',
                        listeners:{
                            change:function(cb,nv,ov){
                                for(var i=0;i<map_devices.values().length;i++){
                                    var f = map_devices.values()[i];
                                    if(nv)
                                        mapUtils.source_cars.addFeature(f);
                                    else
                                        mapUtils.source_cars.removeFeature(f);
                                }
                            }
                        }
                    },{
                        xtype:'checkbox',
                        checked:true,
                        boxLabel:'只显示告警设备',
                        listeners:{
                            change:function(cb,nv,ov){
                                for(var i=0;i<map_devices.values().length;i++){
                                    var f = map_devices.values()[i];
                                    if(nv){
                                        if(f.values_.nodeData.data.monitorStatus>0){
                                            mapUtils.source_cars.addFeature(f);
                                        }else{
                                            mapUtils.source_cars.removeFeature(f);
                                        }
                                    }else
                                        mapUtils.source_cars.addFeature(f);
                                }
                            }
                        }
                    },{
                        xtype:'checkbox',
                        checked:false,
                        boxLabel:'显示网络资源关系',
                        listeners:{
                            change:function(cb,nv,ov){

                                if(nv){
                                    var devices = map_devices.values();
                                    var sites = map_sites.values();
                                    var canvas = mapUtils.canvas;

                                    var btses= map_btses.values();
                                    for(var i=0;i<devices.length;i++){
                                        //设备和站点
                                        if(devices[i].get('parentId')==0){
                                            for(var j=0;j<sites.length;j++){
                                                if(sites[j].get('uid')==devices[i].get('siteId')){
                                                    var coords = [];
                                                    coords.push(devices[i].getGeometry().getCoordinates());
                                                    coords.push(sites[j].getGeometry().getCoordinates());
                                                    var lineString = new ol.geom.LineString(coords);
                                                    var f = new ol.Feature(lineString);
                                                    canvas.AppendFeature(f);
                                                    //canvas.DrawGeometry(lineString, true);
                                                    break;
                                                }
                                            }
                                        }else{ //设备和设备
                                            for(var j=0;j<devices.length;j++){
                                                if(devices[j].get('uid')==devices[i].get('parentId')){
                                                    var coords = [];
                                                    coords.push(devices[i].getGeometry().getCoordinates());
                                                    coords.push(devices[j].getGeometry().getCoordinates());
                                                    var lineString = new ol.geom.LineString(coords);
                                                    var f = new ol.Feature(lineString);
                                                    canvas.AppendFeature(f);

                                                    //canvas.DrawGeometry(lineString, false);
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                    //站点和站点

                                    for(var i=0;i<sites.length;i++){
                                        for(var j=0;j<btses.length;j++){
                                            if(btses[j].get('uid')==sites[i].get('btsId')){
                                                var coords = [];
                                                coords.push(sites[i].getGeometry().getCoordinates());
                                                coords.push(btses[j].getGeometry().getCoordinates());
                                                var lineString = new ol.geom.LineString(coords);
                                                var f = new ol.Feature(lineString);
                                                f.set("lineColor","#18a45b");
                                                canvas.AppendFeature(f);
                                                //canvas.DrawGeometry(lineString, false);
                                                break;
                                            }
                                        }
                                    }
                                }else{
                                    mapUtils.canvas.Clear();
                                    /*for(var i=0;i<map_polylines.length;i++){
                                        map.removeOverlay(map_polylines[i]);
                                    }*/
                                }

                            }
                        }
                    }]
                }),
            }),
            Ext.widget("panel",{
                layout:'vbox',
                region:'east',
                collapsible:true,
                animCollapse:true,
                split:true,
                width:250,
                defaults:{
                    xtype:'grid',
                    width:'100%',
                    height:'50%',
                    flex:1,
                    margins:'0 2 0 0',
                    stripeRows:true,
                    columnLines:true,
                },
                items:[{
                    xtype:'grid',
                    id:'map_dataParamList',
                    title:'实时采样',
                    store:Ext.create('Ext.data.Store',{model:'Mvc.model.monitor.ParamModel'}),
                    columns:[{
                        header:'参数名称',
                        dataIndex:'name',
                        flex:1
                    },{
                        header:'参数值',
                        dataIndex:'displayValue',
                        flex:1
//					},{
//						header:'更新时间',
//						dataIndex:'updateTimeString',
//						flex:1
                    }],
                    viewConfig:{
                        loadMask:{
                            msg :'加载数据中，请稍候...'
                        }}
                },{
                    xtype:'grid',
                    id:'map_alarmParamList',
                    title:'告警和状态',
                    store:Ext.create('Ext.data.Store',{model:'Mvc.model.monitor.ParamModel'}),
                    columns:[{
                        header:'参数名称',
                        dataIndex:'name',
                        flex:1
                    },{
                        header:'参数值',
                        dataIndex:'displayValue',
                        flex:1
//					},{
//						header:'更新时间',
//						dataIndex:'updateTimeString',
//						flex:1
                    }],
                    viewConfig:{
                        loadMask:{
                            msg :'加载数据中，请稍候...'
                        }}
                }]
            })
        ];
        this.callParent(arguments);
    }
});