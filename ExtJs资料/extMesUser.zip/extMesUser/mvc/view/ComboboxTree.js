Ext.define('Mvc.view.ComboboxTree',{
	extend: 'Ext.form.ComboBox',
	alias: 'widget.comboboxTree',
	tpl: "<div id='comboboxTreeBox' style='minHeight:10px'/>",
	initComponent: function(){
		var me = this;
// 		me.treeObj.on('itemclick',function(view,rec){
// 			if(rec){
// 					console.log(rec,'11')
// // //				if(rec.get('id').substring(0,rec.get('id').indexOf('_')) == me.allowType){
// 					me.setValue(this._txtValue = rec.get('text'));
// // 					//setRawValue();
// // 					me._idValue = rec.get('id').substring(rec.get('id').indexOf('_')+1);
// // 					me.collapse();
// // //				}
				
// 				// me.setValue(this._txtValue+= rec.get('text'));
// 			}
// 		});
		me.treeObj.on('itemclick',function(view,rec){
			var sel=me.treeObj.getSelectionModel().getSelection();
			var textAll,idAll;
			var iArray=[];
			var tArray=[];	
			var submitArr=[];		
			for(var i in sel){
				iArray.push(sel[i].get('id'));
				tArray.push(sel[i].get('text'));
				submitArr.push({'id':sel[i].get('id'),'name':sel[i].get('text')});
			}
			idAll=iArray.join(',');
			textAll=tArray.join(',');
			me.setValue(me._txtValue = textAll);
			if(Ext.getCmp('safe_addUser_departmentId')){
				// Ext.getCmp('safe_addUser_departmentId').setValue(idAll);
				Ext.getCmp('safe_addUser_departmentId').value=submitArr;
			}
			if(Ext.getCmp('safe_updateUser_departments')){
				Ext.getCmp('safe_updateUser_departments').value1=submitArr;
			}			
		})
		me.on('expand',function(){
			if(!me.treeObj.rendered && me.treeObj&& !this.readOnly){
				Ext.defer(function(){
					me.treeObj.render('comboboxTreeBox');
				},300,this);
			}
		});
		this.callParent(arguments);
	},
	onRender:function(){
		this.callParent(arguments);
	},
	beforeDestroy:function(){
		this.callParent(arguments);
	},
	getValue:function(){//获取id值
		if(this._idValue){
			return this._idValue;
		}else{
			if(this.defaultValue){
				return this.defaultValue;
			}else{
				return 0;
			}
		}
	},
	getTextValue:function(){//获取text值
		return this._txtValue;
	},
	setLocalValue:function(txt,id){//设值
		this._idValue=id;
		this.setValue(this._txtValue = txt);
	}
});
