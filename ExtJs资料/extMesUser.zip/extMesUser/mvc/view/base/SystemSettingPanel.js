var clockTaskManager=null;
Ext.define('Mvc.view.base.SystemSettingPanel',{
	extend:'Ext.panel.Panel',
	alias:'widget.systemSettingPanel',
	layout:'border',
	autoShow:true,
	maxinizable:true,
	closeAction:'close',
    initComponent:function(){
        var me = this;
        var oldValue = null;
        me.getSynServiceListStore=Ext.getStore('base.GetSynServiceListStore').load();
        me.getControlParameterStore=Ext.getStore('base.GetControlParameterStore').load();
        this.items=[
            Ext.widget("panel",{
                region:'west',
                layout:'fit',
                width:'65%',
                title:'设备维护列表',
                collapsible:true,
                animCollapse:true,
                split:true,
                tbar:Ext.widget("toolbar",{
                    items:[{
                        xtype:'textfield',
                        id:'NTPIP',
                        labelWidth:100,
                        fieldLabel:'NTP服务器地址',
                        readOnly:true,
                        value:ntpAddress,
                        allowBlank:false,
                    },{
                        text:'获取时间',
                        handler:function(btn){
                            btn.setDisabled(true);
                            if(clockTaskManager!=null){
                                Ext.TaskManager.stop(clockTaskManager);
                                Ext.getCmp("clock").setText("");
                            }
                            var ipforntp=Ext.getCmp('NTPIP').getValue();
                            Ext.Ajax.request({
                                url:'base/ntpTime/getNtpTime',
                                params:{ntpIP:ipforntp},
                                success:function(response,option){
                                    var result=Ext.JSON.decode(response.responseText);
                                    if(result.success){
                                        var time=new Date(result.msg).getTime();
                                        clockGo(time);
                                    }else{
                                        alert(result.msg);
                                    }
                                }
                            });

                            //value:new Date(new Date().getTime()-(7*24*60*60*1000))
                            function clockGo(time) {
                                clockTaskManager=Ext.TaskManager.start({
                                    run: function() {
                                        Ext.getCmp("clock").setText(Ext.Date.format(new Date(time), 'Y-m-d H:i:s'));
                                        time=time+1000;
                                    },
                                    interval: 1000
                                });
                            }
                            btn.setDisabled(false);
                        }
                    },{
                        xtype:'label',
                        width: 200,
                        margins: {left: 10},
                        id: 'clock',
                    },"->",{
                        text:'新增服务器',
                        action:'addServiceList',
                    },{
                        text:'修改服务器',
                        action:'updateServiceList',
                    },{
                        text:'删除服务器',
                        action:'delServiceList',
                    },{
                        text:'同步时间',
                        handler:function(btn){
                            btn.setDisabled(true);
                            var sel=Ext.getCmp('grade_controlParameterGrid2').getSelectionModel().getSelection();
                            if(sel.length == 0){
                                alert('请选择服务器!');
                                btn.setDisabled(false);
                            }else{
                                Ext.MessageBox.confirm("请确认以核对时间","所选的["+sel.length+"]个服务器将会被同步，确认继续?",function(btn1){
                                    if(btn1=='yes'){
                                        var ids=[];
                                        for(var i=0;i<sel.length;i++){
                                            var record=sel[i];
                                            ids.push(record.get('id'));
                                        }

                                        Ext.Ajax.request({
                                            url: 'base/ntpTime/set',
                                            params:{ids:ids},
                                            callback: function (response, option) {
                                                    Ext.getCmp('grade_controlParameterGridBar2').doRefresh();
                                                    Ext.getCmp('grade_controlParameterGrid2').getSelectionModel().deselectAll();
                                                    btn.setDisabled(false);
                                            }
                                        });
                                    }else {
                                        btn.setDisabled(false);
                                    }});
                            }
                        }
                    },{
                        text:'导出Excel',
                        handler:function(btn){
                            window.open('base/synServiceList/exportServiceList');
                        }
                    }
                    ]
                }),
                items:[{
                    xtype:'grid',
                    id:'grade_controlParameterGrid2',
                    store:me.getSynServiceListStore,
                    selModel:Ext.create('Ext.selection.CheckboxModel'),
                    stripeRows:true,
                    columnLines:true,
                    columns:[{
                        header:'主机名',dataIndex:'hostName',flex:2,align:'center'
                    },{
                        header:'服务器IP地址',dataIndex:'ip',flex:2,align:'center'
                    },{
                        header:'登录用户名',dataIndex:'userName',flex:1,align:'center'
                    }
                    // ,{
                    //     header:'密码',dataIndex:'password',flex:1,align:'center'
                    // }
                    ,{
                        header:'是否定时同步',dataIndex:'crontabFlag',flex:1,align:'center'
                    },{
                        header:'备注',dataIndex:'description',flex:3,align:'center'
                    },{
                        header:'同步状态',dataIndex:'stateString',flex:1,align:'center'
                    }],
                    bbar:Ext.create('Ext.PagingToolbar',{
                        id:'grade_controlParameterGridBar2',
                        store:me.getSynServiceListStore,
                        displayInfo:true,
                        displayMsg:'显示{0}-{1}条,共计{2}条',
                        emptyMsg:'没有数据',
                        firstText:'第一页',
                        lastText:'最后一页',
                        afterPageText:'/{0}页',
                        beforePageText:'第',
                        nextText:'下一页',
                        prevText:'上一页',
                        refreshText:'刷新'
                    }),
                    viewConfig:{
                        loadMask:{
                            msg :'加载数据中，请稍候...'
                        }}
                }]
            }),
            Ext.widget("panel",{
                region:'center',
                layout:'fit',
                width:'35%',
                title:'系统参数设置',
                tbar:["->",{
                    text:'导出Excel',
                    handler:function(btn){
                        window.open('base/controlParameter/exportControlParameter');
                    }
                }],
                items:[{
                    xtype:'grid',
                    id:'grade_controlParameterGrid',
                    store:me.getControlParameterStore,
                    plugins:[Ext.create('Ext.grid.plugin.CellEditing', {
                        clicksToEdit:1,
                        listeners:{
                            beforeedit:function(editor,e,ops){
                                if(e.column.dataIndex=='value'){
                                    console.log("进入setEditor");
                                    e.column.setEditor({
                                        id:'setEditorid',
                                        xtype:'textfield',
                                        store:'base.GetControlParameterStore',
                                        editable:false,
                                        listeners:{
                                            //获取焦点
                                            focus: function() {
                                                oldValue = Ext.getCmp('setEditorid').getValue();
                                            },
                                            //失去焦点事件
                                            blur: function(){
                                                var newValue = Ext.getCmp('setEditorid').getValue();
                                                if(newValue!=oldValue){
                                                    Ext.Msg.confirm('提示信息','请确认修改？',function(op){
                                                        if(op == 'yes'){
                                                            var sel=Ext.getCmp('grade_controlParameterGrid').getSelectionModel().getSelection();
                                                            var record = sel[0].data;
                                                            var saveFlag=false;
                                                            var ntpFlag=false;
                                                            if(record.name=="NtpAddress"){
                                                                var reg =  /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/
                                                                if(reg.test(newValue)){
                                                                    saveFlag=true;
                                                                    ntpFlag=true;
                                                                }else{
                                                                    alert("请输入一个正确的IP地址");
                                                                    Ext.getCmp('grade_controlParameterGridBar').doRefresh();
                                                                    Ext.getCmp('grade_controlParameterGrid').getSelectionModel().deselectAll();
                                                                }
                                                            }else if(record.name=="LockScreenTime" || record.name=="LockOutTime"){
                                                                if(Math.round(newValue)==newValue){
                                                                    saveFlag=true;
                                                                }else{
                                                                    alert("请输入一个整数");
                                                                    Ext.getCmp('grade_controlParameterGridBar').doRefresh();
                                                                    Ext.getCmp('grade_controlParameterGrid').getSelectionModel().deselectAll();
                                                                }
                                                            }
                                                            else if(record.name=="IPControlFlag"){
                                                                if(newValue==0 || newValue==1){
                                                                    saveFlag=true;
                                                                }else{
                                                                    alert("只能输入0或1");
                                                                    Ext.getCmp('grade_controlParameterGridBar').doRefresh();
                                                                    Ext.getCmp('grade_controlParameterGrid').getSelectionModel().deselectAll();
                                                                }

                                                            }
                                                            else{
                                                                saveFlag=true;
                                                            }

                                                            if(saveFlag==true) {
                                                                Ext.Ajax.request({
                                                                    url: 'base/controlParameter/update',
                                                                    headers: {'Content-Type': 'application/json'},
                                                                    params: JSON.stringify(record),
                                                                    success: function (response, option) {
                                                                        var result = Ext.JSON.decode(response.responseText);
                                                                        if (result.success) {
                                                                            if(ntpFlag==true){
                                                                                ntpAddress=newValue;
                                                                                Ext.getCmp('NTPIP').setValue(newValue);
                                                                            }
                                                                            Ext.getCmp('grade_controlParameterGridBar').doRefresh();
                                                                            Ext.getCmp('grade_controlParameterGrid').getSelectionModel().deselectAll();
                                                                        } else
                                                                            alert(result.msg);
                                                                    }
                                                                });
                                                            }
                                                        }else{
                                                            Ext.getCmp('grade_controlParameterGridBar').doRefresh();
                                                            Ext.getCmp('grade_controlParameterGrid').getSelectionModel().deselectAll();
                                                        }
                                                    })
                                                }
                                            }
                                        }
                                    });
                                }
                            }
                        }
                    })],
                    stripeRows:true,
                    columnLines:true,
                    columns:[
                        //     {
                        //     header:'参数ID',dataIndex:'id',flex:1,align:'center'
                        // },
                        {
                            header:'参数名称',dataIndex:'name',flex:1,align:'center'
                        },{
                            header:'备注',dataIndex:'description',flex:1,align:'center'
                        },{
                            header:'参数值',dataIndex:'value',flex:1,align:'center',
                            editor:{
                                xtype:'textfield',
                                readOnly:true
                            }
                        }],
                    bbar:Ext.create('Ext.PagingToolbar',{
                        id:'grade_controlParameterGridBar',
                        store:me.getControlParameterStore,
                        displayInfo:true,
                        displayMsg:'显示{0}-{1}条,共计{2}条',
                        emptyMsg:'没有数据',
                        firstText:'第一页',
                        lastText:'最后一页',
                        afterPageText:'/{0}页',
                        beforePageText:'第',
                        nextText:'下一页',
                        prevText:'上一页',
                        refreshText:'刷新'
                    }),
                    viewConfig:{
                        loadMask:{
                            msg :'加载数据中，请稍候...'
                        }}
                }]
            }),
        ];
        this.callParent(arguments);
    }
});
