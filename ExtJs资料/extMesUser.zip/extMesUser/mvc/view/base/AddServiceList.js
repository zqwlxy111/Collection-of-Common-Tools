Ext.define('Mvc.view.base.AddServiceList',{
	extend:'Ext.window.Window',
	alias:'widget.addservicelist',
    border:false,
    layout:'fit',
    modal:true,
    autoShow:true,
    closable:false,
    width:360,
    title:'新增服务器(注：需手动安装脚本)',
    initComponent:function(){
        var me=this;
        var json = new Object();
        var flagStore = Ext.create('Ext.data.Store', {
            fields: ['value', 'name'],
            data : [
                {"value":"YES", "name":"YES"},
                {"value":"NO", "name":"NO"}
            ]
        });

        me.items=[{
            xtype:'form',
            margins:"5,5,5,5",
            width:'100%',
            height:'100%',
            defaults:{
                width:330,
                padding:'5 0 0 5'
            },
            items:[{
                xtype:'textfield',
                name:"hostName",
                fieldLabel:"主机名",
                allowBlank:false,
                emptyText:'主机名',
                emptyCls:'textfield-emptyCls',
                enforceMaxLength:48,
                maxLength:48,
                blankText:'请输入主机名'
            },{
                xtype:'textfield',
                name:"ip",
                fieldLabel:'服务器地址',
                allowBlank:false,
                emptyText:'IP地址',
                emptyCls:'textfield-emptyCls',
                enforceMaxLength:25,
                maxLength:25,
                regex:/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/,
                regexText:'请输入正确格式的IP地址'
            },{
                xtype:'textfield',
                name:"userName",
                fieldLabel:"登录用户名",
                allowBlank:false,
                emptyText:'登录用户名',
                emptyCls:'textfield-emptyCls',
                enforceMaxLength:20,
                maxLength:20,
                blankText:'请输入登录用户名'
            },{
                xtype:'textfield',
                name:"password",
                inputType:"password",
                fieldLabel:"登录密码",
                allowBlank:false,
                emptyText:'登录密码',
                emptyCls:'textfield-emptyCls',
                enforceMaxLength:45,
                maxLength:45,
                blankText:'请输入登录密码'
            },{
                xtype:'combo',
                name:'crontabFlag',
                fieldLabel:'是否定时同步',
                valueField:'value',
                displayField: 'name',
                hiddenName: 'name',
                store:flagStore,
                editable:false,
                allowBlank:false
            },{
                xtype:'textfield',
                name:"description",
                fieldLabel:"备注",
                emptyText:'备注',
                emptyCls:'textfield-emptyCls',
                enforceMaxLength:200,
                maxLength:200
            }]
        }];
        me.buttonAlign='center',
            me.buttons=[{
                text:'保存',
                width:150,
                height:22,
                padding:'0',
                margins:'0',
                border:false,
                handler:function(btn){
                    var f=btn.up('window').down('form');
                    if(f && f.isValid()){
                        Ext.Ajax.request({
                            url:'base/synServiceList/insert',
                            headers:{'Content-Type':'application/json'},
                            params:JSON.stringify(f.getValues()),
                            success:function(response,option){
                                var result=Ext.JSON.decode(response.responseText);
                                if(result.success){
                                    f.up('window').close();
                                    Ext.getCmp('grade_controlParameterGridBar2').doRefresh();
                                }else
                                    alert(result.msg);
                            }
                        });
                    }
                }
            },{
                text:'关闭',
                width:150,
                height:22,
                padding:'0',
                margins:'0',
                border:false,
                scope:this,
                handler:this.close
            }]
        this.callParent(arguments);
    }
});