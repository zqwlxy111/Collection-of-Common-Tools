Ext.define('Mvc.model.node.DeviceModel',{
	extend:'Ext.data.Model',
	fields:[
		'id',
		'devId',
		'name',
		'repeaterId',
		'localId',
		'parentId',
		'parentName',
		'siteId',
		'siteName',
		'areaId',
		'areaName',
		'linkMode',
		'devTel',
		'qryTel',
		'ipAddress',
		'provider',
		'productType',
		'devType',
		'typeId',
		'useStatus',
		'IfImportant',
		'createTime',
		{name:'createTimeString',type:'string',convert:function(value,record) {
			if(record.raw.createTime)
				return getMyDate(record.raw.createTime,true);
			else
				return '';
		}},
		'deputyName',
		'address',
		'lng',
		'lat',
		'posType',
		'devPower',
		'postPower',
		'installTime',
		{name:'installTimeString',type:'string',convert:function(value,record) {
			if(record.raw.installTime)
				return getMyDate(record.raw.installTime,true);
			else
				return '';
		}},
		'checkTime',
		{name:'checkTimeString',type:'string',convert:function(value,record) {
			if(record.raw.checkTime)
				return getMyDate(record.raw.checkTime,true);
			else
				return '';
		}},
		'constructman',
        'integration',
		'bak'
	] 
});