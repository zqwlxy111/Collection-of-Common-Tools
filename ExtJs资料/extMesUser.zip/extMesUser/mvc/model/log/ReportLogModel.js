Ext.define('Mvc.model.log.ReportLogModel',{
	extend:'Ext.data.Model',
	fields:[
		'id',
		'omcIP',
		'logTime',
		{name:'logTimeString',type:'string',convert:function(value,record) {
			if(record.raw.logTime)
				return getMyDate(record.raw.logTime,false);
			else
				return '';
		}},
		'reportType',
		'deviceId',
		'info',
	] 
});