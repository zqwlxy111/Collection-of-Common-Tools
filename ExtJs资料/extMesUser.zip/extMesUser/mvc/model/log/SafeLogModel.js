Ext.define('Mvc.model.log.SafeLogModel',{
	extend:'Ext.data.Model',
	fields:[
		'id',
		'subUser',
		'sIP',
		'omcIP',
		'logTime',
		{name:'logTimeString',type:'string',convert:function(value,record) {
			if(record.raw.logTime)
				return getMyDate(record.raw.logTime,false);
			else
				return '';
		}},
		'action',
	] 
});