Ext.define('Mvc.model.safe.UserModel',{
	extend:'Ext.data.Model',
	fields:[
		// 'id',
		// // 'username',
		// 'name',
		// 'realName',
		// 'tel',
		// 'email',
		// // 'department',
		// // 'departmentString',
		// 'userValidity',
		// {name:'userValidityString',type:'string',convert:function(value,record) {
		// 	if(record.raw.userValidity)
		// 		return getMyDate(record.raw.userValidity,true);
		// 	else
		// 		return '';
		// }},
		// 'pwdValidity',
		// {name:'pwdValidityString',type:'string',convert:function(value,record) {
		// 	if(record.raw.pwdValidity)
		// 		return getMyDate(record.raw.pwdValidity,true);
		// 	else
		// 		return '';
		// }},
		// 'flag',
		// 'flagString',
		// 'createTime',
		// {name:'createTimeString',type:'string',convert:function(value,record) {
		// 	if(record.raw.createTime)
		// 		return getMyDate(record.raw.createTime,true);
		// 	else
		// 		return '';
		// }},
		// 'bak',
		// // 'groupIds',
		// // 'groupNames'
		// 'code',
		// 'status',
		'id',
		'name',
		'password',
		'tel',
		'email',
		'realName',
		'roles',
		'departments',
		'systems',
		'rolesStr',
		'systemsStr',
		'departmentsStr',
		'status',
		'createTime',
		'bak',
		'code',
		'userValidity',
		'pwdValidity',
		{name:'userValidityString',type:'string',
			// convert:function(value,record) {
			// 	if(record.raw.userValidity)					
			// 		{return getMyDate(record.raw.userValidity,true);}
			// 	else
			// 		{return '';}
			// }
			convert:function(value,record){
				if(record.raw.userValidity){
					var newValue=Ext.Date.format(new Date(record.raw.userValidity),"Y-m-d")
					return newValue;
				}else{
					return null;
				}
			}
		},
		{name:'pwdValidityString',type:'string',
			convert:function(value,record){
				if(record.raw.pwdValidity){
					var newValue=Ext.Date.format(new Date(record.raw.pwdValidity),"Y-m-d")
					return newValue;
				}else{
					return null;
				}
			}
		},
	] 
});