Ext.define('Mvc.model.safe.DictionaryModel',{
	extend:'Ext.data.Model',
	fields:[
		// {name:'title',type:'string'},
		// {name:'id',type:'string'},
		// {name:'name',type:'string'},
		// {name:'bak',type:'string'},
		// {name:'nameEng',type:'string'},
		// {name:'describe',type:'string'},
		'title',
		'id',
		'value',
		'name',
		'bak',
		'nameEng',
		'describe',
	] 
});