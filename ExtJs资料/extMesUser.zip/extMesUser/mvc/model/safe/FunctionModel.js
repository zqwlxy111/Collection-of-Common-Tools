Ext.define('Mvc.model.safe.FunctionModel',{
	extend:'Ext.data.Model',
	fields:[
		'id',
		'name',
		'action',
		'warningThreshold',
		'stopThreshold',
		'flag',
		{name:'flagName',type:'string',convert:function(value, record) {
			if(record.raw.flag==1)
				return '正常';
			else
				return '禁用';
		}},
		'bak'
	] 
});