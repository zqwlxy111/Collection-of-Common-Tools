Ext.define('Mvc.model.base.SynServiceListModel',{
	extend:'Ext.data.Model',
	fields:[
	    'id',
        'hostName',
		'ip',
		'userName',
        'password',
		'crontabFlag',
		'state',
        {name:'stateString',type:'string',convert:function(value,record) {
            if(record.raw.state==0)
                return "未同步";
            else if(record.raw.state==1)
               	return "同步成功";
            else if(record.raw.state==2)
                return "同步失败";
            else if(record.raw.state==3)
                return "服务器登录失败";
            else
                return '';
        }},
        'description'
	] 
});