Ext.define('Mvc.model.base.ItemModel',{
	extend:'Ext.data.Model',
	fields:[
		'itemTitle',
		'itemId',
		'itemName'
	] 
});