Ext.define('Mvc.model.base.VersionModel',{
	extend:'Ext.data.Model',
	fields:[
		'id',
		'name',
		'fileName',
		'detail',
		'createTime',
		{name:'createTimeString',type:'string',convert:function(value,record) {
			if(record.raw.createTime)
				return getMyDate(record.raw.createTime,false);
			else
				return '';
		}},
		'flag',
		{name:'flagString',type:'string',convert:function(value,record) {
			if(record.raw.flag==0)
				return '未激活';
			else if(record.raw.flag==1)
				return '激活';
			else
				return '';
		}}
	] 
});