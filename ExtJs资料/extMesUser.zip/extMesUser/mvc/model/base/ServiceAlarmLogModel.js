Ext.define('Mvc.model.base.ServiceAlarmLogModel',{
	extend:'Ext.data.Model',
	fields:[
	    'id',
        'hostName',
		'time',
        'repairTime',
		'type',
        'level',
        {name:'levelString',type:'string',convert:function(value,record) {
            if(record.raw.level==0)
                return "提示";
            else if(record.raw.level==1)
                return "一般";
            else if(record.raw.level==2)
                return "严重";
            else
                return '';
        }},
		'state',
        {name:'stateString',type:'string',convert:function(value,record) {
            if(record.raw.state==0)
                return "未处理";
            else if(record.raw.state==1)
               	return "正在处理";
            else if(record.raw.state==2)
                return "自动恢复";
            else
                return '';
        }},
        'description'
	] 
});