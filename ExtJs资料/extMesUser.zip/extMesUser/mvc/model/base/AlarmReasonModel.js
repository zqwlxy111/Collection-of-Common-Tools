Ext.define('Mvc.model.base.AlarmReasonModel',{
	extend:'Ext.data.Model',
	fields:[
		'id',
		'reason',
		'solution'
	] 
});