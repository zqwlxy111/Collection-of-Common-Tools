Ext.define('Mvc.controller.safe.UserController',{
	extend:'Ext.app.Controller',
	stores:[
	    'safe.GetUsersStore',
	    // 'safe.GetGroupsStore',
        'safe.GetDepartmentParentStore',
		'safe.GetDepartmentTreeStore',
		'safe.GetRolesStore',
	],
	views:[
	   	'safe.UserPanel',
	   	'safe.AddUserWin',
	   	'safe.UpdateUserWin',
	   	'safe.UpdateUserPasswordWin',
	   	'safe.UpdateUserRolesWin',
        'ComboboxTree',
	],
	init:function(){
        this.control({
        	'userpanel button':{
        		click:this.userPanelClickFun
        	}
        });
    },
    userPanelClickFun:function(btn){
    	btn.setDisabled(true);
    	var key = btn.action;
    	if(key=='addUserAction'){
    		Ext.widget('adduserwin',{});
    	}else if(key=='updateUserAction'){
    		var sel=Ext.getCmp('safe_userGrid').getSelectionModel().getSelection();
    		if(sel.length!=1){
        		Ext.Msg.alert('温馨提示','请选择一个用户!');
        	}else{
        		Ext.widget('updateuserwin',{
        			dataRecord:sel[0]
        		});
        	}
    	}else if(key=='updateUserPasswordAction'){
    		if(sessionStorage.omcIsAdmin){
                var sel=Ext.getCmp('safe_userGrid').getSelectionModel().getSelection();
                if(sel.length!=1){
                    Ext.Msg.alert('温馨提示','请选择一个用户!');
                }else{
                    Ext.widget('updateuserpasswordwin',{
                        dataRecord:sel[0]
                    });
                }
			}else{
    			alert("仅限超级管理员使用");
			}
		}else if(key=='updateUserRolesAction'){
    		var sel=Ext.getCmp('safe_userGrid').getSelectionModel().getSelection();
    		if(sel.length!=1){
        		Ext.Msg.alert('温馨提示','请选择一个用户!');
        	}else{
        		Ext.widget('updateuserroleswin',{
        			dataRecord:sel[0]
        		});
        	}
    	}else if(key=='deleteUserAction'){
    		var sel=Ext.getCmp('safe_userGrid').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			Ext.Msg.alert('温馨提示','请选择一个用户!');
        	}else{
        		Ext.MessageBox.confirm("请确认","所选的用户["+sel[0].get('name')+"]将会被删除，确认继续?",function(btn1){
    				if(btn1=='yes'){
    		    		Ext.Ajax.request({  
    		    			url:window.url+'/safe/user/deleteUser',
    		    			params:{id:sel[0].get('id')},
    		    			success:function(response,option){
    		    				var result=Ext.JSON.decode(response.responseText);
    		    				if(result.success)
    		    					{Ext.getCmp('safe_userGridBar').doRefresh();}
    		    				else
    		    					{alert(result.msg);}
    		    			}
    		    		});
    			}});
        	}
    	}
    	btn.setDisabled(false);
    }
});