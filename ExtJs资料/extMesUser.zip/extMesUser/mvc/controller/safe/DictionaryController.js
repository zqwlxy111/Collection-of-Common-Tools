Ext.define('Mvc.controller.safe.DictionaryController',{
	extend:'Ext.app.Controller',
	stores:[
		'safe.GetDictionaryStore',
		'safe.GetDictionaryDetailStore',
		'safe.GetRolesStore',
	],
	views:[
		'safe.DictionaryPanel',
		'safe.AddDictionaryWin',
		'safe.AddDictionarySonWin',
	],
	init:function(){
        this.control({
        	'dictionarypanel button':{
        		click:this.dictionarypanelClickFun
        	}
        });
    },
    dictionarypanelClickFun:function(btn){
    	btn.setDisabled(true);
    	var key = btn.action;
    	if(key=='addDictionaryAction'){
    		Ext.widget('adddictionarywin',{});
    	}else if(key=='deleteDictionaryAction'){
    		var sel=Ext.getCmp('safe_dictionaryGrid').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			Ext.Msg.alert('温馨提示','请选择一个用户!');
        	}else{
        		Ext.MessageBox.confirm("请确认","所选的名称为["+sel[0].get('name')+"]将会被删除，确认继续?",function(btn1){
    				if(btn1=='yes'){
    		    		Ext.Ajax.request({  
    		    			url:window.url+'/dict/deleteTitle',
    		    			params:{title:sel[0].get('title')},
    		    			success:function(response,option){
    		    				var result=Ext.JSON.decode(response.responseText);
    		    				if(result.success)
    		    					{Ext.getCmp('safe_dictionaryGrid').getStore().load();}
    		    				else
    		    					{alert(result.msg);}
    		    			}
    		    		});
    			}});
        	}
    	}else if(key=='addDictionarySonAction'){
			var sel=Ext.getCmp('safe_dictionaryGrid').getSelectionModel().getSelection();
			if(sel.length==0){
				Ext.Msg.alert('温馨提示','请选择一个字典值!');
			}else{
				Ext.widget('adddictionarysonwin',{dataRecord:sel[0]});
			}				
		}else if(key=='deleteDictionarySonAction'){
			var sel=Ext.getCmp('safe_dictionaryDetail').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			Ext.Msg.alert('温馨提示','请选择一个子字典值!');
        	}else{
        		Ext.MessageBox.confirm("请确认","所选的名称为["+sel[0].get('name')+"]将会被删除，确认继续?",function(btn1){
    				if(btn1=='yes'){
    		    		Ext.Ajax.request({  
    		    			url:window.url+'/dict/deleteSubItem',
    		    			params:{title:sel[0].get('title'),itemId:sel[0].get('id')},
    		    			success:function(response,option){
    		    				var result=Ext.JSON.decode(response.responseText);
    		    				if(result.success)
    		    					{Ext.getCmp('safe_dictionaryDetailBar').doRefresh();}
    		    				else
    		    					{alert(result.msg);}
    		    			}
    		    		});
    			}});
        	}
		}
    	btn.setDisabled(false);
    }
});