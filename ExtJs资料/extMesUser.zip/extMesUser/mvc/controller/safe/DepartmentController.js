Ext.define('Mvc.controller.safe.DepartmentController',{
	extend:'Ext.app.Controller',
	stores:[
	    'safe.GetDepartmentTreeStore',
		'safe.GetDepartmentParentStore',
		'safe.GetUserLikeNameStore',
	],
	views:[
	   	'safe.DepartmentPanel',
	   	'safe.AddDepartmentWin',
		'safe.UpdateDepartmentWin',
		'safe.AddDepartmentLineWin',
		'safe.AddDepartmentFactoryWin',
		// 'safe.GetBaseStore',
	   	// 'safe.UpdateUserPasswordWin',
	   	// 'safe.UpdateUserGroupWin',
	],
	init:function(){
        this.control({
        	'departmentpanel button':{
        		click:this.DepartmentPanelClickFun
        	}
        });
    },
    DepartmentPanelClickFun:function(btn){
    	btn.setDisabled(true);
		var key = btn.action;
		if(key=='refreshDepartmentAction'){
			Ext.getStore('safe.GetDepartmentTreeStore').load();
		}else if(key=='addDepartmentAction'){
			var sel=Ext.getCmp('safe_departmentTree').getSelectionModel().getSelection();
			if(sel.length!=1){
				Ext.Msg.alert('温馨提示','请先选择上级部门!');
			}else{
				Ext.widget('adddepartmentwin',{dataRecord:sel[0]});						
			}    		
		}else  if(key=='addDepartmentFactoryAction'){
			var sel=Ext.getCmp('safe_departmentTree').getSelectionModel().getSelection();
			if(sel.length!=1){
				Ext.Msg.alert('温馨提示','请先选择上级部门!');
			}else{
				
				if(sel[0].raw.obj.dataType==3){
					//新增工厂
					Ext.widget('adddepartmentfactorywin',{dataRecord:sel[0]});
				}else{
					Ext.Msg.alert('温馨提示','请选择【工厂正确的上级部门】!');
				}
			}    		
		}else  if(key=='addDepartmentLineAction'){
			var sel=Ext.getCmp('safe_departmentTree').getSelectionModel().getSelection();
			if(sel.length!=1){
				Ext.Msg.alert('温馨提示','请先选择上级部门!');
			}else{
				if(sel[0].raw.obj.dataType==5){
					//新增线体
					Ext.widget('adddepartmentlinewin',{dataRecord:sel[0]});
				}else{
					Ext.Msg.alert('温馨提示','请选择【线体正确的上级部门】!');
				}						
			}    		
		}
        else if(key=='updateDepartmentAction'){
    		var sel=Ext.getCmp('safe_departmentTree').getSelectionModel().getSelection();
    		if(sel.length!=1){
        		Ext.Msg.alert('温馨提示','请选择一个部门!');
        	}else{
        		Ext.widget('updatedepartmentwin',{
        			dataRecord:sel[0]
        		});
        	}
    	}
  //       else if(key=='deleteDepartmentAction'){
  //   		if(sessionStorage.omcIsAdmin){
  //               var sel=Ext.getCmp('safe_departmentTree').getSelectionModel().getSelection();
  //               if(sel.length!=1){
  //                   alert('请选择一个用户!');
  //               }else{
  //                   Ext.widget('updateuserpasswordwin',{
  //                       dataRecord:sel[0]
  //                   });
  //               }
		// 	}else{
  //   			alert("仅限超级管理员使用");
		// 	}
		// }
  //       else if(key=='updateUserGroupAction'){
  //   		var sel=Ext.getCmp('safe_userGrid').getSelectionModel().getSelection();
  //   		if(sel.length!=1){
  //       		alert('请选择一个用户!');
  //       	}else{
  //       		Ext.widget('updateusergroupwin',{
  //       			dataRecord:sel[0]
  //       		});
  //       	}
  //   	}
        else if(key=='deleteDepartmentAction'){
    		var sel=Ext.getCmp('safe_departmentTree').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			Ext.Msg.alert('温馨提示','请选择一个用户!');
        	}else{
        		Ext.MessageBox.confirm("请确认","所选的用户["+sel[0].raw.obj.name+"]将会被删除，确认继续?",function(btn1){
    				if(btn1=='yes'){
    		    		Ext.Ajax.request({  
    		    			url:window.url+'/safe/department/delete',
    		    			params:{id:sel[0].get('id')},
    		    			success:function(response,option){
    		    				var result=Ext.JSON.decode(response.responseText);
    		    				if(result.success){
									Ext.getStore('safe.GetDepartmentTreeStore').load();
								}else{
									Ext.Msg.alert('温馨提示',result.msg);
								}
    		    			}
    		    		});
    			}});
        	}
    	}
    	btn.setDisabled(false);
    }
});