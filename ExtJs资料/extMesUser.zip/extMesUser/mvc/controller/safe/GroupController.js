Ext.define('Mvc.controller.safe.GroupController',{
	extend:'Ext.app.Controller',
	stores:[
	    'safe.GetGroupsStore',
	    'safe.GetFunctionsByFlagStore',
	    // 'node.GetAreasStore',
	    // 'base.GetParamTypeStore'
	],
	views:[
	   	'safe.GroupPanel',
	   	'safe.AddGroupWin',
	   	'safe.UpdateGroupWin',
	   	'safe.UpdateGroupFunctionWin',
	   	// 'safe.UpdateGroupAreaWin',
	   	'safe.UpdateGroupParamWin'
	],
	init:function(){
        this.control({
        	'grouppanel button':{
        		click:this.groupPanelClickFun
        	}
        });
    },
    groupPanelClickFun:function(btn){
    	btn.setDisabled(true);
    	var key = btn.action;
    	if(key=='addGroupAction'){
    		Ext.widget('addgroupwin',{});
    	}else if(key=='updateGroupAction'){
    		var sel=Ext.getCmp('safe_groupGrid').getSelectionModel().getSelection();
    		if(sel.length!=1){
        		alert('请选择一个角色!');
        	}else{
        		Ext.widget('updategroupwin',{
        			dataRecord:sel[0]
        		});
        	}
    	}else if(key=='updateGroupFunctionAction'){
    		var sel=Ext.getCmp('safe_groupGrid').getSelectionModel().getSelection();
    		if(sel.length!=1){
        		alert('请选择一个角色!');
        	}else{
        		Ext.widget('updategroupfunctionwin',{
        			dataRecord:sel[0]
        		});
        	}
    	// }else if(key=='updateGroupAreaAction'){
    	// 	var sel=Ext.getCmp('safe_groupGrid').getSelectionModel().getSelection();
    	// 	if(sel.length!=1){
     //    		alert('请选择一个角色!');
     //    	}else{
     //    		Ext.widget('updategroupareawin',{
     //    			dataRecord:sel[0]
     //    		});
     //    	}
    	// }else if(key=='updateGroupParamAction'){
    	// 	var sel=Ext.getCmp('safe_groupGrid').getSelectionModel().getSelection();
    	// 	if(sel.length!=1){
     //    		alert('请选择一个角色!');
     //    	}else{
     //    		Ext.widget('updategroupparamwin',{
     //    			dataRecord:sel[0]
     //    		});
     //    	}
    	}else if(key=='deleteGroupAction'){
    		var sel=Ext.getCmp('safe_groupGrid').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			alert('请选择一个角色!');
        	}else{
        		Ext.MessageBox.confirm("请确认","所选的角色["+sel[0].get('name')+"]将会被删除，确认继续?",function(btn1){
    				if(btn1=='yes'){
    		    		Ext.Ajax.request({  
    		    			url:'safe/group/delete',
    		    			params:{id:sel[0].get('id')},
    		    			success:function(response,option){
    		    				var result=Ext.JSON.decode(response.responseText);
    		    				if(result.success)
    		    					Ext.getCmp('safe_groupGridBar').doRefresh();
    		    				else
    		    					alert(result.msg);
    		    			}
    		    		});
    			}});
        	}
    	}
    	btn.setDisabled(false);
    }
});