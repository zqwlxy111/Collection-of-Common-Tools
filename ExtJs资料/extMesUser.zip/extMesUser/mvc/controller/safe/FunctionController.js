Ext.define('Mvc.controller.safe.FunctionController',{
	extend:'Ext.app.Controller',
	stores:[
	    'safe.GetFunctionsStore'
	],
	views:[
	   	'safe.FunctionPanel'
	],
	init:function(){
        this.control({
//        	'button[action=editCompetence]':{
//        		click:this.editCompetenceFun
//        	},
        });
    },
//    editCompetenceFun:function(btn){
//    	btn.setDisabled(true);
//    	Ext.widget('editcompetencewin',{
//		});
//    	btn.setDisabled(false);
//    }
});