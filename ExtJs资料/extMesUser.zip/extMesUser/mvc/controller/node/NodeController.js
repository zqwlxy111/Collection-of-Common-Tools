Ext.define('Mvc.controller.node.NodeController',{
	extend:'Ext.app.Controller',
	stores:[
		'node.GetAreaTreeStore',
	    'node.GetBtsesStore',
	    'node.GetSitesStore',
	    'node.GetDevicesStore',
	    'node.GetAreasLikeNameStore',
	    'node.GetBtsesLikeNameStore',
	    'node.GetDevicesLikeNameStore',
	    'node.GetSitesLikeNameStore',
	    'base.GetLinkModeStore',
	    'base.GetTypeIdStore'
	],
	views:[
	   	'node.NodePanel',
	   	'node.AddAreaWin',
	   	'node.AddBtsWin',
	   	'node.UpdateBtsWin',
	   	'node.AddSiteWin',
	   	'node.UpdateSiteWin',
	   	'node.AddDeviceWin',
	   	'node.UpdateDeviceWin'
	],
	init:function(){
        this.control({
        	'nodepanel':{
        		afterrender:this.nodepanelAfterrenderFun
        	},
        	'#node_areaTree':{
        		selectionchange:this.areaTreeSelectionchangeFun
        	},
        	'#node_siteGrid':{
        		selectionchange:this.siteGridSelectionchangeFun
        	},
        	'nodepanel button':{
        		click:this.nodePanelClickFun
        	}
        });
    },
    nodepanelAfterrenderFun:function(panel){
//    	console.log("nodepanel afterrender!");
    },
    areaTreeSelectionchangeFun:function(tree,selected){
    	if(selected.length==0)
    		return;
    	var record=selected[selected.length-1];
    	var areaId = record.get('id');
    	areaId = areaId.replace('area_','');
    	
    	var getDevicesStore=Ext.getStore('node.GetDevicesStore');
    	getDevicesStore.proxy.extraParams.areaId=areaId;
    	getDevicesStore.load();
    	
    	var getSitesStore=Ext.getStore('node.GetSitesStore');
		getSitesStore.proxy.extraParams.areaId=areaId;
		getSitesStore.load();
		
		var getBtsesStore=Ext.getStore('node.GetBtsesStore');
		getBtsesStore.proxy.extraParams.areaId=areaId;
		getBtsesStore.load();
    },
    siteGridSelectionchangeFun:function(grid,selected){
    	if(selected.length==0)
    		return;
    	var record=selected[selected.length-1];
    	var store=Ext.getStore('node.GetDevicesStore');
    	store.proxy.extraParams.siteId=record.get('id');
    	store.load();
    },
    nodePanelClickFun:function(btn){
    	btn.setDisabled(true);
    	var key = btn.action;
    	if(key=='addAreaAction'){
    		Ext.widget('addareawin',{});
    	}else if(key=='deleteAreaAction'){
    		var sel=Ext.getCmp('node_areaTree').getSelectionModel().getSelection();
    		if(sel.length == 0){
        		alert('请选择至少一个地区!');
        	}else{
        		var id = sel[0].get('id');
        		id = id.replace('area_','');
        		Ext.MessageBox.confirm("请确认","地区["+sel[0].get('text')+"]及其子地区将会被删除，确认继续?",function(btn1){
    				if(btn1=='yes'){
    		    		Ext.Ajax.request({  
    		    			url:'node/area/delete',
    		    			params:{id:id},
    		    			success:function(response,option){
    		    				var result=Ext.JSON.decode(response.responseText);
    		    				if(result.success)
    		    					Ext.getStore('node.GetAreaTreeStore').load();
    		    				else
    		    					alert(result.msg);
    		    			},
    		    			failure:function(response,option){
    		    				alert(Ext.JSON.decode(response.responseText));
    		    			}
    		    		});
    			}});
        	}
    	}else if(key=='addBtsAction'){
    		Ext.widget('addbtswin',{});
    	}else if(key=='updateBtsAction'){
    		var sel=Ext.getCmp('node_btsGrid').getSelectionModel().getSelection();
    		if(sel.length!=1){
        		alert('请选择一个基站!');
        	}else{
        		Ext.widget('updatebtswin',{
        			dataRecord:sel[0]
        		});
        	}
    	}else if(key=='deleteBtsAction'){
    		var sel=Ext.getCmp('node_btsGrid').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			alert('请选择一个基站!');
        	}else{
        		var ids=[];
        		for(var i=0;i<sel.length;i++){
        			var record=sel[i];
        			ids.push(record.get('id'));
        		}
        		Ext.MessageBox.confirm("请确认","所选的["+sel.length+"]个基站将会被删除，确认继续?",function(btn1){
    				if(btn1=='yes'){
    		    		Ext.Ajax.request({  
    		    			url:'node/bts/delete',
    		    			params:{ids:ids},
    		    			success:function(response,option){
    		    				var result=Ext.JSON.decode(response.responseText);
    		    				if(result.success)
    		    					Ext.getCmp('node_btsGridBar').doRefresh();
    		    				else
    		    					alert(result.msg);
    		    			},
    		    			failure:function(response,option){
    		    				alert(Ext.JSON.decode(response.responseText));
    		    			}
    		    		});
    			}});
        	}
    	}else if(key=='addSiteAction'){
    		Ext.widget('addsitewin',{});
    	}else if(key=='updateSiteAction'){
    		var sel=Ext.getCmp('node_siteGrid').getSelectionModel().getSelection();
    		if(sel.length!=1){
        		alert('请选择一个站点!');
        	}else{
        		Ext.widget('updatesitewin',{
        			dataRecord:sel[0]
        		});
        	}
    	}else if(key=='deleteSiteAction'){
    		var sel=Ext.getCmp('node_siteGrid').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			alert('请选择一个站点!');
        	}else{
        		var ids=[];
        		for(var i=0;i<sel.length;i++){
        			var record=sel[i];
        			ids.push(record.get('id'));
        		}
        		Ext.MessageBox.confirm("请确认","所选的["+sel.length+"]个站点将会被删除，确认继续?",function(btn1){
    				if(btn1=='yes'){
    		    		Ext.Ajax.request({  
    		    			url:'node/site/delete',
    		    			params:{ids:ids},
    		    			success:function(response,option){
    		    				var result=Ext.JSON.decode(response.responseText);
    		    				if(result.success)
    		    					Ext.getCmp('node_siteGridBar').doRefresh();
    		    				else
    		    					alert(result.msg);
    		    			},
    		    			failure:function(response,option){
    		    				alert(Ext.JSON.decode(response.responseText));
    		    			}
    		    		});
    			}});
        	}
    	}else if(key=='addDeviceAction'){
    		Ext.widget('adddevicewin',{});
    	}else if(key=='updateDeviceAction'){
    		var sel=Ext.getCmp('node_deviceGrid').getSelectionModel().getSelection();
    		if(sel.length!=1){
        		alert('请选择一个设备!');
        	}else{
        		Ext.widget('updatedevicewin',{
        			dataRecord:sel[0]
        		});
        	}
    	}else if(key=='deleteDeviceAction'){
    		var sel=Ext.getCmp('node_deviceGrid').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			alert('请选择一个设备!');
        	}else{
        		var ids=[];
        		for(var i=0;i<sel.length;i++){
        			var record=sel[i];
        			ids.push(record.get('id'));
        		}
        		Ext.MessageBox.confirm("请确认","所选的["+sel.length+"]个设备将会被删除，确认继续?",function(btn1){
    				if(btn1=='yes'){
    		    		Ext.Ajax.request({  
    		    			url:'node/device/delete',
    		    			params:{ids:ids},
    		    			success:function(response,option){
    		    				var result=Ext.JSON.decode(response.responseText);
    		    				if(result.success)
    		    					Ext.getCmp('node_deviceGridBar').doRefresh();
    		    				else
    		    					alert(result.msg);
    		    			}
    		    		});
    			}});
        	}
    	}
    	btn.setDisabled(false);
    }
});