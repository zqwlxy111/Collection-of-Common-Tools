Ext.define('Mvc.controller.task.BackupController',{
	extend:'Ext.app.Controller',
	stores:[
	    'task.GetBackupPlansStore',
	    'task.GetBackupResultsStore',
	    'base.GetBackupTypeStore',
	    'base.GetWeekDayStore',
	    'task.GetHourStore'
	],
	views:[
	   	'task.BackupPanel',
	   	'task.AddBackupPlanWin',
	   	'task.UpdateBackupPlanWin',
	   	'task.BackupResultDataWin',
		'task.ExportBackupDataWin'
	],
	models:[
	    'Mvc.model.log.OperateLogModel',
	    'Mvc.model.log.ReportLogModel',
	    'Mvc.model.log.SafeLogModel'
	],
	init:function(){
        this.control({
        	'backuppanel button':{
        		click:this.backupPanelClickFun
        	}
        });
    },
    backupPanelClickFun:function(btn){
    	btn.setDisabled(true);
    	var key = btn.action;
    	if(key=='addBackupPlanAction'){
    		Ext.widget('addbackupplanwin',{});
    	}else if(key=='updateBackupPlanAction'){
    		var sel=Ext.getCmp('backupPlan_Grid').getSelectionModel().getSelection();
    		if(sel.length!=1){
        		alert('请选择一个备份策略!');
        	}else{
        		Ext.widget('updatebackupplanwin',{
        			dataRecord:sel[0],
        		});
        	}
    	}else if(key=='deleteBackupPlanAction'){
    		var sel=Ext.getCmp('backupPlan_Grid').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			alert('请选择一个备份策略!');
        	}else{
        		Ext.MessageBox.confirm("请确认","所选的备份策略["+sel[0].get('id')+"]将会被删除，确认继续?",function(btn1){
    				if(btn1=='yes'){
    		    		Ext.Ajax.request({  
    		    			url:'task/backup/delete',
    		    			params:{id:sel[0].get('id')},
    		    			success:function(response,option){
    		    				var result=Ext.JSON.decode(response.responseText);
    		    				if(result.success){
    		    					Ext.getCmp('backupPlan_GridBar').doRefresh();
    		    				}else
    		    					alert(result.msg);
    		    			}
    		    		});
    			}});
        	}
    	}else if(key=='startBackupAction'){
    		var sel=Ext.getCmp('backupPlan_Grid').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			alert('请选择一个备份策略!');
        	}else{
        		Ext.MessageBox.confirm("请确认","所选的备份策略["+sel[0].get('id')+"]将会被启动，确认继续?",function(btn1){
    				if(btn1=='yes'){
    		    		Ext.Ajax.request({  
    		    			url:'task/backup/insertResult',
    		    			params:{id:sel[0].get('id')},
    		    			success:function(response,option){
    		    				var result=Ext.JSON.decode(response.responseText);

    		    				if(result.success){
    		    					Ext.getCmp('backupResult_GridBar').doRefresh();
    		    				}else
    		    					alert(result.msg);
    		    			}
    		    		});
    			}});
        	}
    	}else if(key=='showBackupDataAction'){
    		var sel=Ext.getCmp('backupResult_Grid').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			alert('请选择一个备份数据!');
        	}else{
        		Ext.widget('backupresultdatawin',{
        			dataRecord:sel[0],
        		});
        	}
    	}else if(key=='restoreBackupDataAction'){
    		var sel=Ext.getCmp('backupResult_Grid').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			alert('请选择一个备份数据!');
        	}else{
    		    if(sel[0].get('type')!=2){
    		        alert('无法恢复日志数据!');
                }else{
                    Ext.MessageBox.confirm("请确认","所选的备份数据["+sel[0].get('id')+"]将会被恢复到系统中，确认继续?",function(btn1){
                        if(btn1=='yes'){
                            Ext.Ajax.request({
                                url:'task/backup/restoreBackupDatas',
                                params:{id:sel[0].get('id')},
                                success:function(response,option){
                                    var result=Ext.JSON.decode(response.responseText);
                                    if(result.success){
                                        alert("数据已恢复!");
                                    }else
                                        alert(result.msg);
                                }
                            });
                        }});
                }
        	}
    	}else if(key=='deleteBackupResultAction'){
    		var sel=Ext.getCmp('backupResult_Grid').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			alert('请选择一个备份数据!');
        	}else{
        		Ext.MessageBox.confirm("请确认","所选的备份数据["+sel[0].get('id')+"]将会被删除，确认继续?",function(btn1){
    				if(btn1=='yes'){
    		    		Ext.Ajax.request({  
    		    			url:'task/backup/deleteResult',
    		    			params:{id:sel[0].get('id')},
    		    			success:function(response,option){
    		    				var result=Ext.JSON.decode(response.responseText);
    		    				if(result.success){
    		    					Ext.getCmp('backupResult_GridBar').doRefresh();
    		    				}else
    		    					alert(result.msg);
    		    			}
    		    		});
    			}});
        	}
    	}else if(key=='exportBackupDataAction') {
            Ext.widget('exportbackupdatawin');
        }
    	btn.setDisabled(false);
    }
});