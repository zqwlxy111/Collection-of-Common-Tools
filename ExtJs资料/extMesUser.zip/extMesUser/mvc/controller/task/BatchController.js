Ext.define('Mvc.controller.task.BatchController',{
	extend:'Ext.app.Controller',
	stores:[
	    'task.GetBatchPlansStore',
	    'node.GetDevicesLikeNameStore',
	    'monitor.GetParamsStore'
	],
	views:[
	   	'task.BatchPlanPanel',
	   	'task.AddBatchWin',
	   	'task.SelectParamWin',
	   	'task.UpdateBatchWin',
	   	'task.BatchResultChart'
	],
	init:function(){
        this.control({
        	'#batchPlan_Grid':{
        		selectionchange:this.batchPlanGridSelectionchangeFun
        	},
        	'batchplanpanel button':{
        		click:this.batchPanelClickFun
        	}
        });
    },
    batchPlanGridSelectionchangeFun:function(grid,selected){
    	if(selected.length==0)
    		return;
    	var record=selected[selected.length-1];
    	var results = eval(record.get('result'));
    	if(results!=null){
    		for(var i=0;i<results.length;i++){
    			results[i].time=getMyTime(results[i].time);
    			results[i].v=parseInt(results[i].v);
    		}
    		Ext.getCmp('task_batchResultChart').store.loadData(results);
    	}else{
    		Ext.getCmp('task_batchResultChart').store.loadData([]);
    	}
    },
    batchPanelClickFun:function(btn){
    	btn.setDisabled(true);
    	var key = btn.action;
    	if(key=='addBatchPlanAction'){
    		Ext.widget('addbatchwin',{});
    	}else if(key=='updateBatchPlanAction'){
    		var sel=Ext.getCmp('batchPlan_Grid').getSelectionModel().getSelection();
    		if(sel.length!=1){
        		alert('请选择一个批采计划!');
        	}else{
    			Ext.widget('updatebatchwin',{
        			dataRecord:sel[0]
        		});
        	}
    	}else if(key=='deleteBatchPlanAction'){
    		var sel=Ext.getCmp('batchPlan_Grid').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			alert('请选择一个批采计划!');
        	}else{
        		var ids=[];
        		for(var i=0;i<sel.length;i++){
        			var record=sel[i];
        			ids.push(record.get('id'));
        		}
        		console.log(ids);
        		Ext.MessageBox.confirm("请确认","所选的["+sel.length+"]个批采计划将会被删除，确认继续?",function(btn1){
    				if(btn1=='yes'){
    		    		Ext.Ajax.request({  
    		    			url:'task/batchPlan/delete',
    		    			params:{ids:ids},
    		    			success:function(response,option){
    		    				var result=Ext.JSON.decode(response.responseText);
    		    				if(result.success){
    		    					Ext.getCmp('batchPlan_GridBar').doRefresh();
    		    				}else
    		    					alert(result.msg);
    		    			}
    		    		});
    			}});
        	}
    	}
    	btn.setDisabled(false);
    }
});