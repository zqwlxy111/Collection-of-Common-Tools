Ext.define('Mvc.controller.task.UpgradeController',{
	extend:'Ext.app.Controller',
	stores:[
	    'task.GetUpgradePlansStore',
	    'node.GetDevicesLikeNameStore'
	],
	views:[
	   	'task.UpgradePlanPanel',
	   	'task.AddUpgradeWin',
	],
	init:function(){
        this.control({
        	'upgradeplanpanel button':{
        		click:this.batchPanelClickFun
        	}
        });
    },
    batchPanelClickFun:function(btn){
    	btn.setDisabled(true);
    	var key = btn.action;
    	if(key=='addUpgradePlanAction'){
    		Ext.widget('addupgradewin',{});
    	}else if(key=='deleteUpgradePlanAction'){
    		var sel=Ext.getCmp('upgradePlan_Grid').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			alert('请选择一个升级计划!');
        	}else{
        		if(sel[0].get('flag')==2){
        			alert('选择的计划正在执行!');
        		}else{
        			Ext.MessageBox.confirm("请确认","所选的升级计划将会被删除，确认继续?",function(btn1){
        				if(btn1=='yes'){
        					Ext.Ajax.request({  
        						url:'task/upgrade/delete',
        						params:{id:sel[0].get('id')},
        						success:function(response,option){
        							var result=Ext.JSON.decode(response.responseText);
        							if(result.success){
        								Ext.getCmp('upgradePlan_GridBar').doRefresh();
        							}else
        								alert(result.msg);
        						},
        						failure:function(response,option){
        							alert(Ext.JSON.decode(response.responseText));
        						}
        					});
        				}});
        		}
        	}
    	}else if(key=='startUpgradePlanAction'){
    		var sel=Ext.getCmp('upgradePlan_Grid').getSelectionModel().getSelection();
    		if(sel.length!=1){
        		alert('请选择一个升级计划!');
        	}else{
        		if(sel[0].get('flag')!=1){
        			alert('选择的计划无法启动!');
        		}else{
        			Ext.Ajax.request({  
        				url:'task/upgrade/updateFlag',
        				params:{
        					id:sel[0].get('id'),
        					flag:2
        				},
        				success:function(response,option){
        					var result=Ext.JSON.decode(response.responseText);
        					if(result.success){
        						Ext.getCmp('upgradePlan_GridBar').doRefresh();
        						Ext.getCmp('upgradePlan_Grid').getSelectionModel().deselectAll();
        					}else
        						alert(result.msg);
        				},
        				failure:function(response,option){
        					alert(Ext.JSON.decode(response.responseText));
        				}
        			});
        		}
        	}
    	}else if(key=='stopUpgradePlanAction'){
    		var sel=Ext.getCmp('upgradePlan_Grid').getSelectionModel().getSelection();
    		if(sel.length!=1){
        		alert('请选择一个升级计划!');
        	}else{
        		if(sel[0].get('flag')!=2){
        			alert('选择的计划没有在执行!');
        		}else{
        			Ext.Ajax.request({  
        				url:'task/upgrade/updateFlag',
        				params:{
        					id:sel[0].get('id'),
        					flag:5
        				},
        				success:function(response,option){
        					var result=Ext.JSON.decode(response.responseText);
        					if(result.success){
        						Ext.getCmp('upgradePlan_GridBar').doRefresh();
        						Ext.getCmp('upgradePlan_Grid').getSelectionModel().deselectAll();
        					}else
        						alert(result.msg);
        				}
        			});
        		}
        	}
    	}
    	btn.setDisabled(false);
    }
});