Ext.define('Mvc.controller.task.PollingController',{
	extend:'Ext.app.Controller',
	stores:[
	    'task.GetPollingDevicesStore',
	    'task.GetPollingPlansStore',
	    'task.GetPollingResultsStore',
	    'task.GetPollingResultDevicesStore',
	    'task.GetHourStore',
	    'node.GetDevicesByKeyStore',
	    'base.GetParamTypeStore',
	    'node.GetAreasLikeNameStore'
	],
	views:[
	   	'task.PollingPanel',
	   	'task.PollingResultPieChart',
	   	'task.AddPollingPlanWin',
	   	'task.UpdatePollingPlanWin'
	],
	init:function(){
        this.control({
        	'#pollingResult_Grid':{
        		selectionchange:this.pollingResultGridSelectionchangeFun
        	},
        	'pollingpanel button':{
        		click:this.pollingPanelClickFun
        	}
        });
    },
    pollingResultGridSelectionchangeFun:function(grid,selected){
    	if(selected.length==0)
    		return;
    	var record=selected[selected.length-1];
    	var result=record.get('result');
    	var results=[];
    	if(result!=null &&result!=""){
    		var json = Ext.JSON.decode(result);
    		results.push({name:"正常",count:json.normal});
    		results.push({name:"一级告警",count:json.alarm1});
    		results.push({name:"二级告警",count:json.alarm2});
    		results.push({name:"三级告警",count:json.alarm3});
    		results.push({name:"四级告警",count:json.alarm4});
    	}
    	Ext.getCmp('task_Pollingresultpiechart').store.loadData(results);
    	
    	var store=Ext.getStore('task.GetPollingResultDevicesStore');
    	store.proxy.extraParams.pollingResultId=record.get('id');
    	store.proxy.extraParams.monitorStatus=-1;
    	store.load();
    	
    },
    pollingPanelClickFun:function(btn){
    	btn.setDisabled(true);
    	var key = btn.action;
    	if(key=='addPollingPlanAction'){
    		Ext.widget('addpollingplanwin',{});
    	}else if(key=='updatePollingPlanAction'){
    		var sel=Ext.getCmp('pollingPlan_Grid').getSelectionModel().getSelection();
    		if(sel.length!=1){
        		alert('请选择一个轮询策略!');
        	}else{
        		var tempStore=Ext.getStore('task.GetPollingDevicesStore');
        		tempStore.proxy.extraParams.pollingPlanId=sel[0].get('id');
        		tempStore.load(function(records){
        			Ext.widget('updatepollingplanwin',{
            			dataRecord:sel[0],
            			selectStore:tempStore
            		});
        		});
        	}
    	}else if(key=='deletePollingPlanAction'){
    		var sel=Ext.getCmp('pollingPlan_Grid').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			alert('请选择一个轮询策略!');
        	}else{
        		Ext.MessageBox.confirm("请确认","所选的轮询策略["+sel[0].get('name')+"]将会被删除，确认继续?",function(btn1){
    				if(btn1=='yes'){
    		    		Ext.Ajax.request({  
    		    			url:'task/polling/delete',
    		    			params:{id:sel[0].get('id')},
    		    			success:function(response,option){
    		    				var result=Ext.JSON.decode(response.responseText);
    		    				if(result.success){
    		    					Ext.getCmp('pollingPlan_GridBar').doRefresh();
    		    				}else
    		    					alert(result.msg);
    		    			},
    		    			failure:function(response,option){
    		    				alert(Ext.JSON.decode(response.responseText));
    		    			}
    		    		});
    			}});
        	}
    	}else if(key=='startPollingAction'){
    		var sel=Ext.getCmp('pollingPlan_Grid').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			alert('请选择一个轮询策略!');
        	}else{
        		Ext.MessageBox.confirm("请确认","所选的轮询策略["+sel[0].get('name')+"]将会被启动，确认继续?",function(btn1){
    				if(btn1=='yes'){
    		    		Ext.Ajax.request({  
    		    			url:'task/polling/insertResult',
    		    			params:{id:sel[0].get('id')},
    		    			success:function(response,option){
    		    				var result=Ext.JSON.decode(response.responseText);
    		    				if(result.success){
//    		    					Ext.getCmp('pollingResult_GridBar').doRefresh();
    		    				}else
    		    					alert(result.msg);
    		    			},
    		    			failure:function(response,option){
    		    				alert(Ext.JSON.decode(response.responseText));
    		    			}
    		    		});
    			}});
        	}
    	}else if(key=='stopPollingAction'){
    		var sel=Ext.getCmp('pollingResult_Grid').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			alert('请选择一个轮询任务!');
        	}else{
        		if(sel[0].get('flag')<=1){
        			Ext.MessageBox.confirm("请确认","所选的轮询任务["+sel[0].get('id')+"]将会被终止，确认继续?",function(btn1){
        				if(btn1=='yes'){
        					Ext.Ajax.request({  
        						url:'task/polling/updateResult',
        						params:{id:sel[0].get('id')},
        						success:function(response,option){
        							var result=Ext.JSON.decode(response.responseText);
        							if(result.success){
        								Ext.getCmp('pollingResult_GridBar').doRefresh();
        							}else
        								alert(result.msg);
        						}
        					});
        			}});
        		}else{
        			alert('所选轮询已结束!');
        		}
        	}
    	}
    	btn.setDisabled(false);
    }
});