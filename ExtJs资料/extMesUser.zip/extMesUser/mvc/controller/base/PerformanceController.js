Ext.define('Mvc.controller.base.PerformanceController',{
	extend:'Ext.app.Controller',
	stores:[
        'performance.GetPerformanceInfoStore',
        'performance.GetProcessInfoStore',
        'performance.GetMySQLProcessInfoStore',
        'performance.GetHardwareInfoStore',
        'performance.GetServiceListTreeStore',
		'base.GetSynServiceListStore',
		'performance.GetServiceAlarmLogStore'
	],
	views:[
	   	'performance.PerformancePanel',
		'performance.CPUResultChart',
        'performance.MemoryResultChart',
	],
	init:function(){
        this.control({
			'performancepanel button':{
                click:this.PerformancePanelClickFun
            }
        });
    },
    PerformancePanelClickFun:function(btn){
        btn.setDisabled(true);
        var key = btn.action;
        if(key=='updateStateAction'){
            var sel=Ext.getCmp('performance_siteGrid1').getSelectionModel().getSelection();
            if(sel.length == 0){
                alert('请选择要标记的记录!');
            }else{
                Ext.MessageBox.confirm("请确认","所选的["+sel.length+"]个记录将会被设置为已读，确认继续?",function(btn1){
                    if(btn1=='yes'){
                        var ids=[];
                        for(var i=0;i<sel.length;i++){
                            var record=sel[i];
                            ids.push(record.get('id'));
                        }
                        Ext.Ajax.request({
                            url: 'base/serviceAlarmLog/updateStateByID',
                            params:{ids:ids},
                            success: function (response, option) {
                                var result = Ext.JSON.decode(response.responseText);
                                if (result.success) {
                                    //刷新告警信息
                                    Ext.getCmp('performance_siteGridBar2').doRefresh();
                                } else
                                    alert(result.msg);
                            }
                        });
                    }});
            }
        }else if(key=='deleteAction'){
            var sel=Ext.getCmp('performance_siteGrid1').getSelectionModel().getSelection();
            if(sel.length == 0){
                alert('请选择要删除的记录!');
            }else{
                Ext.MessageBox.confirm("请确认","所选的["+sel.length+"]个记录将会被删除，确认继续?",function(btn1){
                    if(btn1=='yes'){
                        var ids=[];
                        for(var i=0;i<sel.length;i++){
                            var record=sel[i];
                            ids.push(record.get('id'));
                        }
                        Ext.Ajax.request({
                            url: 'base/serviceAlarmLog/delete',
                            params:{ids:ids},
                            success: function (response, option) {
                                var result = Ext.JSON.decode(response.responseText);
                                if (result.success) {
                                    Ext.getCmp('performance_siteGridBar2').doRefresh();
                                } else
                                    alert(result.msg);
                            }
                        });
                    }});
            }
        }else if(key=='killProcessAction'){
            var sel=Ext.getCmp('performance_tab6Grid').getSelectionModel().getSelection();
            if(sel.length == 0){
                alert('请选择要结束的进程!');
            }else{
                Ext.MessageBox.confirm("请确认","所选的["+sel.length+"]个记录将会被删除，确认继续?",function(btn1){
                    if(btn1=='yes'){
                        var processList=[];
                        for(var i=0;i<sel.length;i++){
                            var record=sel[i];
                            var process=record.get('hostName')+" "+record.get('pid')+" "+record.get('command');
                            console.log("process:"+process);
                            processList.push(process);
                        }
                        Ext.Ajax.request({
                            url: 'base/script/killProcess',
                            params:{processList:processList},
                            success: function (response, option) {
                                var result = Ext.JSON.decode(response.responseText);
                                if (result.success) {
                                    Ext.getCmp('performance_tab6GridBar').doRefresh();
                                } else{
                                    alert(result.msg);
                                }
                            }
                        });
                    }});
            }
        }
        btn.setDisabled(false);
    }

});