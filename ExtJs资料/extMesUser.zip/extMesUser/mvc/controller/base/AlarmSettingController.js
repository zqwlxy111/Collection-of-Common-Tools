Ext.define('Mvc.controller.base.AlarmSettingController',{
	extend:'Ext.app.Controller',
	stores:[
	    'base.GetAlarmGradesStore',
	    'base.GetAlarmReasonsStore',
	    'base.GetAlarmReasonsForComboStore',
	    'base.GetTypeIdStore',
	    'base.GetAlarmLevelStore'
	],
	views:[
	   	'base.AlarmSettingPanel',
	   	'base.AddReasonWin',
	   	'base.UpdateReasonWin'
	],
	init:function(){
        this.control({
        	'alarmsettingpanel button':{
        		click:this.alarmSettingPanelClickFun
        	},
        });
    },
    alarmSettingPanelClickFun:function(btn){
    	btn.setDisabled(true);
    	var key = btn.action;
    	if(key=='addReasonAction'){
    		Ext.widget('addreasonwin',{});
    	}else if(key=='updateReasonAction'){
    		var sel=Ext.getCmp('grade_alarmReasonGrid').getSelectionModel().getSelection();
    		if(sel.length!=1){
        		alert('请选择一个告警信息!');
        	}else{
        		Ext.widget('updatereasonwin',{
        			dataRecord:sel[0]
        		});
        	}
    	}else if(key=='deleteReasonAction'){
    		var sel=Ext.getCmp('grade_alarmReasonGrid').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			alert('请选择一个告警信息!');
        	}else{
        		console.log(sel[0]);
        		Ext.MessageBox.confirm("请确认","所选的["+sel.length+"]个告警信息将会被删除，确认继续?",function(btn1){
    				if(btn1=='yes'){
    		    		Ext.Ajax.request({  
    		    			url:'base/alarmReason/delete',
    		    			headers:{'Content-Type':'application/json'},
			    			params:JSON.stringify(sel[0].data),
    		    			success:function(response,option){
    		    				var result=Ext.JSON.decode(response.responseText);
    		    				if(result.success){
    		    					Ext.getCmp('grade_alarmReasonGridBar').doRefresh();
    		    				}else
    		    					alert(result.msg);
    		    			}
    		    		});
    			}});
        	}
    	}
    	btn.setDisabled(false);
    }
});