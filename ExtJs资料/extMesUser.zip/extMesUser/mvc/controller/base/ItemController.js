Ext.define('Mvc.controller.base.ItemController',{
	extend:'Ext.app.Controller',
	stores:[
	    'base.GetItemTitleStore',
	    'base.GetItemsByTitleStore'
	],
	views:[
	   	'base.ItemPanel',
	   	'base.AddItemWin',
	   	'base.UpdateItemWin'
	],
	init:function(){
        this.control({
        	'#item_itemTitleGrid':{
        		selectionchange:this.itemTitleGridSelectionchangeFun
        	},
//        	'#item_itemNameGrid':{
//        		selectionchange:this.itemNameGridSelectionchangeFun
//        	},
        	'itempanel button':{
        		click:this.itempanelClickFun
        	}
        });
    },
    itemTitleGridSelectionchangeFun:function(grid,selected){
    	if(selected.length==0)
    		return;
    	var record=selected[selected.length-1];
    	var store=Ext.getStore('base.GetItemsByTitleStore');
    	store.proxy.extraParams.itemTitle=record.get('itemTitle');
    	store.load();
    },
//    itemNameGridSelectionchangeFun:function(grid,selected){
//    	if(selected.length==0)
//    		return;
//    	var record=selected[selected.length-1];
//    	Ext.getCmp('item_detailForm').loadRecord(record);
//    },
    itempanelClickFun:function(btn){
    	btn.setDisabled(true);
    	var key = btn.action;
    	if(key=='importParamListAction'){
    		
    	}else if(key=='addItemAction'){
    		Ext.widget('additemwin',{});
    	}else if(key=='updateItemAction'){
    		var sel=Ext.getCmp('item_itemNameGrid').getSelectionModel().getSelection();
    		if(sel.length!=1){
        		alert('请选择一个主题选项!');
        	}else{
        		Ext.widget('updateitemwin',{
        			dataRecord:sel[0]
        		});
        	}
    	}else if(key=='deleteItemAction'){
    		var sel=Ext.getCmp('item_itemNameGrid').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			alert('请选择一个主题选项!');
        	}else{
        		Ext.MessageBox.confirm("请确认","所选的["+sel.length+"]个主题选项将会被删除，确认继续?",function(btn1){
    				if(btn1=='yes'){
    		    		Ext.Ajax.request({  
    		    			url:'base/item/delete',
    		    			headers:{'Content-Type':'application/json'},
			    			params:JSON.stringify(sel[0].data),
    		    			success:function(response,option){
    		    				var result=Ext.JSON.decode(response.responseText);
    		    				if(result.success){
    		    					Ext.getStore('base.GetItemTitleStore').load();
    		    					Ext.getStore('base.GetItemsByTitleStore').load();
    		    				}else
    		    					alert(result.msg);
    		    			}
    		    		});
    			}});
        	}
    	}
    	btn.setDisabled(false);
    }
});