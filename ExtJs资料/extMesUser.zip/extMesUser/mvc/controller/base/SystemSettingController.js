Ext.define('Mvc.controller.base.SystemSettingController',{
	extend:'Ext.app.Controller',
	stores:[
        'base.GetControlParameterStore',
        'base.GetSynServiceListStore'
	],
	views:[
        'base.SystemSettingPanel',
        'base.AddServiceList',
        'base.UpdateServiceListWin'
	],
	init:function(){
        this.control({
            'systemSettingPanel button':{
                click:this.systemSettingPanelClickFun
            }
        });
    },
	systemSettingPanelClickFun:function(btn){
        btn.setDisabled(true);
        var key = btn.action;
        if(key=='addServiceList'){
            Ext.widget('addservicelist',{});
        }else if(key=='delServiceList'){
            var sel=Ext.getCmp('grade_controlParameterGrid2').getSelectionModel().getSelection();
            if(sel.length == 0){
                alert('请选择服务器!');
            }else{
                Ext.MessageBox.confirm("请确认","所选的["+sel.length+"]个服务器信息将会被删除，确认继续?",function(btn1){
                    if(btn1=='yes'){
                        var ids=[];
                        for(var i=0;i<sel.length;i++){
                            var record=sel[i];
                            ids.push(record.get('id'));
                        }
						Ext.Ajax.request({
							url: 'base/synServiceList/delete',
                            params:{ids:ids},
							success: function (response, option) {
								var result = Ext.JSON.decode(response.responseText);
								if (result.success) {
									Ext.getCmp('grade_controlParameterGridBar2').doRefresh();
								} else
									alert(result.msg);
							}
						});
                    }});
            }
		}else if(key=='updateServiceList'){
            var sel=Ext.getCmp('grade_controlParameterGrid2').getSelectionModel().getSelection();
            if(sel.length!=1){
                alert('请选择一个告警信息!');
            }else{
                Ext.widget('updatereasonwin',{
                    dataRecord:sel[0]
                });
            }
		}
        btn.setDisabled(false);
    }
});