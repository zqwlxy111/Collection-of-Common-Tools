Ext.define('Mvc.controller.base.VersionController',{
	extend:'Ext.app.Controller',
	stores:[
	    'base.GetVersionsStore'
	],
	views:[
	   	'base.VersionPanel',
	   	'base.AddVersionWin'
	],
	init:function(){
        this.control({
        	'versionpanel button':{
        		click:this.itempanelClickFun
        	}
        });
    },
    itempanelClickFun:function(btn){
    	btn.setDisabled(true);
    	var key = btn.action;
    	if(key=='addVersionAction'){
    		Ext.widget('addversionwin',{});
    	}else if(key=='deleteVersionAction'){
    		var sel=Ext.getCmp('base_VersionGrid').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			alert('请选择一个版本!');
        	}else if(sel[0].get('flag')==1){
        		alert('当前版本已被激活,删除前需要先卸载!');
        	}else{
        		Ext.MessageBox.confirm("请确认","所选的["+sel.length+"]个版本补丁将会被删除，确认继续?",function(btn1){
    				if(btn1=='yes'){
    		    		Ext.Ajax.request({  
    		    			url:'base/version/delete',
    		    			params:{
			    				id:sel[0].get('id')
			    			},
    		    			success:function(response,option){
    		    				var result=Ext.JSON.decode(response.responseText);
    		    				if(result.success){
    		    					Ext.getCmp('base_VersionGridBar').doRefresh();
    		    				}else
    		    					alert(result.msg);
    		    			}
    		    		});
    			}});
        	}
    	}else if(key=='updateVersion1Action'){
    		var sel=Ext.getCmp('base_VersionGrid').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			alert('请选择一个版本!');
        	}else if(sel[0].get('flag')==1){
        		alert('当前版本已被激活!');
        	}else{
        		Ext.MessageBox.confirm("请确认","所选的["+sel.length+"]个版本补丁将会被激活，确认继续?",function(btn1){
    				if(btn1=='yes'){
    		    		Ext.Ajax.request({  
    		    			url:'base/version/update',
			    			params:{
			    				id:sel[0].get('id'),
			    				flag:1
			    			},
    		    			success:function(response,option){
    		    				var result=Ext.JSON.decode(response.responseText);
    		    				if(result.success){
    		    					Ext.getCmp('base_VersionGridBar').doRefresh();
    		    				}else
    		    					alert(result.msg);
    		    			}
    		    		});
    			}});
        	}
    	}else if(key=='updateVersion0Action'){
    		var sel=Ext.getCmp('base_VersionGrid').getSelectionModel().getSelection();
    		if(sel.length == 0){
    			alert('请选择一个版本!');
        	}else if(sel[0].get('flag')==0){
        		alert('当前版本已被卸载!');
        	}else{
        		Ext.MessageBox.confirm("请确认","所选的["+sel.length+"]个版本补丁将会被卸载，确认继续?",function(btn1){
    				if(btn1=='yes'){
    		    		Ext.Ajax.request({  
    		    			url:'base/version/update',
			    			params:{
			    				id:sel[0].get('id'),
			    				flag:0
			    			},
    		    			success:function(response,option){
    		    				var result=Ext.JSON.decode(response.responseText);
    		    				if(result.success){
    		    					Ext.getCmp('base_VersionGridBar').doRefresh();
    		    				}else
    		    					alert(result.msg);
    		    			}
    		    		});
    			}});
        	}
    	}
    	btn.setDisabled(false);
    }
});