Ext.define('Mvc.controller.MainController',{
    extend:'Ext.app.Controller',
    stores:[
        // 'node.GetAreaTreeStore',
        // 'node.GetBtsesStore',
        // 'node.GetSitesStore',
        
        // 'plan.GetOutWeekPlanListStore',

        // 'monitor.GetDeviceExListForMapStore',
     //    'monitor.GetParamsStore',
     //    'main.MonitorStatusStore',
     //    'main.WorkStatusStore',
     //    'main.CurAlarmStore',
     //    'base.GetControlParameterStore',
     //    'log.GetOperateLogsStore',
     //    'log.GetReportLogsStore',
     //    'log.GetSafeLogsStore',
     //    'node.GetAreasLikeNameStore',
	    // 'node.GetBtsesLikeNameStore',
	    // 'node.GetDevicesLikeNameStore',
	    // 'node.GetSitesLikeNameStore',
	    // 'base.GetLinkModeStore',
	    // 'base.GetTypeIdStore'
    ],
    views:[
        'main.MainTab',

        // 'main.FirstPage',
        // 'plan.AddWeekPlanWin',
        // 'plan.WeekPlanUploadWin',

     //    'main.MapPanel',
     //    'user.Login',
     //    'user.LockScreen',
        'user.UpdateUserInfoWin',
        // 'user.ResetPasswordWin',
        'user.ResetPasswordWin2',
     //    'main.MonitorStatusPieChart',
     //    'main.WorkStatusPieChart',
     //    'log.OperateLogPanel',
     //    'log.ReportLogPanel',
     //    'log.SafeLogPanel',
     //    'node.AddAreaWin',
     //    'node.UpdateBtsWin',
	   	// 'node.UpdateSiteWin',
	   	// 'node.UpdateDeviceWin'
    ],
    init:function(){
        this.control({
            'firstpage':{
            	// beforerender:this.mainBeforerender,
             //    afterrender:this.mainAfterrender
            },
            // '#map_areaTree':{
            //     selectionchange:this.areaTreeSelectionchangeFun
            // },
            'button[action=onLogin]':{
                click:this.onLogin
            },
            'button[action=unLock]':{
                click:this.unLock
            },
            '#west-region-container':{
                beforerender:this.mainBeforerender,
                afterrender:this.mainAfterrender,
            },
            '#west-region-container treepanel':{                
                selectionchange:this.switchPageFun
            }
        });
    },
    mainBeforerender:function(panel){
        Ext.Ajax.defaultHeaders={'token':sessionStorage.omcToken};
        Ext.Ajax.timeout=3000000;
        Ext.Ajax.on('requestcomplete',function(conn,response,options,e){
            var s;
            // 当返回失败的时候的提示，先注释掉
            // if(response && response.responseText && !options.isUpload){ 
            //     s=JSON.parse(response.responseText); 
            //     if(s.success==false){
            //         Ext.Msg.alert('温馨提示', s.msg);
            //     }              
            // } 


            // if(response && response.responseText){ 
            //     s=JSON.parse(response.responseText);         
            // }
            // if(s.success==false){
            //     Ext.Msg.alert('温馨提示', s.msg);
            // }              
            
       });
    },
    mainAfterrender:function(panel){

        // 树型导航需要添加的
            
        // *********************
        
//        Ext.Ajax.on('requestcomplete',function(conn,response,options,e){
//            var s=response.responseText;
//            if(s=="sessionout" && lockScreenFlag==false){
//            	goToLogin();
//            }
//        });
//         if(sessionStorage.omcChangePwd=='true'){
//         	Ext.widget('resetpasswordwin');
//         }
        // createLeftMenu(sessionStorage.omcFunctions,sessionStorage.omcIsAdmin); //暂时先注释掉
//     	refreshTimeFunction();
        openWebsocket();//websocket接收服务端推送
//         //setMap();
//         this.getSystemParameter();
//         this.lockScreen();
//         createMapData(1);
//         Ext.getStore('monitor.GetDeviceExListStore').load();
//         Ext.Ajax.request({  
// 			url:'monitor/alarm/getLastCurAlarm',
// 			success:function(response,option){
// 				var result=Ext.JSON.decode(response.responseText);
// 				if(result.root!=null){
//                     playSound();
// 					Ext.getStore('main.CurAlarmStore').loadData([{
// 						name:'设备ID',value:result.device.id
// 					},{
// 						name:'设备名称',value:result.device.name
// 					},{
// 						name:'告警名称',value:result.root.name
// //					},{
// //						name:'告警类型',value:result.root.alarmType
// 					},{
// 						name:'告警级别',value:result.root.grade
// 					},{
// 						name:'告警时间',value:result.root.updateTimeString
// 					}]);
// 				}
// 			}
// 		});
    },
    areaTreeSelectionchangeFun:function(tree,selected){
        if(selected.length==0)
            return;
        var record=selected[selected.length-1];
        var id=record.get('id');
        selectAreaInMap(record);

        if(id.indexOf('area_')>-1){
            id = id.replace('area_','');
            createMapData(id);
        }
    },
    onLogin:function(btn){
        btn.setDisabled(true);
        var f=Ext.getCmp('loginform');
        if(f&&f.isValid()){
            f.submit({
                waitMsg :'正在登录...',
                url:'safe/user/login',
                success:function(form, action){
                    f.up('window').close();
                    checkSession();
                },
                failure:function(form, action){
                    if(action.failreType=="connect"){
                        alert('错误1', '状态:'+action.response.status+':'+
                            action.response.statusText, Ext.Msg.ERROR);
                        btn.setDisabled(false);
                        return;
                    }
                    if(action.result){
                        if(action.result.msg){
                            alert(action.result.msg);
                        }
                    }
                }
            });
        }
        btn.setDisabled(false);
    },
    unLock:function(btn){
        btn.setDisabled(true);
        var f=Ext.getCmp('unLockForm');
        if(f&&f.isValid()){
            f.submit({
                waitMsg :'正在登录...',
                url:'safe/user/login',
                params:{userName:sessionStorage.omcLoginName},
                success:function(form, action){
                    f.up('window').close();
                    lockScreenFlag=false;
                    sessionStorage.omcFunctions=action.result.functions;
                    sessionStorage.omcIsAdmin=action.result.isAdmin;
                    sessionStorage.omcToken=action.result.token;
                    Ext.Ajax.defaultHeaders={'Authorization':sessionStorage.omcToken};
                },
                failure:function(form, action){
                    if(action.failreType === "connect"){
                        alert('错误1', '状态:'+action.response.status+':'+
                            action.response.statusText, Ext.Msg.ERROR);
                        btn.setDisabled(false);
                        return;
                    }
                    if(action.result){
                        if(action.result.msg){
                            alert(action.result.msg);
                        }
                    }
                }
            });
        }
        btn.setDisabled(false);
    },
    switchPageFun:function(ts,record){
        var me=this;
        var key=record[0].raw.action;
        var text=record[0].raw.text;
        var cmp=Ext.getCmp('mainTab');
        // if(key=="openInWeekPlanPanel"){
        //     me.getController('plan.InWeekPlanController');
        //     var tabId="tab_inWeekPlanController";
        //     addTab(cmp,tabId,{id:tabId,title:text,xtype:'inweekplanpanel',closable:true});
        // }
        // if(key=="openInWeekMouldPanel"){
        //     me.getController('plan.InWeekMouldController');
        //     var tabId="tab_inWeekMouldController";
        //     addTab(cmp,tabId,{id:tabId,title:text,xtype:'inweekmouldpanel',closable:true});
        // }
        // if(key=="openOutWeekPlanPanel"){
        //     me.getController('plan.OutWeekPlanController');
        //     var tabId="tab_outWeekPlanController";
        //     addTab(cmp,tabId,{id:tabId,title:text,xtype:'outweekplanpanel',closable:true});
        // }
        // if(key=="openSixDayPlanPanel"){
        //     me.getController('plan.SixDayPlanController');
        //     var tabId="tab_sixDayPlanController";
        //     addTab(cmp,tabId,{id:tabId,title:text,xtype:'sixdayplanpanel',closable:true});
        // }
        // if(key=="openMonitorPanel"){
        //     var tabId="tab_monitorPanel";
        //     addTab(cmp,tabId,{id:tabId,title:text,xtype:'monitorpanel',closable:true});
        // }
        // if(key=="openPollingPanel"){
        // 	me.getController('task.PollingController');
        //     var tabId="tab_pollingPanel";
        //     addTab(cmp,tabId,{id:tabId,title:text,xtype:'pollingpanel',closable:true});
        // }
        // if(key=="openBatchPlanPanel"){
        // 	me.getController('task.BatchController');
        //     var tabId="tab_batchPlanPanel";
        //     addTab(cmp,tabId,{id:tabId,title:text,xtype:'batchplanpanel',closable:true});
        // }
        // if(key=="openUpgradePlanPanel"){
        // 	me.getController('task.UpgradeController');
        // 	var tabId="tab_upgradePlanPanel";
        // 	addTab(cmp,tabId,{id:tabId,title:text,xtype:'upgradeplanpanel',closable:true});
        // }
        // if(key=="openCurAlarmPanel"){
        //     me.getController('monitor.AlarmController');
        //     var tabId="tab_curAlarmPanel";
        //     addTab(cmp,tabId,{id:tabId,title:text,xtype:'curalarmpanel',closable:true});
        // }
        // if(key=="openHisAlarmPanel"){
        //     me.getController('monitor.AlarmController');
        //     var tabId="tab_hisAlarmPanel";
        //     addTab(cmp,tabId,{id:tabId,title:text,xtype:'hisalarmpanel',closable:true});
        // }


        // if(key=="openAlarmGradePanel"){
        //     me.getController('base.AlarmSettingController');
        //     var tabId="tab_alarmGradePanel";
        //     addTab(cmp,tabId,{id:tabId,title:text,xtype:'alarmsettingpanel',closable:true});
        // }
        // if(key=="openSystemSettingPanel"){
        //     me.getController('base.SystemSettingController');
        //     var tabId="tab_systemSettingPanel";
        //     addTab(cmp,tabId,{id:tabId,title:text,xtype:'systemSettingPanel',closable:true});
        // }
        // if(key=="openItemPanel"){
        //     me.getController('base.ItemController');
        //     var tabId="tab_itemPanel";
        //     addTab(cmp,tabId,{id:tabId,title:text,xtype:'itempanel',closable:true});
        // }
        // if(key=="openBackupPlanPanel"){
        //     me.getController('task.BackupController');
        //     var tabId="tab_backupPlanPanel";
        //     addTab(cmp,tabId,{id:tabId,title:text,xtype:'backuppanel',closable:true});
        // }
        // if(key=="openVersionPanel"){
        // 	me.getController('base.VersionController');
        //     var tabId="tab_versionPanel";
        //     addTab(cmp,tabId,{id:tabId,title:text,xtype:'versionpanel',closable:true});
        // }
        if(key=="openUserPanel"){
        	me.getController('safe.UserController');
            var tabId="tab_userPanel";
            addTab(cmp,tabId,{id:tabId,title:text,xtype:'userpanel',closable:true});
        }
        // if(key=="openGroupPanel"){
        // 	me.getController('safe.GroupController');
        //     var tabId="tab_groupPanel";
        //     addTab(cmp,tabId,{id:tabId,title:text,xtype:'grouppanel',closable:true});
        // }
        if(key=="openDepartmentPanel"){
            me.getController('safe.DepartmentController');
            var tabId="tab_departmentPanel";
            addTab(cmp,tabId,{id:tabId,title:text,xtype:'departmentpanel',closable:true});
        }
        if(key=="openRolesPanel"){
            me.getController('safe.RolesController');
            var tabId="tab_rolesPanel";
            addTab(cmp,tabId,{id:tabId,title:text,xtype:'rolespanel',closable:true});
        }
        if(key=="openDictionaryPanel"){
            me.getController('safe.DictionaryController');
            var tabId="tab_dictionaryPanel";
            addTab(cmp,tabId,{id:tabId,title:text,xtype:'dictionarypanel',closable:true});
        }
        // if(key=="openFunctionPanel"){
        // 	me.getController('safe.FunctionController');
        //     var tabId="tab_functionPanel";
        //     addTab(cmp,tabId,{id:tabId,title:text,xtype:'functionpanel',closable:true});
        // }
        // if(key=="openSafeLogPanel"){
        //     var tabId="tab_safeLogPanel";
        //     addTab(cmp,tabId,{id:tabId,title:text,xtype:'safelogpanel',closable:true});
        // }
        // if(key=="openOperateLogPanel"){
        //     var tabId="tab_operateLogPanel";
        //     addTab(cmp,tabId,{id:tabId,title:text,xtype:'operatelogpanel',closable:true});
        // }
        // if(key=="openReportLogPanel"){
        //     var tabId="tab_reportLogPanel";
        //     addTab(cmp,tabId,{id:tabId,title:text,xtype:'reportlogpanel',closable:true});
        // }
        // if(key=="openPerformancePanel"){
        //     me.getController('base.PerformanceController');
        //     var tabId="tab_performancePanel";
        //     addTab(cmp,tabId,{id:tabId,title:text,xtype:'performancepanel',closable:true});
        // }
        // btn.setDisabled(false);
    },
    lockScreen:function(){
        var count = 0;
        var id = window.setInterval(go, 1000);
        function go() {
            count++;
            //console.log(count);
            if(lockScreenFlag==false) {
                //锁屏
                if (count == lockScreenTime) {
                    Ext.Ajax.request({
                        url: 'safe/user/logout',
                        success: function (response, option) {
                            Ext.widget('LockScreen', {
                                title: '操作超时，请输入密码解锁'
                            })
                            lockScreenFlag = true;
                        }
                    });
                }
            }

            //退出登录
            if (count == outScreenTime) {
                clearInterval(id);
                Ext.Ajax.request({
                    url: 'safe/user/logout',
                });
                goToLogin();
            }

        }

        var x ;
        var y ;
        //监听鼠标
        document.onmousemove = function (event) {
            var x1 = event.clientX;
            var y1 = event.clientY;
            if (x != x1 || y != y1) {
                count = 0;
            }
            x = x1;
            y = y1;
        };

        //监听键盘
        document.onkeydown = function () {
            count = 0;
        };
    },

    getSystemParameter:function(){
        var me=this;
        me.store=Ext.create('Mvc.store.base.GetControlParameterStore');
        me.store.load(function(records){
            for(var i=0;i<records.length;i++){
                if(records[i].get('name')=="LockScreenTime"){
                    lockScreenTime=records[i].get('value');
                }else if(records[i].get('name')=="LockOutTime"){
                    outScreenTime=records[i].get('value');
                }else if(records[i].get('name')=="NtpAddress"){
                    ntpAddress=records[i].get('value');
                }else if(records[i].get('name')=="TaskForMonitorTime"){
                    taskForMonitorTime=records[i].get('value');
                }else if(records[i].get('name')=="ProcessRefreshTime"){
                    processRefreshTime=records[i].get('value');
                }
            }
        });
    }
});
var lockScreenFlag=false;
var lockScreenTime = 300;   //单位：秒
var outScreenTime = 900;   //单位：秒
var ntpAddress = null;
var taskForMonitorTime = 5; //单位：秒
var processRefreshTime = 10; //单位：秒