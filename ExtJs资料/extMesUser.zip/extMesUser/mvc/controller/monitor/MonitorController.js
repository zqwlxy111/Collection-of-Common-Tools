Ext.define('Mvc.controller.monitor.MonitorController',{
	extend:'Ext.app.Controller',
	stores:[
		'node.GetDevicesLikeNameStore',
//		'node.GetAreasLikeNameStore',
		'node.GetDevicesByKeyStore',
		'monitor.GetDeviceExListStore',
		'monitor.GetParamsStore',
		'monitor.GetParamsByTypeStore',
		'monitor.GetDeviceAlarmHisStore',
        'monitor.GetTimeslotHisStore',
		'base.GetParamTypeStore',
		'base.GetTypeIdStore'
	],
	views:[
	   	'monitor.DeviceListPanel',
	   	'monitor.MonitorPanel',
	   	'monitor.DeviceParamPanel',
	   	'monitor.BatchSettingWin',
	   	'monitor.DeviceAlarmHisWin',
        'monitor.TimeslotHisWin'
	],
	init:function(){
        this.control({
        	'#monitor_deviceListGrid':{
        		itemdblclick:this.deviceListGridItemdbClickFun
        	},
        	'deviceparampanel':{
        		afterrender:this.deviceparamgridAfterrenderFun,
        		beforeclose:this.deviceparamgridBeforecloseFun
        	},
        	'devicelistpanel button':{
        		click:this.devicelistpanelClickFun
        	}
        });
    },
    deviceListGridItemdbClickFun:function(grid,record){
		var tabId="tab_monitorPanel";
		addTab(Ext.getCmp('mainTab'),tabId,
				{id:tabId,title:'设备监控',xtype:'monitorpanel',closable:true});
		
		var monitorId='tab_monitor_'+record.get('id');
		addTab(Ext.getCmp('monitor_tabPanel'),monitorId,{
			id:monitorId,
			title:record.get('name'),
			xtype:'deviceparampanel',
			device:record,
			closable:true
		});
    },
    deviceparamgridAfterrenderFun:function(panel){
    	addDeviceMonitor(panel.device.get('id'));
    },
    deviceparamgridBeforecloseFun:function(panel){
    	removeDeviceMonitor(panel.device.get('id'));
    },
    devicelistpanelClickFun:function(btn){
    	btn.setDisabled(true);
    	var key = btn.action;
    	if(key=='monitorAction'){
    		var sel=Ext.getCmp('monitor_deviceListGrid').getSelectionModel().getSelection();
    		if(sel.length == 0){
        		alert('请选择至少一个设备!');
        	}else{
        		var tabId="tab_monitorPanel";
        		addTab(Ext.getCmp('mainTab'),tabId,
        				{id:tabId,title:'设备监控',xtype:'monitorpanel',closable:true});
        		
    	        var monitorId='tab_monitor_'+sel[0].get('id');
    	        addTab(Ext.getCmp('monitor_tabPanel'),monitorId,{
    	        	id:monitorId,
    	        	title:sel[0].get('name'),
    	        	xtype:'deviceparampanel',
    	        	device:sel[0],
    	        	closable:true
    	        });
        	}
    	}else if(key=="exportExcelAction"){
    		Ext.MessageBox.confirm('请确认','确定要导出excel吗?', function(btn){
        		if(btn=='yes'){
        			var store=Ext.getStore('monitor.GetDeviceExListStore');
        			window.open('monitor/monitor/exportDevicesInExcel'+
        					'?areaId='+store.proxy.extraParams.areaId+
        					'&repeaterId='+store.proxy.extraParams.repeaterId+
        					'&name='+store.proxy.extraParams.name+
        					'&areaName='+store.proxy.extraParams.areaName+
        					'&token='+sessionStorage.omcToken);
        		}
        	});
    	}else if(key=='batchSettingAction'){
    		Ext.widget('batchsettingwin',{
    			title:'批量设置参数'
    		});
    	}
    	btn.setDisabled(false);
    }
});