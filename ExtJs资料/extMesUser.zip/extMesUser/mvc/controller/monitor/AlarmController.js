Ext.define('Mvc.controller.monitor.AlarmController',{
	extend:'Ext.app.Controller',
	stores:[
		'monitor.GetCurAlarmsStore',
        'monitor.GetHisAlarmsStore'
	],
	views:[
	   	'monitor.CurAlarmPanel',
        'monitor.HisAlarmPanel'
	],
	init:function(){
        this.control({
        	
        });
    },
    
});