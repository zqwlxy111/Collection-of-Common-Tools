Ext.define('Mvc.controller.plan.OutWeekPlanController',{
    extend:'Ext.app.Controller',
    stores:[
        'plan.GetOutWeekPlanListStore',
        'plan.GetOutWeekPlanLackStore',
        'plan.GetOWPLackDetailStore',
    ],
    views:[
        // 'main.MainTab',
        // 'main.FirstPage',
        'plan.OutWeekPlanPanel',
        'plan.AddWeekPlanWin',
        'plan.WeekPlanUploadWin',
        'plan.OutWeekPlanLackWin',
        'plan.OWPLackTimeWin',
        'plan.OWPLackUpload',
    ],
    init:function(){
        this.control({
            // '#titleToolbar':{
            //     beforerender:this.mainBeforerender,
            //     afterrender:this.mainAfterrender,
            // },
            // '#titleToolbar menuitem':{
                
            //     click:this.switchPageFun
            // }
            // '#weekPlanUploadWin_file':{
            //     afterrender:this.fileUpload
            // }
        });
    },
    // fileUpload:function(){
    //     $('#weekPlanUploadWin_file').change(function(e){
    //         var formData=new FormData();
    //         formData.append('file', e.target.files[0]);
    //         formData.append('token',sessionStorage.omcToken);
    //         $.ajax({ 
    //             url:window.url1+"/owpWeekPlan/upload", 
    //             type:"post", 
    //             data:formData, 
    //             processData:false, 
    //             contentType:false, 
    //             success:function(res){ 
    //                 if(res){ 
    //                     if(res.success==true){
    //                         Ext.Msg.alert('温馨提示', '上传成功！');
    //                     }else{
    //                         Ext.Msg.alert('温馨提示', res.msg);
    //                     }		        
    //                 }
    //         }, 
    //         error:function(err){ 
    //                 Ext.Msg.alert('温馨提示', err);
    //         } 
            
    //         })
    //     })
    // }
});