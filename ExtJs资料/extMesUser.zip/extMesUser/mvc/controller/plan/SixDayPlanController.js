Ext.define('Mvc.controller.plan.SixDayPlanController',{
    extend:'Ext.app.Controller',
    stores:[
        'plan.GetSixDayPlanStore',
        'safe.GetFactoryStore',
        // 'plan.GetOutWeekPlanLackStore',
        // 'plan.GetOWPLackDetailStore'
    ],
    views:[
        'plan.SixDayPlanPanel',
        'plan.AddSixDayPlanWin',
        'plan.SixDayPlanUploadWin',
        'plan.SplitSixDayPlanWin',
        // 'plan.AddWeekPlanWin',
        // 'plan.WeekPlanUploadWin',
        // 'plan.OutWeekPlanLackWin',
        // 'plan.OWPLackTimeWin',
        // 'plan.OWPLackUpload',
    ],
    init:function(){
        this.control({
            // '#titleToolbar':{
            //     beforerender:this.mainBeforerender,
            //     afterrender:this.mainAfterrender,
            // },
            // '#titleToolbar menuitem':{
                
            //     click:this.switchPageFun
            // }
        });
    },
});