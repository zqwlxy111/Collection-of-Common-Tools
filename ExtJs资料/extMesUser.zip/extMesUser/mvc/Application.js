Ext.define('Mvc.Application',{
	extend:'Ext.app.Application',
	name:'Mvc',
	appFolder:'mvc',
	controllers: [
		'MainController',
		// 'monitor.MonitorController'
	],
	autoCreateViewport:true,
	launch: function(){
		Mvc.app=this;
	}
});