/**
 * Created by justinguo on 2016/10/25.
 */
var baseuri={};
baseuri.path = 'http://192.168.13.139/';
baseuri.service = 'http://192.168.13.139/taxi/app/'; //rest 请求路径
// baseuri.path = 'http://'+window.location.host+''/;
// baseuri.service = 'http://'+window.location.host+'/taxi/app/'; //rest 请求路径
//baseuri.local_arcgis_tile = "http://192.168.13.200/map/amap/";          //本地arcgis切片地址（高德底图gcj02）
//baseuri.local_arcgis_google_tile = "http://192.168.13.200/map/google/";          //google地图（gcj02）
baseuri.local_arcgis_tile = baseuri.path + "map/amap/";          //本地arcgis切片地址（高德底图gcj02）
baseuri.local_arcgis_google_tile = "http://taxi.powercn.com/grentechZC/map/amap/";          //google地图（gcj02）
baseuri.remote_tianditu_tile = "http://t2.tianditu.com/DataServer";     //在线天地图
baseuri.configurationFinished = false;

/*$.ajax({
    method: "GET",
    url: "route/isInternalIp",
    dataType: "json",
    success: function (data) {
        if(data.internalIp){
            baseuri.local_arcgis_tile = "http://192.168.13.83/grentechZC/map/amap/";
            baseuri.local_arcgis_google_tile = "http://192.168.13.83/grentechZC/map/amap/";
        }
    }
});*/

var options = {};
options.url = "";
//obsolete property
options.basemapurl = "http://192.168.13.83:9009/arctiler/ogc/services/szmap_1/WMTS/";
options.gispngurl = baseuri.path + 'js/ol/img/';
options.showContextMenu = true;
options.refreshInterval = 5000; //地图实时车辆刷新间隔（毫秒）
//options.maxTerminal = 1000; //最多在地图上显示终端数量。修改为显示第一批数据，具体数量在controller中设置
options.featureType = {'stations':'stations','lines':'lines'};
options.geometryType = {'stations':'Point','lines':'LineString'};
options.featureNS = 'http://exp_taxi';
options.featurePrefix = 'experiment_taxi_data';
options.srsName = 'EPSG:4326';
options.geometryName = 'geometry';

options.matrixIds = [];
options.resolutions = [];
options.matrixIds[0]=8;
options.resolutions[0]=611.496226281411;
options.matrixIds[1]=9;
options.resolutions[1]=305.748113140705;
options.matrixIds[2]=10;
options.resolutions[2]=152.874056570353;
options.matrixIds[3]=11;
options.resolutions[3]=76.4370282851762;
options.matrixIds[4]=12;
options.resolutions[4]=38.2185141425881;
options.matrixIds[5]=13;
options.resolutions[5]=19.1092570712941;
options.matrixIds[6]=14;
options.resolutions[6]=9.55462853564702;
options.matrixIds[7]=15;
options.resolutions[7]=4.77731426782352;
options.matrixIds[8]=16;
options.resolutions[8]=2.38865713391176;
options.matrixIds[9]=17;
options.resolutions[9]=1.19432856695588;
options.matrixIds[10]=18;
options.resolutions[10]=0.597164283477938;


options.originX = -20037508.3427892 - 526.096 - 25; //-地图往左挪
options.originY = 20037508.3430388 + 295.331 + 80;  //+地图往上挪

//深圳（wgs84原点）
options.originX = -20038061.0162311;
options.originY = 20037843.1827692;

//深圳（GCJ原点）
options.originX = -20037508.3427892; //-45
options.originY = 20037508.3430388; //+35

options.center = [114.06667,22.56667];
options.zoom = 12;
options.map_bounds = [109.154663085938, 19.4510540298, 111.5771484375, 22.039821650237];

// 湛江
// options.originX = -20038002.4211221;
// options.originY = 20037794.3860565;
// options.center = [110.333, 21.2787];
// options.zoom = 11;
// options.map_bounds = [109.154663085938, 19.4510540298, 111.5771484375, 22.039821650237];
