if (!window.gisApp) {
    window.gisApp = {};
}
var gisApp = window.gisApp;

// 测量长度
gisApp.Measurement = function(that, options){
    this.mapUtils = that;

    this.wgs84Sphere = new ol.Sphere(6378137);
    this.source_measure = new ol.source.Vector();
    this.layer_measure = null;
    /**
     * Currently drawn feature.
     * @type {ol.Feature}
     */
    this.sketch = null;
    /**
     * The help tooltip element.
     * @type {Element}
     */
    this.helpTooltipElement = null;
    /**
     * Overlay to show the help messages.
     * @type {ol.Overlay}
     */
    this.helpTooltip = null;
    /**
     * The measure tooltip element.
     * @type {Element}
     */
    this.measureTooltipElement = null;
    /**
     * Overlay to show the measurement.
     * @type {ol.Overlay}
     */
    this.measureTooltip = null;
    /**
     * Message to show when the user is drawing a line.
     * @type {string}
     */
    this.continueLineMsg = '双击鼠标开始测量';

    // global so we can remove it later
    this.draw = null;
    /**
     *
     *
     *
     * Handle pointer move.
     * @param {ol.MapBrowserEvent} evt
     */
    this.pointerMoveHandler = function(evt) {
        if (evt.dragging) {
            return;
        } /** @type {string} */
        var helpMsg = '单击鼠标开始画线'; /** @type {ol.Coordinate|undefined} */
        var tooltipCoord = evt.coordinate;
        if (this.sketch) {
            var output;
            var geom = (this.sketch.getGeometry());
            if (geom instanceof ol.geom.LineString) {
                output = this.formatLength(geom);
                helpMsg = this.continueLineMsg;
                tooltipCoord = geom.getLastCoordinate();
            }
            this.measureTooltipElement.innerHTML = output;
            this.measureTooltip.setPosition(tooltipCoord);
        }
        this.helpTooltipElement.innerHTML = helpMsg;
        this.helpTooltip.setPosition(evt.coordinate);
    };

    /**
     * format length output
     * @param {ol.geom.LineString} line
     * @return {string}
     */
    this.formatLength = function(line) {
        var length;
        var coordinates = line.getCoordinates();
        length = 0;
        var sourceProj = mapUtils.map.getView().getProjection();
        for (var i = 0, ii = coordinates.length - 1; i < ii; ++i) {
            var c1 = ol.proj.transform(coordinates[i], sourceProj, 'EPSG:4326');
            var c2 = ol.proj.transform(coordinates[i + 1], sourceProj, 'EPSG:4326');
            length += this.wgs84Sphere.haversineDistance(c1, c2);
        }
        var output;
        if (length > 100) {
            output = (Math.round(length / 1000 * 100) / 100) + ' ' + 'km';
        } else {
            output = (Math.round(length * 100) / 100) + ' ' + 'm';
        }
        return output;
    };
    this.addInteraction();
};

gisApp.Measurement.prototype.addInteraction = function() {
    var type = 'LineString';
    this.draw = new ol.interaction.Draw({
        source: this.source_measure,
        type: type,
        style: new ol.style.Style({
            fill: new ol.style.Fill({
                color: 'rgba(255, 255, 255, 0.2)'
            }),
            stroke: new ol.style.Stroke({
                color: 'rgba(0, 0, 0, 0.5)',
                lineDash: [10, 10],
                width: 2
            }),
            image: new ol.style.Circle({
                radius: 5,
                stroke: new ol.style.Stroke({
                    color: 'rgba(0, 0, 0, 0.7)'
                }),
                fill: new ol.style.Fill({
                    color: 'rgba(255, 255, 255, 0.2)'
                })
            })
        })
    });
    this.draw.on('drawstart', function(evt) {
        // set sketch
        this.sketch = evt.feature;
    }, this);
    this.draw.on('drawend', function(evt) {
        this.measureTooltipElement.className = 'tooltip tooltip-static';
        this.measureTooltip.setOffset([0, -7]);
        // unset sketch
        this.sketch = null;
        // unset tooltip so TOP_WINDOW a new one can be created
        this.measureTooltipElement = null;
        this.createMeasureTooltip();
    }, this);
};
/**
 * Creates a new help tooltip
 */
gisApp.Measurement.prototype.createHelpTooltip = function () {
    if (this.helpTooltipElement) {
        this.helpTooltipElement.parentNode.removeChild(this.helpTooltipElement);
        this.helpTooltipElement = null;
    }
    this.helpTooltipElement = document.createElement('div');
    this.helpTooltipElement.className = 'tooltip';
    this.helpTooltipElement.id = "mytooltip";

    this.helpTooltip = new ol.Overlay({
        element: this.helpTooltipElement,
        offset: [15, 0],
        positioning: 'center-left'
    });
    mapUtils.map.addOverlay(this.helpTooltip);
};
/**
 * Creates a new measure tooltip
 */
gisApp.Measurement.prototype.createMeasureTooltip = function () {
    if (this.measureTooltipElement) {
        this.measureTooltipElement.parentNode.removeChild(this.measureTooltipElement);
        this.measureTooltipElement = null;
    }
    this.measureTooltipElement = document.createElement('div');
    this.measureTooltipElement.className = 'tooltip tooltip-measure';
    this.measureTooltip = new ol.Overlay({
        element: this.measureTooltipElement,
        offset: [0, -15],
        positioning: 'bottom-center'
    });
    mapUtils.map.addOverlay(this.measureTooltip);
};

gisApp.Measurement.prototype.turnOn = function(){
    mapUtils.Clear();
    this.source_measure.clear();
    this.layer_measure = new ol.layer.Vector({
        source: this.source_measure,
        style: new ol.style.Style({
            fill: new ol.style.Fill({
                color: 'rgba(255, 255, 255, 0.2)'
            }),
            stroke: new ol.style.Stroke({
                color: '#ffcc33',
                width: 2
            }),
            image: new ol.style.Circle({
                radius: 7,
                fill: new ol.style.Fill({
                    color: '#ffcc33'
                })
            })
        })
    });
    mapUtils.map.addLayer(this.layer_measure);
    this.createMeasureTooltip();
    this.createHelpTooltip();
    mapUtils.map.on('pointermove', this.pointerMoveHandler,this);
    mapUtils.mapEvents['pointermove'] = this.pointerMoveHandler;
    mapUtils.mapEventsHolder['pointermove'] = this;
    //mapUtils.map.addInteraction(this.draw);
    mapUtils.mapInteractions.push(this.draw);
};

gisApp.Measurement.prototype.turnOff = function(){
    mapUtils.Clear();
    mapUtils.map.removeLayer(this.layer_measure);
    // mapUtils.map.getOverlays().clear();
    //
    // if (this.helpTooltipElement) {
    //     this.helpTooltipElement.parentNode.removeChild(this.helpTooltipElement);
    //     this.helpTooltipElement = null;
    // }
    // if (this.measureTooltipElement) {
    //     this.measureTooltipElement.parentNode.removeChild(this.measureTooltipElement);
    //     this.measureTooltipElement = null;
    // }
    //
    // mapUtils.map.removeInteraction(this.draw);
    //
    //
    // mapUtils.map.un(event,mapUtils.mapEvents['pointermove'],mapUtils.mapEventsHolder['pointermove']);
    // delete mapUtils.mapEvents['pointermove'];
    // delete mapUtils.mapEventsHolder['pointermove'];
};