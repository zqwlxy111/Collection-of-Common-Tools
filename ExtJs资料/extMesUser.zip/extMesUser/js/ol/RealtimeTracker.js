/**
 * Created by justinguo on 2016/10/25.
 */
if (!window.gisApp) {
    window.gisApp = {};
}
var gisApp = window.gisApp;

// 实时轨迹
gisApp.RealtimeTracker = function(that, options) {
    this.mapUtils = that;

    this.styleCache = [];
    this.pointStyle = new ol.style.Circle({
        radius: 5,
        fill: new ol.style.Stroke({
            color: 'rgba(255,0,0,0.5)',
            width: 1
        }),
        stroke: new ol.style.Stroke({
            color: 'rgba(255,0,0,0.9)',
            width: 1
        })
    });
    this.lineStyle = new ol.style.Stroke({
        color: 'rgba(255,0,0,0.9)',
        width: 1
    });

    this.source_tracks = new ol.source.Vector({
        format: new ol.format.GeoJSON()
    });
    this.layer_tracks = null;

    this.cache = [];


    this.trackingFeature = null;
    this.monitorFeatures = new ol.Collection();
    this.point = null;
    this.line = null;
    this.displaySnap = function(coordinate) {
        var closestFeature = this.source_tracks.getClosestFeatureToCoordinate(coordinate);
        //var info = document.getElementById('info');
        if (closestFeature === null) {
            this.point = null;
            this.line = null;
            //info.innerHTML = '&nbsp;';
        } else {
            var geometry = closestFeature.getGeometry();
            var closestPoint = geometry.getClosestPoint(coordinate);
            if (this.point === null) {
                this.point = new ol.geom.Point(closestPoint);
            } else {
                this.point.setCoordinates(closestPoint);
            }
            //var date = new Date(closestPoint[2]);
            //info.innerHTML = closestFeature.get('name') + ' (' + date.toLocaleString() + ')';
            //var key = closestFeature.get('name')+closestPoint[2].toString().substr(0,9);
            // info.innerHTML += " 速度"+this.cache[key+'speed'];
            // info.innerHTML += " 方向"+this.cache[key+'direction'];
            // info.innerHTML += " 温度"+this.cache[key+'temp'];

            var coordinates = [coordinate, [closestPoint[0], closestPoint[1]]];
            if (this.line === null) {
                this.line = new ol.geom.LineString(coordinates);
            } else {
                this.line.setCoordinates(coordinates);
            }
        }
        mapUtils.map.render();
    };
};

gisApp.RealtimeTracker.prototype.TraceStyle = function(feature, resolution) {
    var id = feature.getId();

    var style = this.styleCache[id];
    if (!style) {
        var r = parseInt(200*Math.random());
        var g = parseInt(200*Math.random());
        var b = parseInt(200*Math.random());

        style = [new ol.style.Style({
            stroke: new ol.style.Stroke({
                color: "rgb("+r+","+g+","+b+")",
                width: 3
            })
        })];
        this.styleCache[id] = style;
    }
    return style;
}

gisApp.RealtimeTracker.prototype.tracePointerMove = function(evt) {
    if (evt.dragging) {
        return;
    }
    var coordinate = mapUtils.map.getEventCoordinate(evt.originalEvent);
    //this.displaySnap(coordinate);
};

gisApp.RealtimeTracker.prototype.clickEvent = function(evt) {
    //this.displaySnap(evt.coordinate);
};

gisApp.RealtimeTracker.prototype.drawTrackers = function(evt) {
    var vectorContext = evt.vectorContext;
    if (this.point !== null) {
        vectorContext.setImageStyle(this.pointStyle);
        vectorContext.drawGeometry(this.point);
        mapUtils.panToPoint(this.point.getCoordinates());
    }
    if (this.line !== null) {
        vectorContext.setFillStrokeStyle(null, this.lineStyle);
        vectorContext.drawGeometry(this.line);
    }
};

gisApp.RealtimeTracker.prototype.turnOn = function() {
    this.layer_tracks = new ol.layer.Vector({
        visible: true,
        source: this.source_tracks,
        style: $.proxy(mapUtils.realtimeTracker.TraceStyle, mapUtils.realtimeTracker)
    });
    //mapUtils.map.removeLayer(mapUtils.layer_cars);
    mapUtils.map.addLayer(this.layer_tracks);
    //mapUtils.map.addLayer(mapUtils.layer_cars);
    mapUtils.map.on('pointermove', this.tracePointerMove, this);
    mapUtils.map.on('click', this.clickEvent, this);
    mapUtils.map.on('postcompose', this.drawTrackers, this);
    mapUtils.mapEvents['pontermove'] = this.tracePointerMove;
    mapUtils.mapEvents['click'] = this.clickEvent;
    mapUtils.mapEvents['postcompose'] = this.drawTrackers;
    mapUtils.mapEventsHolder['pontermove'] = this;
    mapUtils.mapEventsHolder['click'] = this;
    mapUtils.mapEventsHolder['postcompose'] = this;
};

gisApp.RealtimeTracker.prototype.turnOff = function() {
    this.cache = [];
    this.styleCache = [];
    this.source_tracks.clear();

    this.monitorFeatures.clear();
    this.trackingFeature = null;
    //mapUtils.map.removeLayer(mapUtils.layer_cars);
    this.mapUtils.map.removeLayer(this.layer_tracks);
    //mapUtils.map.addLayer(mapUtils.layer_cars);
    this.layer_tracks = null;
    this.mapUtils.Clear();
    this.mapUtils.switchMapStatus(gisApp.MAP_STATE.REALTIME);

    // mapUtils.map.un(event,mapUtils.mapEvents['pontermove'],mapUtils.mapEventsHolder['pontermove']);
    // mapUtils.map.un(event,mapUtils.mapEvents['click'],mapUtils.mapEventsHolder['click']);
    // mapUtils.map.un(event,mapUtils.mapEvents['postcompose'],mapUtils.mapEventsHolder['postcompose']);
    // delete mapUtils.mapEvents['pontermove'];
    // delete mapUtils.mapEventsHolder['pontermove'];
    // delete mapUtils.mapEvents['click'];
    // delete mapUtils.mapEventsHolder['click'];
    // delete mapUtils.mapEvents['postcompose'];
    // delete mapUtils.mapEventsHolder['postcompose'];
};

// 添加数据
gisApp.RealtimeTracker.prototype.AppendTraceData = function (point) {
    //if(this.monitorFeatures.getLength()==0) return;
    if(this.trackingFeature==null) return;

    var geo = new ol.format.GeoJSON().writeFeature(point);
    geo = geo.replace('"type":"Point"','"type":"LineString"')
        .replace('"coordinates":[','"coordinates":[[')
        .replace(']},"properties"',']]},"properties"');
    var f = (new ol.format.GeoJSON()).readFeature(geo);


    var feature = this.source_tracks.getFeatureById(f.getId());
    //属于监控车辆
    if(f.getId()==this.trackingFeature.getId()) {
        var geometry;
        if (feature) {
            geometry = feature.getGeometry();
            var coord1 = geometry.getCoordinates();
            var coord2 = f.getGeometry().getCoordinates();
            var coord = coord1.concat(coord2);
            feature.getGeometry().setCoordinates(coord);
            geometry.layout = 'XYM';
        }
        else {
            geometry = f.getGeometry();
            geometry.layout = 'XYM';
            this.source_tracks.addFeature(f);
        }
        this.mapUtils.panToGeometry(geometry);
        // var key = point.get('name') + point.getGeometry().getCoordinates()[2].toString().substr(0,9);
        // this.cache[key+'speed'] = f.get('speed');
        // this.cache[key+'direction'] = f.get('direction');
        // this.cache[key+'temp'] = f.get('temp');
        mapUtils.map.render();
    }
};