if (!window.gisApp) {
    window.gisApp = {};
}
var gisApp = window.gisApp;

// 弹出框
gisApp.Popup = function (that, options) {
    this.mapUtils = that;

    this.popup = new ol.Overlay({
        element: options.element,
        positioning: 'bottom-right',
        autoPan: false,
        stopEvent: true
    });
    // 选择事件，更改样式
    this.sel_interaction = new ol.interaction.Select({
        style: $.proxy(that.style_sel_func, that),
        layers: [that.layer_cars,that.canvas.vectorLayer],
        condition: ol.events.condition.pointerMove
    });
    // 选择事件，获取信息
    this.sel_interaction.on('select', function (e) {
        if (e.deselected.length > 0)
            this.popup.setPosition(undefined);
        if (e.selected.length > 0) {
            var sel = e.selected[0];
            var name = sel.get('name');
            var id = sel.getId();

            var coord = sel.getGeometry().getCoordinates();
            var info;

            
            switch (sel.get("type")) {
                case 'gathering':
                    info = '该区域在' + sel.get("happeningTime") + '发生聚集事件';
                    break;
                case 'sta':
                    info = 'ID：' + id + ' 名称：' + name + ' 方向：' + sel.get('direction') + ' 坐标：' + coord;
                    break;
                default :
                    //coord = coord[0].toFixed(6) + ',' + coord[1].toFixed(6);
                    info = '车牌：' + sel.get("carNo") +
                        '<br/>司机工号：' + sel.get("driverNo") +
                        '<br/>司机姓名：' + sel.get("driverName") +
                        '<br/>司机电话：' + sel.get("driverTel") +
                        '<br/>公司：' + sel.get("companyName") +
                        '<br/>车型：' + sel.get("carSerialNum") +
                        '<br/>速度：' + sel.get('speed') +
                        '<br/>方向：' + gisApp.Common.FormatDirection(sel.get('angle')) +
                        '<br/>车载电话：' + sel.get('carPhone') +
                        '<br/>车辆状态：' + sel.get('stateText') +
                        '<br/>时间：' + sel.get('normalTime');

            }
            this.popup.setPosition(e.mapBrowserEvent.coordinate);
            //document.getElementById('info').innerHTML = info;
            document.getElementById('popup').innerHTML = info;
        }
    }, this);
};

// change mouse cursor when over marker
gisApp.Popup.prototype.changeCursor = function (e) {
    var pixel = this.mapUtils.map.getEventPixel(e.originalEvent);
    var hit = this.mapUtils.map.hasFeatureAtPixel(pixel);

    document.getElementById('map').style.cursor = hit ? 'pointer' : '';
};

gisApp.Popup.prototype.turnOn = function () {
    //mapUtils.map.addInteraction(this.sel_interaction);
    this.mapUtils.mapInteractions.push(this.sel_interaction);
    this.mapUtils.map.addOverlay(this.popup);
    this.mapUtils.map.on('pointermove', this.changeCursor, this);
    this.mapUtils.mapEvents['pointermove'] = this.changeCursor;
    this.mapUtils.mapEventsHolder['pointermove'] = this;
};
