if (!window.gisApp) {
    window.gisApp = {};
}
var gisApp = window.gisApp;

gisApp.CustomCtrl = function(that, options) {
    this.mapUtils = that;
    gisApp.CustomCtrl.MapInstance = that;
    // 地图车辆总数
    // this.InfoLabel_ = null;
    // ol.inherits(this.InfoLabelCtrl, ol.control.Control);

    this.context_overlay;

    // 显示实时轨迹
    this.RealtimeTraceState = false;
    this.RealtimeTraceCtrlButton_ = null;
    ol.inherits(this.RealtimeTraceCtrl, ol.control.Control);

    // 测量长度
    this.MeasureState = false;
    this.MeasureCtrlButton_ = null;
    ol.inherits(this.MeasureCtrl, ol.control.Control);

    // 速度热力图
    this.SpeedHeapmapCtrlButton_ = null;
    ol.inherits(this.SpeedHeapmapCtrl, ol.control.Control);

    // 热力图层
    this.heatmap_vector = new ol.layer.Heatmap({
        source: that.source_cars,
        blur: 25,
        radius: 10
    });
    this.HeapmapCtrlButton_ = null;
    ol.inherits(this.HeapmapCtrl, ol.control.Control);


    this.last_click_toolbar_item = null;
    // 聚合图层


    this.ClusterCtrlButton_ = null;
    this.realTimeLayer_ = that.layer_cars;
    this.source_cluster = new ol.source.Cluster({
        distance: 50,
        source: that.source_cars
    });

    this.source_cluster.on("change",this.FeatureChanged,this);
    this.styleCache = {};
    this.layer_clusters = null;
    ol.inherits(this.ClusterCtrl, ol.control.Control);

    ol.inherits(this.TracePlayerCtrl, ol.control.Control);
    ol.inherits(this.RightPrimaryCtrl, ol.control.Control);
    ol.inherits(this.LeftPanelCtrl, ol.control.Control);
    ol.inherits(this.ToolbarCtrl, ol.control.Control);
    //ol.inherits(this.Statusbar, ol.control.Control);

    this.ctrlState = gisApp.CTRL_STATE.CAR;

};

gisApp.CustomCtrl.MapInstance = null;

//重新载入实时跟踪子菜单
gisApp.CustomCtrl.ReloadMonitorSubmenu = function (that) {

    var li = document.getElementById("MonitorTerminalEle");
    var disabled = "";
    var a = li.childNodes[0];
    a.removeAttribute("onclick");

    if(that.mapUtils.hoveringFeature) {
        a.innerHTML = "<img src='/taxi/static/gis/img/observation.png'/>跟踪定位";
        a.setAttribute("onclick","gisApp.CustomCtrl.MonitorTerminalHandler()");
    }

    var trackingFeature = that.mapUtils.realtimeTracker.trackingFeature;
    if(trackingFeature!=null && !that.mapUtils.hoveringFeature){
        a.innerText = "取消跟踪(" + trackingFeature.get("name") + ")";
        a.setAttribute("onclick","gisApp.CustomCtrl.ExitMonitorTeriminal('" + trackingFeature.getId() + "')");
    }

    if(trackingFeature==null && !that.mapUtils.hoveringFeature)
        li.className="disabled";
    else
        li.className="";


    // if(that.mapUtils.realtimeTracker.monitorFeatures.getLength()>0){
    //
    //     li.className = "dropdown-submenu";
    //     var sub = "<a href='#' onclick='gisApp.CustomCtrl.MonitorTerminalHandler(' + that + ');'>跟踪定位</a><ul class='dropdown-menu'><li><a onclick='gisApp.CustomCtrl.ExitMonitorTeriminal();'>退出实时监控</a></li>";
    //     that.mapUtils.realtimeTracker.monitorFeatures.forEach(function(ele,index,array){
    //         sub = sub + "<li><span><a href='#' class='fa fa-recycle' onclick=gisApp.CustomCtrl.ExitMonitorTeriminal('" + ele.getId() + "');>" + ele.getId() + "</a></span></li>";
    //     });
    //     sub = sub + "</ul>";
    //     li.innerHTML = sub;
    // }
    // else{
    //     if(!that.mapUtils.hoveringFeature)
    //         li.className="disabled";
    //     else
    //         li.className="";
    // }

    var selectcar = that.mapUtils.hoveringFeature;

    if(selectcar!=null&&selectcar!=undefined)
    {
        //var cmd1 = document.getElementById("cmd1");
        var cmd2 = document.getElementById("cmd2");
        var cmd3 = document.getElementById("cmd3");
        var cmd4 = document.getElementById("cmd4");

        //cmd1.style.display="";
        cmd2.style.display="";
        cmd3.style.display="";
        cmd4.style.display="";

    }

    else
    {
        //var cmd1 = document.getElementById("cmd1");
        var cmd2 = document.getElementById("cmd2");
        var cmd3 = document.getElementById("cmd3");
        var cmd4 = document.getElementById("cmd4");
        //cmd1.style.display="none";
        cmd2.style.display="none";
        cmd3.style.display="none";
        cmd4.style.display="none";

    }
}

//跟踪定位
gisApp.CustomCtrl.MonitorTerminalHandler = function () {

    var that = gisApp.CustomCtrl.MapInstance;
    var feature = that.hoveringFeature;
    if(feature) {
        //that.realtimeTracker.monitorFeatures.append(feature);
        that.realtimeTracker.trackingFeature = feature;
        that.switchMapStatus(gisApp.MAP_STATE.TRACING);
        that.customCtrl.context_overlay.setPosition(undefined);
    }
    //ReloadMonitorSubmenu();
}

//退出跟踪定位
gisApp.CustomCtrl.ExitMonitorTeriminal = function(feature) {
    var that = gisApp.CustomCtrl.MapInstance;

    // if(!feature)
    //     that.realtimeTracker.turnOff();
    // else{
    //     that.realtimeTracker.trackingFeature = null;
    //     that.realtimeTracker.monitorFeatures.remove(feature);
    // }
    that.realtimeTracker.turnOff();
    //gisApp.CustomCtrl.ReloadMonitorSubmenu(that);
    that.customCtrl.context_overlay.setPosition(undefined);
}

//切换车辆状态条件
gisApp.CustomCtrl.SwitchTaxiStateCondition = function(){
    var target = window.event.srcElement || window.event.target;
    if(target.tagName == "A") {
        if (target.className == "glyphicon glyphicon-ok")
            target.className = "";
        else
            target.className = "glyphicon glyphicon-ok";
    };

    gisApp.CustomCtrl.composeFilter();
}

//组合过滤条件; 调用时不清除几何查询条件，清除Feature查询条件
gisApp.CustomCtrl.composeFilter = function(geo,showlist){

    //that is MapUtils instance.
     var that = gisApp.CustomCtrl.MapInstance;

    that.terminalFilter.Filters.splice(0,that.terminalFilter.Filters.length);

    if(geo){
        that.terminalFilter.Geometry = geo;
        that.terminalFilter.SpatialOperator = gisApp.SPATIAL_OPERATOR.WithIn;
    }
    //关键字
    var txtKey = document.getElementById("txtKeyword");
    if(txtKey!=null && txtKey.value.length>0) {
        var condition = gisApp.FeatureFilter;
        condition.PropertyName = "name";
        condition.Expression = document.getElementById("txtKeyword").value;
        condition.RelationExpression = gisApp.RELATION_EXPRESSION.Like;
        condition.LogicalOperator = gisApp.LOGICAL_OPERATOR.And;
        that.terminalFilter.Filters.push(condition);
    }

    //company
    var sel_comp = document.getElementById("ddlCompany");
    if(sel_comp!=null && sel_comp.value!="-1"){
        var condition = gisApp.FeatureFilter;
        condition.PropertyName = "companyId";
        condition.Expression = sel_comp.value;
        condition.RelationExpression = gisApp.RELATION_EXPRESSION.Equal;
        that.terminalFilter.Filters.push(condition);
    }

    //车辆状态
    $("a.glyphicon").each(function(index,ele){
        var state = ele.innerText;
        if(state!="") {
            var condition = gisApp.Common.CreateFeatureFilter(); //gisApp.FeatureFilter;
            condition.PropertyName = "stateText";
            condition.Expression = state;
            condition.RelationExpression = gisApp.RELATION_EXPRESSION.Like;
            //condition.LogcialOperator
            that.terminalFilter.Filters.push(condition);
        }
    });

    that.dataUpdatedEvent = function(data) {
        //延迟载入查询结果
        if(showlist)
            loadTerminalSearchResult();
        that.dataUpdatedEvent = null;
    }

    that.RefreshImmediate();

    //document.getElementById("PrimaryHolder").innerHTML = "正在载入查询结果...";
}


//初始化右键菜单
gisApp.CustomCtrl.prototype.InitializeContextMenu = function(){

    if(document.getElementById("contextmenu_container")==null) {
        var doc_map = this.mapUtils.map.getTargetElement();
        $(doc_map).append(this.contextMenu_);
    }

    this.context_overlay = new ol.Overlay({
        element: document.getElementById("contextmenu_container"),
        positioning: 'right-center'
    });
    this.context_overlay.setMap(this.mapUtils.map);

    //右键事件函数
    $(this.mapUtils.map.getViewport()).on("contextmenu",$.proxy(function(e){
        e.preventDefault();
        var coord = this.mapUtils.map.getEventCoordinate(e);

        //正在编辑状态时，屏蔽右键菜单
        //it's more proper move following code to 'canvas'.
        var existing=false;
        this.mapUtils.map.getInteractions().forEach(function(ele,index,arr){
            if(ele instanceof ol.interaction.Draw){
                existing=true;
            }
        });

        if(existing) return;

        var pixel = this.mapUtils.map.getEventPixel(e);
        var hit = this.mapUtils.map.hasFeatureAtPixel(pixel);
        this.mapUtils.hoveringFeature=null;

        if(hit) {
            this.mapUtils.map.forEachFeatureAtPixel(pixel, function (feature, layer) {
                if(layer.getSource()===this.mapUtils.source_cars) {
                    this.mapUtils.hoveringFeature = feature;
                    this.mapUtils.customCtrl.context_overlay.setPosition(coord);

                }

            });
        }

    },this));

    $(this.mapUtils.map.getViewport()).on("click",$.proxy(function(e){

        var pixel = this.mapUtils.map.getEventPixel(e);
        var hit = this.mapUtils.map.hasFeatureAtPixel(pixel);
        this.mapUtils.hoveringFeature=null;

        if(hit) {
            this.mapUtils.map.forEachFeatureAtPixel(pixel, function (feature, layer) {
                if(layer.getSource()===this.mapUtils.source_cars) {
                    this.mapUtils.hoveringFeature = feature;


                    var getParamsStore=Ext.create('Mvc.store.monitor.GetParamsStore');
                    getParamsStore.proxy.extraParams={'deviceId':feature.get('uid')};
                    getParamsStore.load(function(records) {
                        if (records != null) {
                            var rs1 = [];
                            var rs2 = [];
                            for (var i = 0; i < records.length; i++) {
                                if (records[i].get('groupName') == '告警和状态' && records[i].get('displayValue') == "告警")
                                    rs1.push(records[i]);

                                if (records[i].get('groupName') == '实时采样数据')
                                    rs2.push(records[i]);
                            }
                            Ext.getCmp('map_alarmParamList').store.loadData(rs1);
                            Ext.getCmp('map_dataParamList').store.loadData(rs2);
                        }
                    });
                }

            });
        }
        this.context_overlay.setPosition(undefined);
    },this));

};

//轨迹播放器
gisApp.CustomCtrl.prototype.TracePlayerCtrl = function(customCtrl, opt_options){
    var options = opt_options || {};
    var element = document.createElement('div');
    element.className = 'traceHolder';
    element.id = "traceHolder";
    element.setAttribute("onmouseover","this.style.opacity=0.9");
    element.setAttribute("onmouseout","this.style.opacity=0.5");
    ol.control.Control.call(this, {
        element: element,
        target: options.target
    });
};

//地图左侧控件
gisApp.CustomCtrl.prototype.LeftPanelCtrl = function(customCtrl, opt_options){
    var options = opt_options || {};
    var element = document.createElement('div');
    element.className = 'LeftPanelHolder';
    element.id = "LeftPanelHolder";
    //默认不显示
    //element.innerHTML = customCtrl.featureSearch_;

    ol.control.Control.call(this, {
        element: element,
        target: options.target
    });
};

//状态栏
gisApp.CustomCtrl.prototype.Statusbar = function(customCtrl, opt_options){
    var options = opt_options || {};
    var element = document.createElement('div');
    element.className = 'StatusbarHolder';
    element.id = "StatusbarHolder";

    element.innerHTML = customCtrl.MapLegendDisplay_;

    ol.control.Control.call(this, {
        element: element,
        target: options.target
    });
};

//地图中间工具栏
gisApp.CustomCtrl.prototype.ToolbarCtrl = function(customCtrl, opt_options){
    var options = opt_options || {};
    var element = document.createElement('div');
    element.className = 'ToolbarHolder';
    element.id = "ToolbarHolder";
    element.innerHTML = customCtrl.historyTrack_;

    // element.onclick = function(e){
    //     if(this.last_click_toolbar_item)
    //         this.last_click_toolbar_item.className = null;
    //
    //     var leftPanel = document.getElementById("LeftPanelHolder");
    //     if((this.last_click_toolbar_item!=e.srcElement || leftPanel.innerHTML=="") && e.srcElement.tagName == "A"){
    //
    //         customCtrl.mapUtils.canvas.Clear();
    //         e.srcElement.className = "selected"
    //         document.getElementById("PrimaryHolder").innerHTML = "";
    //         //customCtrl.mapUtils.Clear();
    //         this.last_click_toolbar_item = e.srcElement;
    //         //根据不同的cmd_name显示不同的面板
    //         var html = eval('mapUtils.customCtrl.' + e.srcElement.dataset.cmd_name);
    //         leftPanel.innerHTML = (html) ? html : "";
    //         //查询
    //         if(e.srcElement.dataset.cmd_name=="featureSearch_")
    //             LoadCompany()
    //         //围栏
    //         if(e.srcElement.dataset.cmd_name=="fenceEditor_")
    //             LoadFence();
    //         //重点区域
    //         if(e.srcElement.dataset.cmd_name=="impRegionEditor_")
    //             LoadImpRegion();
    //         //历史轨迹
    //         if(e.srcElement.dataset.cmd_name!="historyTrack_")
    //             customCtrl.mapUtils.switchMapStatus(gisApp.MAP_STATE.REALTIME);
    //     }
    //
    //     //卫星影像，路况
    //     if(e.srcElement.tagName=="SPAN" || e.srcElement.parentNode.tagName=="SPAN"){
    //         var targetElement = (e.srcElement.tagName=="SPAN") ? e.srcElement : e.srcElement.parentNode;
    //
    //         if(targetElement.className=="switch disabled"){
    //             targetElement.className="switch enable";
    //             if(targetElement.innerHTML.indexOf("卫星")>-1)
    //                 mapUtils.SetLayer(gisApp.Common.SATELLITE_REMOTE_TDT,true,2);
    //             else
    //                 mapUtils.SetLayer(gisApp.Common.TRAFFICFLOW_REMOTE_BD,true,3);
    //         }
    //         else{
    //             targetElement.className="switch disabled";
    //             if(targetElement.innerHTML.indexOf("卫星")>-1)
    //                 mapUtils.SetLayer(gisApp.Common.SATELLITE_REMOTE_TDT,false,2);
    //             else
    //                 mapUtils.SetLayer(gisApp.Common.TRAFFICFLOW_REMOTE_BD,false,3);
    //         }
    //     }
    // };

    ol.control.Control.call(this, {
        element: element,
        target: options.target
    });
};

//ui-grid-table_car
gisApp.CustomCtrl.prototype.RightPrimaryCtrl = function(customCtrl, opt_options){
    var options = opt_options || {};
    var element = document.createElement('div');
    element.className = 'PrimaryHolder';
    element.id = "PrimaryHolder";
    // element.setAttribute("onmouseover","this.style.opacity=0.9");
    // element.setAttribute("onmouseout","this.style.opacity=0.5");
    //element.innerHTML = "<div id='primaryGrid'></div>";

    ol.control.Control.call(this, {
        element: element,
        target: options.target
    });
};

// 显示实时轨迹
gisApp.CustomCtrl.prototype.RealtimeTraceCtrl = function(customCtrl, opt_options) {

    var options = opt_options || {};

    customCtrl.RealtimeTraceCtrlButton_ = document.createElement('button');
    customCtrl.RealtimeTraceCtrlButton_.innerHTML = '轨';

    var switchStatus = function() {
        var mapUtils = this.mapUtils;
        if (mapUtils.customCtrl.RealtimeTraceState) {
            mapUtils.customCtrl.RealtimeTraceCtrlButton_.innerHTML = '轨';
            mapUtils.customCtrl.RealtimeTraceState = false;
            //mapUtils.switchMapStatus(gisApp.MAP_STATE.REALTIME);
            mapUtils.realtimeTracker.turnOff();
            //document.getElementById("info").style.display = "none";
        } else {
            mapUtils.customCtrl.RealtimeTraceCtrlButton_.innerHTML = '关';
            mapUtils.realtimeTracker.turnOn();
            mapUtils.customCtrl.RealtimeTraceState = true;
            //document.getElementById("info").style.display = "inline";
        }
    };

    customCtrl.RealtimeTraceCtrlButton_.addEventListener(
        'click', $.proxy(function() {
            switchStatus()
        }, this), false);

    var element = document.createElement('div');
    element.className = 'realtime-trace-control ol-unselectable ol-control';
    element.appendChild(customCtrl.RealtimeTraceCtrlButton_);

    ol.control.Control.call(this, {
        element: element,
        target: options.target
    });
};

// 测量长度
gisApp.CustomCtrl.prototype.MeasureCtrl = function(customCtrl, opt_options) {

    var options = opt_options || {};

    customCtrl.MeasureCtrlButton_ = document.createElement('button');
    customCtrl.MeasureCtrlButton_.innerHTML = '量';

    var switchStatus = function() {
        var mapUtils = this.mapUtils;
        if (mapUtils.customCtrl.MeasureState) {
            mapUtils.customCtrl.MeasureCtrlButton_.innerHTML = '量';
            //mapUtils.switchMapStatus(gisApp.MAP_STATE.REALTIME);
            mapUtils.measurement.turnOff();
            mapUtils.customCtrl.MeasureState = false;
        } else {
            mapUtils.customCtrl.MeasureCtrlButton_.innerHTML = '关';

            mapUtils.measurement.turnOn();
            mapUtils.customCtrl.MeasureState = true;
        }
    };

    customCtrl.MeasureCtrlButton_.addEventListener('click', $.proxy(function() {
        switchStatus()
    }, this), false);

    var element = document.createElement('div');
    element.className = 'measure-control ol-unselectable ol-control';
    element.appendChild(customCtrl.MeasureCtrlButton_);

    ol.control.Control.call(this, {
        element: element,
        target: options.target
    });
};

// 速度热力图
gisApp.CustomCtrl.prototype.SpeedHeapmapCtrl = function(customCtrl, opt_options) {

    var options = opt_options || {};
    customCtrl.SpeedHeapmapCtrlButton_ = document.createElement('button');
    customCtrl.SpeedHeapmapCtrlButton_.innerHTML = '速';

    var switchStatus = function() {
        var mapUtils = this.mapUtils;
        switch (mapUtils.customCtrl.ctrlState) {
            case gisApp.CTRL_STATE.CAR:
                mapUtils.customCtrl.SpeedHeapmapCtrlButton_.innerHTML = '关';
                mapUtils.source_cars.forEachFeature(function(f) {
                    f.set('weight', parseInt(f.get('speed'), 10) / 40.0);
                });
                mapUtils.map.addLayer(mapUtils.customCtrl.heatmap_vector);
                mapUtils.map.removeLayer(mapUtils.customCtrl.realTimeLayer_);
                mapUtils.customCtrl.ctrlState = gisApp.CTRL_STATE.SPEED_HEAPMAP;
                break;

            case gisApp.CTRL_STATE.CLUSTER:
                break;

            case gisApp.CTRL_STATE.HEAPMAP:
                break;

            case gisApp.CTRL_STATE.SPEED_HEAPMAP:
                mapUtils.customCtrl.SpeedHeapmapCtrlButton_.innerHTML = '速';
                mapUtils.map.removeLayer(mapUtils.customCtrl.heatmap_vector);
                mapUtils.map.addLayer(mapUtils.customCtrl.realTimeLayer_);
                mapUtils.customCtrl.ctrlState = gisApp.CTRL_STATE.CAR;
                break;
        }
        mapUtils.customCtrl.refreshCtrl(mapUtils);
    };

    customCtrl.SpeedHeapmapCtrlButton_.addEventListener('click', $.proxy(function() {
        switchStatus()
    }, this), false);

    var element = document.createElement('div');
    element.className = 'speed-heatmap-control ol-unselectable ol-control';
    element.appendChild(customCtrl.SpeedHeapmapCtrlButton_);

    ol.control.Control.call(this, {
        element: element,
        target: options.target
    });
};

// 热力图层
gisApp.CustomCtrl.prototype.HeapmapCtrl = function(customCtrl, opt_options) {

    var options = opt_options || {};

    customCtrl.HeapmapCtrlButton_ = document.createElement('button');
    customCtrl.HeapmapCtrlButton_.innerHTML = "热";

    var switchStatus = function() {
        var mapUtils = this.mapUtils;
        switch (mapUtils.customCtrl.ctrlState) {
            case gisApp.CTRL_STATE.CAR:
                mapUtils.customCtrl.HeapmapCtrlButton_.innerHTML = '关';
                mapUtils.source_cars.forEachFeature(function(f) {
                    f.set('weight', 1);
                });
                mapUtils.map.addLayer(mapUtils.customCtrl.heatmap_vector);
                mapUtils.map.removeLayer(mapUtils.customCtrl.realTimeLayer_);
                mapUtils.customCtrl.ctrlState = gisApp.CTRL_STATE.HEAPMAP;
                break;

            case gisApp.CTRL_STATE.CLUSTER:
                break;

            case gisApp.CTRL_STATE.HEAPMAP:
                mapUtils.customCtrl.HeapmapCtrlButton_.innerHTML = "热";
                mapUtils.map.removeLayer(mapUtils.customCtrl.heatmap_vector);
                mapUtils.map.addLayer(mapUtils.customCtrl.realTimeLayer_);
                mapUtils.customCtrl.ctrlState = gisApp.CTRL_STATE.CAR;
                break;

            case gisApp.CTRL_STATE.SPEED_HEAPMAP:
                break;
        }
        mapUtils.customCtrl.refreshCtrl(mapUtils);
    };

    customCtrl.HeapmapCtrlButton_.addEventListener('click', $.proxy(function() {
        switchStatus()
    }, this), false);

    var element = document.createElement('div');
    element.className = 'heatmap-control ol-unselectable ol-control';
    element.appendChild(customCtrl.HeapmapCtrlButton_);

    ol.control.Control.call(this, {
        element: element,
        target: options.target
    });
};

// 聚合图层
gisApp.CustomCtrl.prototype.ClusterStyle = function(feature, resolution) {
    var size = feature.get('features').length;
    var style = this.styleCache[size];
    if (!style) {
        style = [new ol.style.Style({
            image: new ol.style.Circle({
                radius: 15,
                stroke: new ol.style.Stroke({
                    color: '#fff'
                }),
                fill: new ol.style.Fill({
                    color: '#3399CC'
                })
            }),
            text: new ol.style.Text({
                font: "15px sans-serif",
                text: size.toString(),
                fill: new ol.style.Fill({
                    color: '#fff'
                })
            })
        })];
        this.styleCache[size] = style;
    }

    return style;
}

gisApp.CustomCtrl.prototype.ClusterCtrl = function(customCtrl, opt_options) {

    var options = opt_options || {};

    customCtrl.ClusterCtrlButton_ = document.createElement('button');
    customCtrl.ClusterCtrlButton_.innerHTML = '聚';

    var switchStatus = function() {
        var mapUtils = this.mapUtils;
        switch (mapUtils.customCtrl.ctrlState) {
            case gisApp.CTRL_STATE.CAR:
                mapUtils.customCtrl.ClusterCtrlButton_.innerHTML = '关';
                mapUtils.customCtrl.layer_clusters = new ol.layer.Vector({
                    source: mapUtils.customCtrl.source_cluster,
                    style: $.proxy(mapUtils.customCtrl.ClusterStyle, mapUtils.customCtrl),
                    visible: false
                });
                mapUtils.map.addLayer(mapUtils.customCtrl.layer_clusters);
                //mapUtils.map.removeLayer(mapUtils.customCtrl.realTimeLayer_);
                mapUtils.customCtrl.ctrlState = gisApp.CTRL_STATE.CLUSTER;
                break;

            case gisApp.CTRL_STATE.CLUSTER:
                mapUtils.customCtrl.ClusterCtrlButton_.innerHTML = '聚';
                mapUtils.map.removeLayer(mapUtils.customCtrl.layer_clusters);
                mapUtils.customCtrl.layer_clusters = null;
                mapUtils.map.addLayer(mapUtils.customCtrl.realTimeLayer_);
                mapUtils.customCtrl.ctrlState = gisApp.CTRL_STATE.CAR;
                break;

            case gisApp.CTRL_STATE.HEAPMAP:
                break;

            case gisApp.CTRL_STATE.SPEED_HEAPMAP:
                break;
        }
        mapUtils.customCtrl.refreshCtrl(mapUtils);
    };

    customCtrl.ClusterCtrlButton_.addEventListener('click', $.proxy(function() {
        switchStatus()
    }, this), false);

    var element = document.createElement('div');
    element.className = 'cluster-control ol-unselectable ol-control';
    element.appendChild(customCtrl.ClusterCtrlButton_);

    ol.control.Control.call(this, {
        element: element,
        target: options.target
    });
};

//集合图层要素改变
gisApp.CustomCtrl.prototype.FeatureChanged = function(){
    //console.info(this.source_cluster.getFeatures());
    if(this.ctrlState != gisApp.CTRL_STATE.CLUSTER) return;

    var max_sum = -1; //聚集车辆最多集合
    var max_idx = -1;
    var pts = null; //聚集multi points

    var idx=-1;
    //先循环图层中的feature，得到聚焦车辆最多的要素
    this.source_cluster.forEachFeature(function (f) {
        idx++;
        var len = f.values_.features.length;
        if(len>max_sum) {
            max_sum = len;
            max_idx = idx;
        }
    });


    if(max_idx>-1) {
        var arr = this.source_cluster.getFeatures()[max_idx].values_.features;
        for (var i = 0; i < arr.length; i++){
            if (pts == null) pts = new ol.geom.MultiPoint();
            //note the layout of MultiPoint must be same with appended Point. LIKE 'XY' or 'XYZ'
            pts.appendPoint(arr[i].getGeometry());
        }
    }

    if(pts!=null)
        this.mapUtils.canvas.DrawGeometry(ol.geom.Polygon.fromExtent(pts.getExtent()),true);

    console.info(this.source_cluster.getFeatures().length);
};

// 控制按钮
gisApp.CustomCtrl.prototype.refreshCtrl = function(holder) {
    var customCtrl = holder.customCtrl;
    // if (holder.mapStatus != gisApp.MAP_STATE.MEASUREMENT) {
    //     customCtrl.MeasureState = false;
    //     customCtrl.MeasureCtrlButton_.innerHTML = '量';
    // }
    if (holder.mapStatus != gisApp.MAP_STATE.REALTIME) {
        customCtrl.ClusterCtrlButton_.style.display = "none";
        customCtrl.HeapmapCtrlButton_.style.display = "none";
        customCtrl.SpeedHeapmapCtrlButton_.style.display = "none";
        //customCtrl.InfoLabel_.style.display = "none";
        customCtrl.RealtimeTraceCtrlButton_.style.display = "none";
    }
    //customCtrl.InfoLabel_.style.display = "block";
    customCtrl.RealtimeTraceCtrlButton_.style.display = "block";
    switch (customCtrl.ctrlState) {
        case gisApp.CTRL_STATE.CAR:
            customCtrl.ClusterCtrlButton_.style.display = "block";
            customCtrl.HeapmapCtrlButton_.style.display = "block";
            customCtrl.SpeedHeapmapCtrlButton_.style.display = "block";
            break;

        case gisApp.CTRL_STATE.CLUSTER:
            customCtrl.ClusterCtrlButton_.style.display = "block";
            customCtrl.HeapmapCtrlButton_.style.display = "none";
            customCtrl.SpeedHeapmapCtrlButton_.style.display = "none";
            break;

        case gisApp.CTRL_STATE.HEAPMAP:
            customCtrl.ClusterCtrlButton_.style.display = "none";
            customCtrl.HeapmapCtrlButton_.style.display = "block";
            customCtrl.SpeedHeapmapCtrlButton_.style.display = "none";
            break;

        case gisApp.CTRL_STATE.SPEED_HEAPMAP:
            customCtrl.ClusterCtrlButton_.style.display = "none";
            customCtrl.HeapmapCtrlButton_.style.display = "none";
            customCtrl.SpeedHeapmapCtrlButton_.style.display = "block";
            break;
    }
}

gisApp.CustomCtrl.prototype.DisplayContent = function(element,content){
    document.getElementById(element).innerHTML = content;
};

/* html code for user custom panel */
//layer manager
gisApp.CustomCtrl.prototype.layerManager_ =
    '<div>' +
        '<div style="border-bottom:1px solid #7ab5d3; height:28px; margin-bottom:6px;">' +
            '<div style="display:inline; float:left">' +
            '<i class="fa fa-search text-info"></i>&nbsp;<font class="text-info">图层显示</font>' +
            '</div>' +
            '<div style="display:inline; float:right">' +
            '<button type="button" class="close" onclick=document.getElementById("LeftPanelHolder").innerHTML="">x</button>' +
            '</div>' +
        '</div>' +
        '<div class="LayerManagerContent">' +
            '<div class="checkbox"><br/><label><input type="checkbox" name="chkLayerManager" text="实时车辆" value="0"/>实时车辆</label>' +
            '<br/><label><input type="checkbox" name="chkLayerManager" text="实时路况" value="0" onclick="mapUtils.SetLayer(gisApp.Common.TRAFFICFLOW_REMOTE_BD,this.checked,3);"/>实时路况</label>' +
            '<br/><label><input type="checkbox" name="chkLayerManager" text="卫星影像" value="0" onclick="mapUtils.SetLayer(gisApp.Common.SATELLITE_REMOTE_TDT,this.checked,2);"/>卫星影像</label>' +
            '<br/><label><input type="checkbox" name="chkLayerManager" text="气象云图" value="0"/>气象云图</label>' +
            '<br/></div>' +
        '</div>' +
    '</div>';

//toolbar
gisApp.CustomCtrl.prototype.toolbarMenu_ =
    '<div class="ToolbarContent" style="display:block;" onmouseover="this.style.opacity=1" onmouseout="this.style.opacity=0.7">' +
    '<div style="display:inline-block;">' +
    '<i class="fa fa-search" style="color:#0a6aa1"></i><a href="#" data-cmd_name="featureSearch_">查询</a>&nbsp;' +
    //'<i class="fa fa-eye" style="color:#0a6aa1"></i><a href="#" data-cmd_name="layerManager_">图层</a>&nbsp;' +
    '<i class="fa fa-warning" style="color:#0a6aa1"></i><a href="#" data-cmd_name="fenceEditor_" onclick="InitDateTimePicker();">围栏</a>&nbsp;' +
    //'<i class="fa fa-fire"  style="color:#0a6aa1"></i><a href="#" data-cmd_name="historyTrack_" onclick="InitDateTimePicker();">轨迹</a>&nbsp;' +
    '<i class="fa fa-flag" style="color:#0a6aa1"></i><a href="#" data-cmd_name="impRegionEditor_">重点区域</a>&nbsp;' +
    '<span class="switch disabled" onmouseover="this.style.opacity=1;" onmouseout=\'(this.className=="switch disabled") ? this.style.opacity=0.6 : this.style.opacity=1;\'><img src="gis/img/traffic-light-16.png"/>路况</span>' +
    '<span class="switch disabled" onmouseover="this.style.opacity=1"  onmouseout=\'(this.className=="switch disabled") ? this.style.opacity=0.6 : this.style.opacity=1;\'><img src="gis/img/satellite.png" width="20" height="20"/>卫星</span>' +
    '<select class="" style="width:120px; margin:3px 6px 0px 6px; font-size:12px;" onchange="mapUtils.ReloadBaseMap(this.value);">' +
    '<option value="BASELAYER_LOCAL_ARCGIS_GOOGLE_TILE" selected>谷歌（离线）</option>' +
    '<option value="BASELAYER_LOCAL_ARCGIS_TILE">高德（离线）</option>' +
    '<option value="BASELAYER_REMOTE_TDT,MARKED_REMOTE_TDT">天地图（在线）</option>' +
    '<option value="BASELAYER_REMOTE_BAIDU">百度（在线）</option>' +
    '</select>' +
    '</div>' +
    '</div>';

//feature search
gisApp.CustomCtrl.prototype.featureSearch_ =
    '<div>' +
    '<div style="border-bottom:1px solid #7ab5d3; height:28px; margin-bottom:6px;">' +
        '<div style="display:inline; float:left">' +
            '<i class="fa fa-search text-info"></i>&nbsp;<font class="text-info">显示过滤</font>' +
        '</div>' +
        '<div style="display:inline; float:right">' +
            '<button type="button" class="close" onclick=document.getElementById("LeftPanelHolder").innerHTML="">x</button>' +
        '</div>' +
    '</div>' +
    '<div><input id="txtKeyword" type="text" value="" placeholder="关键字" style="width:120px; padding:3px;"/></div>' +
    '<div>' +
        '<select id="ddlCompany" style="width:120px;">' +
        '<option>所有公司</option>' +
        '<option>康辉出租车</option>' +
        '<option>深港出租车</option>' +
        '</select>' +
    '</div>' +

    '<div>' +
        '<select id="typeSelect" style="width:120px;" onchange="mapUtils.canvas.Open(this.selectedOptions[0].value,true);">' +
        '<option value="">几何查询</option>' +
        '<option value="Circle">圆形选择</option>' +
        '<option value="Polygon">多边形选择</option>' +
        '<option value="Rectangle">矩形选择</option>' +
        '</select>' +
    '</div>' +
    '<div>' +
    '<button class="btn btn-info  btn-small" onclick="ClearSearchResult();">清除</button>&nbsp;' +
    '<button class="btn btn-info btn-small" onclick="gisApp.CustomCtrl.composeFilter(mapUtils.canvas.GetLastGeometry(false),true)">查询</button>&nbsp;' +
    '<button class="btn btn-primary btn-small" onclick="ClearSearchResult(); mapUtils.canvas.Close();">退出</button>' +
    '</div>' +
    '</div>';


//fence editor
gisApp.CustomCtrl.prototype.fenceEditor_ =
    '<div>' +
        '<div style="border-bottom:1px solid #7ab5d3; height:28px; margin-bottom:6px;">' +
            '<div style="display:inline; float:left">' +
            '<i class="fa fa-search text-info"></i>&nbsp;<font class="text-info">围栏编辑</font>' +
            '</div>' +
            '<div style="display:inline; float:right">' +
            '<button type="button" class="close" onclick=document.getElementById("LeftPanelHolder").innerHTML="">x</button>' +
            '</div>' +
        '</div>' +

        '<input type="text" id="txtFenceName" name="txtFenceName" required placeholder="围栏名称" maxlength="12" style="width:120px; height:24px;"/>' +
        '<input type="text" id="txtStartTime" class="datetimeInput" placeholder="开始时间" maxlength="12" style="margin-top:6px; width:120px; height:24px;"/>' +
        '<input type="text" id="txtEndTime" class="datetimeInput" placeholder="结束时间" maxlength="12" style="margin-top:6px; width:120px; height:24px;"/>' +

        '<select id="typeSelect" style="width:120px;" onchange="mapUtils.canvas.Open(this.selectedOptions[0].value);">' +
            '<option value="Circle">圆形</option>' +
            '<option value="Polygon">多边形</option>' +
            '<option value="Rectangle">矩形</option>' +
        '</select>' +
        '<div>' +
            '<button class="btn btn-info  btn-small" onclick="mapUtils.canvas.Clear();">清除</button>&nbsp;' +
            '<button class="btn btn-info  btn-small" onclick="mapUtils.canvas.Modify();">编辑</button>&nbsp;' +
            '<button class="btn btn-info  btn-small" onclick="SaveFence()">保存</button>' +
        '</div>' +
    '</div>';

//重点区域
gisApp.CustomCtrl.prototype.impRegionEditor_ =
    '<div style="height:300px;">' +
    '<div style="border-bottom:1px solid #7ab5d3; height:28px; margin-bottom:6px;">' +
    '<div style="display:inline; float:left">' +
    '<i class="fa fa-search text-info"></i>&nbsp;<font class="text-info">区域编辑</font>' +
    '</div>' +
    '<div style="display:inline; float:right">' +
    '<button type="button" class="close" onclick=document.getElementById("LeftPanelHolder").innerHTML="">x</button>' +
    '</div>' +
    '</div>' +

    '<input type="text" id="txtRegionName" name="txtRegionName" required placeholder="区域名称" maxlength="12" style="width:120px; height:24px;"/>' +
    '<input type="text" id="txtPrewarning" class="datetimeInput" placeholder="预警值" maxlength="12" style="margin-top:6px; width:120px; height:24px;"/>' +
    '<input type="text" id="txtWarning" class="datetimeInput" placeholder="告警值" maxlength="12" style="margin-top:6px; width:120px; height:24px;"/>' +
    '<input type="text" id="txtRegionStartTime" placeholder="开始时间" maxlength="12" style="margin-top:6px; width:120px; height:24px;"/>' +
    '<input type="text" id="txtRegionEndTime" placeholder="结束时间" maxlength="12" style="margin-top:6px; width:120px; height:24px;"/>' +

    '<select id="typeSelect" style="width:120px;" onchange="mapUtils.canvas.Open(this.selectedOptions[0].value);">' +
    '<option value="Circle">圆形</option>' +
    '<option value="Polygon">多边形</option>' +
    '<option value="Rectangle">矩形</option>' +
    '</select>' +
    '<div>' +
    '<button class="btn btn-info  btn-small" onclick="mapUtils.canvas.Clear();">清除</button>&nbsp;' +
    '<button class="btn btn-info  btn-small" onclick="mapUtils.canvas.Modify();">编辑</button>&nbsp;' +
    '<button class="btn btn-info  btn-small" onclick="SaveRegion()">保存</button>' +
    '</div>' +
    '</div>';

//历史轨迹
gisApp.CustomCtrl.prototype.historyTrack_ =
    '<div>' +
    '<div style="border-bottom:1px solid #7ab5d3; height:28px; margin-bottom:6px;">' +
    '<div style="display:inline; float:left">' +
    '<i class="fa fa-search text-info"></i>&nbsp;<font class="text-info">历史轨迹</font>' +
    '</div>' +
    '<div style="display:inline; float:right">' +
    '<button type="button" class="close" onclick=document.getElementById("LeftPanelHolder").innerHTML="">x</button>' +
    '</div>' +
    '</div>' +

        '<div><input type="text" id="txtOrder" required placeholder="订单号" maxlength="12" style="width:120px; height:24px;"/></div>' +
        // '<div><input type="text" id="txtHistoryStartTime" class="datetimeInput" placeholder="开始时间" maxlength="12" style="margin-top:6px; width:120px; height:24px;"/></div>' +
        // '<div><input type="text" id="txtHistoryEndTime" class="datetimeInput" placeholder="结束时间" maxlength="12" style="margin-top:6px; width:120px; height:24px;"/></div>' +
    '<div>' +
    '<button class="btn btn-info  btn-small" onclick="mapUtils.canvas.Clear();">退出</button>&nbsp;' +
    '<button class="btn btn-info  btn-small" onclick="loadHistoryTrack()">查询</button>' +
    '</div>';

//context menu
gisApp.CustomCtrl.prototype.contextMenu_ =
    '<ul id="contextmenu_container" class="dropdown-menu" style="display:block; position:static; width:80px;">' +
    '<li class="dropdown-submenu"><a class="fa fa-filter" href="#" onclick="showMantainanceDialog();">维护</a></li>' +
    '<li class="dropdown-submenu"><a href="#" onclick="showMonitorDialog();">监控</a></li>' +
    '</ul>';

gisApp.CustomCtrl.prototype.MapLegendDisplay_ =
    '<div class="MapLegendContent" style="display: block; padding:6px; padding-left:12px; opacity:0.8">' +
    '<div>' +
    '<a href="#" class="myBadge">' +
    '<img src="gis/img/taxi_loaded.png">重车<span id="lblLegendHeavy">0</span>' +
    '</a>' +
    '<a href="#" class="myBadge">' +
    '<img src="gis/img/taxi_offline.png">离线<span id="lblLegendOffline">0</span>' +
    '</a>' +
    '<a href="#" class="myBadge">' +
    '<img src="gis/img/taxi_empty.png">空车<span id="lblLegendEmpty">0</span>' +
    '</a>' +
    '<a href="#" class="myBadge">' +
    '<img src="gis/img/taxi_assign.png">电召<span id="lblLegendDispatch">0</span>' +
    '</a>' +
    '<a href="#" class="myBadge">' +
    '<img src="gis/img/taxi_off.png">熄火<span id="lblLegendOff">0</span>' +
    '</a>' +
    '</div>' +
    '</div>';

function trackPlyerHtml() {
    var html = '<div>' +
        '<div style="border-bottom:1px solid #7ab5d3; height:28px; margin-bottom:6px;">' +
        '<div style="display:inline; float:left">' +
        '<i class="fa fa-search text-info"></i>&nbsp;<label class="text-info" style="size:16px;"><b>详细信息</b></label><label id="lblDetail" style="float:right;"></label>' +
        '</div>' +
        '<div style="display:inline; float:right">' +
        '<button type="button" class="close" onclick=document.getElementById("PrimaryHolder").innerHTML="">x</button>' +
        '</div>' +
        '</div>';

    html = html + '<div  id="tracePlayer">' +
        '<div style="text-align:center; padding:3px;">' +
        '<a id="playTracker" class="fa fa-play" onclick="mapUtils.showTracker.playTracker(true,200,document.getElementById(\'step\').value);" title="播放轨迹">播放</a>' +
        '&nbsp;&nbsp;<a id="pauseTracker" class="fa fa-pause" onclick="mapUtils.showTracker.playTracker(false)" title="暂停播放">暂停</a>' +
        '&nbsp;&nbsp;<a id="stopTracker" class="fa fa-stop" onclick="mapUtils.showTracker.playTracker(false);document.getElementById(\'position\').value=mapUtils.showTracker.trackerVal=0;" title="播放轨迹">停止</a>' +
        '&nbsp;&nbsp;<a id="exitTracker" onclick="ExitHistoryTrack()" title="退出轨迹播放">退出</a>' +
        '</div>' +
        '<form style="width:300px;">' +
        '<div class="col-md-4">' +
        '速度:<input id="step" class="trackSlider" type="range" value="1" steps="1" min="1" max="30" title="速度">' +
        '</div>' +
        '<div class="col-md-8">' +
        '进度:<input id="position" class="trackSlider" type="range" value="0" steps="1" min="0" max="10000" title="进度" oninput="mapUtils.showTracker.stepBarListener(this);">' +
        '</div>' +
        '</form>' +
        '</div>';
    return html;
}


//载入历史轨迹详细记录
function loadHistoryTrack(){
    var order = document.getElementById("txtOrder").value;
    // var sdt = document.getElementById("txtHistoryStartTime").value;
    // var edt = document.getElementById("txtHistoryEndTime").value;

    var holder = document.getElementById("PrimaryHolder");

    console.info("loadHistoryTrack");

    $.ajax({
        method: "GET",
        url: "route/getByOrderId?start=0&limit=999999&orderId=" + order,
        dataType: "json",
        success: function (data) {
            if(data.root===null || data.root===undefined) return;

            for(var i=0;i<data.root.length;i++){
                data.root[i].normal_time = new Date(data.root[i].time).Format("yyyy-MM-dd hh:mm:ss");
                data.root[i].index = (i+1);
            }

            holder.innerHTML = "<div>" + trackPlyerHtml() + "<div id='searchHistoryResultGrid'></div>" +
                "本次订单共产生 里程" + mapUtils.showTracker.totalKilometer + "km. </div>";
            var lbl = document.getElementById("lblDetail");
            //if(lbl) lbl.innerHTML = "本次共加载了" + data.root.length + "条GPS记录";
            document.getElementById("position").setAttribute("max",data.root.length);

            $("#searchHistoryResultGrid").jsGrid({
                width: "360px",
                height: "340px",
                data: data.root,
                fields: [
                    {title: '序号', width: 45, name: 'index'},
                    {title: '时间', width: 120, name: 'normal_time'}
                ],
                rowClick:function(e){
                    if(data.root.length>0) {
                        //document.getElementById("position").value = e.itemIndex / data.root.length * 10000;
                        if(e.item.lng!=0 && e.item.lat!=0)
                            mapUtils.panToPoint([e.item.lng, e.item.lat]);
                        mapUtils.showTracker.stepBarListener(e.itemIndex);
                    }
                    //mapUtils.showTracker.stepBarListener({value: percent});
                }
            });

            mapUtils.showTracker.turnOn();
            mapUtils.showTracker.AppendJsonData(order,data.root);
        }
    });

}
