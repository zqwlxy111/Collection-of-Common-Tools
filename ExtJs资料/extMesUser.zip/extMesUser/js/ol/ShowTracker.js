if (!window.gisApp) {
    window.gisApp = {};
}
var gisApp = window.gisApp;

// 实时轨迹
gisApp.ShowTracker = function(that, options) {
    this.mapUtils = that;

    this.play = false;
    this.vectorCurrCarSource = null;
    this.vectorCurrCarLayer = null;

    this.playTracker_timer_id = null;
    this.playTracker_step = 1;
    this.trackerVal = 0; //当前轨迹点位置索引
    this.extent = [];
    this.time = {
        start: Infinity,
        stop: -Infinity,
        duration: 0
    };
    this.pointNum = 0; //轨迹点计数
    this.highlightFeature = null;
    this.highlightStation = null;
    this.featureOverlay = null; //轨迹线路featureOverlay图层（显示）
    this.allFeatures = []; //所有按时间顺序的轨迹点,getFeatures返回的没有顺序
    this.source_tracks = null;
    this.featureId = null; //正在播放的终端ID
    this.layer_tracks = null;//轨迹点图层（保存所有轨迹点的坐标，第一次显示，播放轨迹时隐藏）

    this.totalKilometer= 0;                 //总里程
    this.totalLength = 0;                   //里程长度，算到结束索引
    this.startIndex = 0;                    //开始绘制轨迹的索引F

    this.styleCache = [];

    this.lineStyle = new ol.style.Stroke({
        color: 'rgba(255,0,0,0.9)',
        width: 1
    });

    this.lineTrack = null;
    this.cache = [];
    this.point = null;
    this.line = null;
    this.displaySnap = function(coordinate) {
        var closestFeature = this.source_tracks.getClosestFeatureToCoordinate(coordinate);
        //var info = document.getElementById('info');
        if (closestFeature === null) {
            this.point = null;
            this.line = null;
            //info.innerHTML = '&nbsp;';
        } else {
            var geometry = closestFeature.getGeometry();
            if(!closestFeature.get('dis')){
                this.point = null;
                this.line = null;
                //info.innerHTML = '&nbsp;';
            }
            else{
                var closestPoint = geometry.getClosestPoint(coordinate);
                if (this.point === null) {
                    this.point = new ol.geom.Point(closestPoint);
                } else {
                    this.point.setCoordinates(closestPoint);
                }
                var date = new Date(closestPoint[2]);
                var key = closestFeature.get('name')+closestPoint[2].toString().substr(0,9);
                // info.innerHTML = closestFeature.get('name') + ' (' + date.Format("YYYY-MM-DD HH:mm:SS") + ')';
                // info.innerHTML += " 速度"+this.cache[key+'speed'];
                // info.innerHTML += " 运营"+this.cache[key+'operatestate'];
                // info.innerHTML += " 超速"+this.cache[key+'overspeed'];

                var coordinates = [coordinate, [closestPoint[0], closestPoint[1]]];
                if (this.line === null) {
                    this.line = new ol.geom.LineString(coordinates);
                } else {
                    this.line.setCoordinates(coordinates);
                }

                var o_line = new ol.geom.LineString()
                if(this.play){
                    var f = this.vectorCurrCarSource.getFeatureById(closestFeature.getId());
                    if(f!=null)
                        this.vectorCurrCarSource.removeFeature(f);
                }else {
                    this.vectorCurrCarSource.clear();
                }

                f = new ol.Feature(new ol.geom.Point(closestPoint));
                f.set('angle',this.cache[key+'angle']);
                f.set('speed',this.cache[key+'speed']);
                f.set('operatestate',this.cache[key+'operatestate']);
                //f.set('name',closestFeature.get('name')+"("+date.Format("HH:mm:SS")+"),速度:"+this.cache[key+'speed']);
                f.set('name',date.Format("HH:mm:SS")+","+this.cache[key+'speed'] + "/h");
                f.setId(closestFeature.getId());
                this.vectorCurrCarSource.addFeature(f);
            }
        }
        mapUtils.map.render();
    };
};

gisApp.ShowTracker.prototype.TraceStyle = function(feature, fid) {
    var id = fid || feature.getId();
    var style = this.mapUtils.style_unsel_func(feature);

    if (!style) {
        var r = parseInt(200*Math.random());
        var g = parseInt(200*Math.random());
        var b = parseInt(200*Math.random());

        style = [new ol.style.Style({
            stroke: new ol.style.Stroke({
                color: "rgba("+r+","+g+","+b+",0.8)",
                width: 3
            })
        })];
        this.styleCache[id] = style;
    }
    return style;
};

gisApp.ShowTracker.prototype.HoverOnStation = function(pixel) {
    var feature = mapUtils.map.forEachFeatureAtPixel(pixel, function(feature, layer) {
        //&& feature.getId().substring(0,3)!='sta'
        if(feature && feature.getGeometry().getType()!="Point") return;
        feature.set("overonstation",true);
        return feature;
    });


    if (feature !== this.highlightStation) {
        if (this.highlightStation) {
            try {
                this.featureOverlay.getSource().removeFeature(this.highlightStation);
            }
            catch(e){

            }
        }

        if (feature) {
            this.featureOverlay.getSource().addFeature(feature);
        }
        this.highlightStation = feature;
    }
};

gisApp.ShowTracker.prototype.tracePointerMove = function(evt) {
    if (evt.dragging || this.play) {
        return;
    }

    var pixel = mapUtils.map.getEventPixel(evt.originalEvent);
    //this.HoverOnStation(pixel);
    this.displaySnap(evt.coordinate);
};

gisApp.ShowTracker.prototype.clickEvent = function(evt) {
    //this.displaySnap(evt.coordinate);
};

gisApp.ShowTracker.prototype.drawTrackers = function(evt) {
    if(this.play)
        return;

    var vectorContext = evt.vectorContext;
    if (this.point !== null) {
        //vectorContext.setImageStyle(this.pointStyle);
        vectorContext.drawPointGeometry(this.point);
    }
    if (this.line !== null) {
        vectorContext.setFillStrokeStyle(null, this.lineStyle);
        vectorContext.drawLineStringGeometry(this.line);
    }
};

gisApp.ShowTracker.prototype.getCarStyle = function(feature) {
    //this is a misunderstanding.it might be replaced by previous code.
    var styles;
    var src;
    var dir = feature.get('angle');
    var states = [];
    if(feature.get('stateText')!=null)
        states = feature.get('stateText').split(",");
    var lineDash = undefined;


    var suffix = "_m.png";
    src = options.gispngurl + 'taxi_loaded' + suffix;

    var lineColor = "#000";
    if(feature.get('relocated')!=null) {
        lineColor = "#CCC";
        lineDash = [5, 5];
    }


    
    switch (states[0]){
        case "离线":
            src = options.gispngurl + 'taxi_offline' + suffix;
            lineColor = "#666";
            break;
        case "重车":
            src = options.gispngurl + 'taxi_loaded' + suffix;
            lineColor = "#F3D01C";
            break;
        case "空车":
            src = options.gispngurl + 'taxi_empty' + suffix;
            lineColor = "#098B24";
            break;
        case "电召":
            src = options.gispngurl + 'taxi_assign' + suffix;
            lineColor = "#00a8f3";
            break;
        case "熄火":
            src = options.gispngurl + 'taxi_off' + suffix;
            break;
    }

    src = options.gispngurl + 'vehicle.png';
    lineColor = "#098B24";
    if(feature.get("startpoint"))
        src = options.gispngurl + "start.png";

    var angle = dir;

    //if(dir<90) dir = dir-90;
    dir = (dir*2+90)*Math.PI/180.0;

    styles = [new ol.style.Style({
        stroke: new ol.style.Stroke({
            color: lineColor,
            lineDash: lineDash,
            width: 3
        }),
        text: new ol.style.Text({
            font: '12px Calibri,sans-serif',
            text: (feature.get('totalLength')==undefined) ? "" : (this.totalLength/1000).toFixed(1) + 'km', //must be a string.
            offsetY: -10,
            textAlign:'center',
            fill: new ol.style.Fill({
                color: '#222'
            }),
            stroke: new ol.style.Stroke({
                color: feature.get("selected") ? '#ff0' : '#fff',
                width: feature.get("selected") ? 4 : 2
            })
        }),
        image: new ol.style.Icon({
            src: src,
            rotateWithView: false,
            rotation: 0
        })
    })];

    return styles;
};

//每次打开时都会创建新的layer，这里可以优化
gisApp.ShowTracker.prototype.turnOn = function() {
    this.cache = [];
    this.time = {
        start: Infinity,
        stop: -Infinity,
        duration: 0
    };
    this.extent = [];
    this.pointNum = 0;
    mapUtils.Clear();

    this.source_tracks = new ol.source.Vector({
        format: new ol.format.GeoJSON()
    });

    this.layer_tracks = new ol.layer.Vector({
        visible: true,
        source: this.source_tracks,
        style: $.proxy(mapUtils.showTracker.getCarStyle, mapUtils.showTracker)
    });
    this.featureOverlay = new ol.layer.Vector({
        source: new ol.source.Vector(),
        map: mapUtils.map,
        style: $.proxy(mapUtils.showTracker.getCarStyle, mapUtils.showTracker)
    });

    mapUtils.map.removeLayer(mapUtils.layer_cars);
    mapUtils.map.addLayer(this.layer_tracks);
    mapUtils.map.addLayer(this.featureOverlay);
    mapUtils.map.on('pointermove', this.tracePointerMove, this);
    mapUtils.map.on('click', this.clickEvent, this);
    mapUtils.map.on('postcompose', this.drawTrackers, this);
    mapUtils.mapEvents['pontermove'] = this.tracePointerMove;
    mapUtils.mapEvents['click'] = this.clickEvent;
    mapUtils.mapEvents['postcompose'] = this.drawTrackers;
    mapUtils.mapEventsHolder['pontermove'] = this;
    mapUtils.mapEventsHolder['click'] = this;
    mapUtils.mapEventsHolder['postcompose'] = this;


    mapUtils.map.removeLayer(this.vectorCurrCarLayer);
    this.vectorCurrCarSource = new ol.source.Vector();
    this.vectorCurrCarLayer = new ol.layer.Vector({
        source:this.vectorCurrCarSource,
        style:$.proxy(mapUtils.showTracker.getCarStyle, mapUtils.showTracker)
    });
    mapUtils.map.addLayer(this.vectorCurrCarLayer);
};

gisApp.ShowTracker.prototype.Clear = function(){
    if(this.featureOverlay!=null)
        this.featureOverlay.getSource().clear();
    if(this.source_tracks!=null)
        this.source_tracks.clear();
};

gisApp.ShowTracker.prototype.turnOff = function(){
    // this.mapUtils.SetLayer(this.layer_tracks, false);
    // this.mapUtils.SetLayer(this.featureOverlay, false);
    this.mapUtils.map.removeLayer(this.layer_tracks);
    this.mapUtils.map.removeLayer(this.featureOverlay);
    //this.mapUtils.map.removeLayer(this.vectorCurrCarLayer);
    var existing = false;
    this.mapUtils.map.getLayers().forEach(
        function(ele,index,arr) {
            if(ele===this.mapUtils.layer_cars)
                existing = true;
    });
    
    if(!existing)
        this.mapUtils.map.addLayer(this.mapUtils.layer_cars);

    this.mapUtils.switchMapStatus(gisApp.MAP_STATE.REALTIME);

};

//添加数据(obsoleted)
gisApp.ShowTracker.prototype.AppendTraceData = function (pointJson) {
    var point = (new ol.format.GeoJSON()).readFeature(pointJson);
    var geo = pointJson.replace('"type":"Point"','"type":"LineString"')
        .replace('"coordinates":[','"coordinates":[[')
        .replace(']},"properties"',']]},"properties"');
    var f = (new ol.format.GeoJSON()).readFeature(geo);

    var feature = this.source_tracks.getFeatureById(f.getId());
    var geometry;
    if(feature){
        geometry = feature.getGeometry();
        var coord1=geometry.getCoordinates();
        var coord2=f.getGeometry().getCoordinates();
        var coord = coord1.concat(coord2);
        feature.getGeometry().setCoordinates(coord);
        geometry.layout = 'XYM';
    }
    else{
        geometry = f.getGeometry();
        geometry.layout = 'XYM';
        this.source_tracks.addFeature(f);
    }

    var key = point.getGeometry().getCoordinates()[2].toString(); //.substr(0,9);
    this.cache['speed' + key] = f.get('speed');
    this.cache['angle' + key] = f.get('angle');
    this.cache['state' + key] = f.get('stateText');
    // this.time.start = Math.min(this.time.start, geometry.getFirstCoordinate()[2]);
    // this.time.stop = Math.max(this.time.stop, geometry.getLastCoordinate()[2]);
    // this.time.duration = this.time.stop - this.time.start;

    var pos = point.getGeometry().getCoordinates();
    if(this.extent.length==0){
        this.extent = [[pos[0],pos[1]],[pos[0],pos[1]]];
    }
    else{
        if(pos[0]<this.extent[0][0])
            this.extent[0][0] = pos[0];
        else if(pos[0]>this.extent[1][0])
            this.extent[1][0] = pos[0];

        if(pos[1]<this.extent[0][1])
            this.extent[0][1] = pos[1];
        else if(pos[1]>this.extent[1][1])
            this.extent[1][1] = pos[1];
    }
};

//添加数据
gisApp.ShowTracker.prototype.AppendJsonData = function (id, rawData) {

    this.pointNum=0;
    this.lineTrack = null;
    this.allFeatures = [];

    var lastPoint;

    for(var data in rawData){
        var d = rawData[data];
        var feature = gisApp.Common.CreateTaxiObject(id,d);
        this.featureId = id;
        if (d.lng && d.lat && d.time) {

            if(lastPoint){
                //30秒跑了3KM的数据过滤掉
                var distance = gisApp.TopoAlgorithm.PathLength([[lastPoint.flatCoordinates[0],lastPoint.flatCoordinates[1]],[d.lng,d.lat]]);
                var duration = (d.time-lastPoint.flatCoordinates[2])/1000;
                //时速大于200km的点移除（时间间隔大于1秒才纳入判断）
                if(distance/duration * 3600 / 1000 > 200 && duration>1000) {
                    console.info("GPS点在" + new Date(d.time).toString() + "超过理论速度，已移除");
                    continue;
                }
            }
            var geo = new ol.geom.Point([d.lng, d.lat, d.time]);
            lastPoint = geo;
            geo.setLayout(ol.geom.GeometryLayout.XYM);
            feature.setGeometry(geo);
            this.allFeatures.push(feature);
            this.pointNum++;

            //将数据保存至数组中
            var key = d.time;
            // this.cache['speed' + key] = feature.get('speed');
            // this.cache['angle' + key] = feature.get('angle');
            // this.cache['state' + key] = feature.get('stateText');

            //将点组成线
            if(this.lineTrack==null)
                this.lineTrack = new ol.geom.Point(geo.getCoordinates(),ol.geom.GeometryLayout.XYM);
            else {
                if(this.lineTrack.getType() == ol.geom.GeometryType.POINT){
                    var coord = this.lineTrack.getCoordinates();
                    var coords = [];
                    coords.push(coord);
                    coords.push(geo.getFlatCoordinates());
                    this.lineTrack = new ol.geom.LineString(coords);
                }
                else{
                    this.lineTrack.appendCoordinate(geo.getCoordinates());
                }
                //this.lineTrack = this.lineTrack.appendCoordinate(geo.getCoordinates());
            }
            //mapUtils.showTracker.AppendTraceData( new ol.format.GeoJSON().writeFeature(feature));
        }
    }

    if(this.lineTrack!=null){
        var coords = this.lineTrack.getCoordinates();
        this.totalKilometer = (gisApp.TopoAlgorithm.PathLength(coords) / 1000).toFixed(2);
    }

    this.mapUtils.panToLine(this.lineTrack);
    this.trackAnimation(this.pointNum-1,this);
};

gisApp.ShowTracker.prototype.stepBarListener = function(evt) {
    //this.trackerVal = parseInt(evt.value , 10)/10000*this.pointNum-1;
    this.trackerVal = (typeof(evt)=="object") ? evt.value : evt;
    this.layer_tracks.setVisible(false);
    this.trackAnimation(this.trackerVal,mapUtils.showTracker);
};

gisApp.ShowTracker.prototype.trackAnimation=function(idx,holder) {
    holder = this;
    //var f = holder.source_tracks.getFeatures()[0];
    var coordinates = this.lineTrack.getCoordinates();

    idx = this.trackerVal = parseInt(idx);
    if(idx>this.pointNum) return;
    
    //当最后一个GPS点在主副站附近时，startIndex为最后一个点的索引值，然后再拖动时会出现startIndex大于idx的情况，从而导致错误
    if(this.startIndex>idx+1) this.startIndex=0;
    var coords = coordinates.slice(this.startIndex, idx+1);
    this.totalLength = 0;
    this.totalLength = gisApp.TopoAlgorithm.PathLength(coords);
    var endpoint_coord = coords[idx];
    var sp = new ol.Feature(new ol.geom.Point(coords[0]));
    sp.set("startpoint",true);

    var pf = new ol.Feature(new ol.geom.Point(endpoint_coord));
    pf.set("totalLength",this.totalLength);
    
    // holder.highlightFeature = pf;
    // pf.setId('highlightFeature');

    try {
        if(holder.featureOverlay.getSource().getFeatures().length>0)
            holder.featureOverlay.getSource().clear();
        holder.featureOverlay.getSource().addFeature(pf);
    }
    catch (e){
        console.info(e);
    }

    //画线
    if (idx > 0) {
        var last_start_index=0;
        var last_state="";
        var lineFeature;
        var relocated = false;

        for(var i=0;i<=idx && i<this.allFeatures.length;i++){
            var state = "FFFF"; //Representing nothing here. this.allFeatures[i].get("stateText").split(",")[0];
            var time = this.allFeatures[i].getGeometry().getCoordinates()[2];
            if(i==0) last_state = state;
            //if(last_start_index==i) continue;

            //根据不同的状态，用不同的颜色绘制
            lineFeature = new ol.Feature(new ol.geom.LineString(coordinates.slice(last_start_index, i+1)));
            //this.totalLength = gisApp.TopoAlgorithm.PathLength(coordinates.slice(0, i+1));
            lineFeature.set("stateText",last_state);
            //lineFeature.set("totalLength",this.totalLength);

            //两点相隔超过五分钟将用虚线连接
            if(i>0){
                var last_time = this.allFeatures[i-1].getGeometry().getCoordinates()[2];
                //var last_time = Date.parse(line_string[line_string.length-1][2]);
                if(time-last_time>1000*60*5){
                    relocated = true;
                    var line_coords = lineFeature.getGeometry().getCoordinates();
                    lineFeature.getGeometry().setCoordinates(line_coords.splice(0,line_coords.length-1));
                }
            }

            if((state!=last_state && i>0) || relocated){
                holder.featureOverlay.getSource().addFeature(lineFeature);
                if(relocated) {
                    var dash_coord = [];
                    dash_coord.push(this.allFeatures[i-1].getGeometry().getCoordinates());
                    dash_coord.push(this.allFeatures[i].getGeometry().getCoordinates());
                    var new_line = new ol.geom.LineString(dash_coord);
                    var new_feature = new ol.Feature();
                    new_feature.set("relocated",true);
                    new_feature.setGeometry(new_line);
                    holder.featureOverlay.getSource().addFeature(new_feature);
                    relocated=false;
                }
                //console.info(last_start_index + "," + i);
                last_state = state;
                last_start_index=i;
            }

        }

        //last line segment.
        if(lineFeature)
            holder.featureOverlay.getSource().addFeature(lineFeature);
    }
    console.info('there are ' + holder.featureOverlay.getSource().getFeatures().length + ' feature(s) in the layer.');

    //holder.displaySnap([endpoint_coord[0], endpoint_coord[1]]);
    //mapUtils.map.render();
};

//播放轨迹
gisApp.ShowTracker.prototype.setTrackerVal = function() {
    document.getElementById('position').value = this.trackerVal;

    //this.refreshDraw(this.trackerVal / this.pointNum, this);
    if (this.trackerVal >= this.pointNum){
        this.trackerVal = this.pointNum-1;
        this.playTracker(false);
        console.info("stoping animation.");
        return;
    }
    else {
        this.trackerVal += parseInt(this.playTracker_step);
        //if (this.trackerVal > this.pointNum) this.trackerVal = this.pointNum-1;
    }

    this.layer_tracks.setVisible(false);
    this.trackAnimation(this.trackerVal,this);
    //console.info(this.trackerVal / this.pointNum);
};

//播放或暂停
gisApp.ShowTracker.prototype.playTracker = function(play, timer, step) {

    if (play) {
        this.playTracker_step = step;
        if (this.playTracker_timer_id != null)
            window.clearInterval(this.playTracker_timer_id);
        this.trackerVal=1;
        this.playTracker_timer_id = window.setInterval($.proxy(this.setTrackerVal, this), timer);
    } else {
        if (this.playTracker_timer_id != null) {
            window.clearInterval(this.playTracker_timer_id);
            this.playTracker_timer_id = null;
        }
    }
    this.play = play;
};

//停止
gisApp.ShowTracker.prototype.Stop = function(){
    this.totalLength=0;
    this.trackerVal=0;
    this.startIndex=0;
    document.getElementById('position').value = 0;

    //清除绘制的轨迹，重新显示所有轨迹
    if(this.featureOverlay && this.layer_tracks) {
        this.featureOverlay.getSource().clear();
        this.layer_tracks.setVisible(true);
    }

    if (this.playTracker_timer_id != null) {
        window.clearInterval(this.playTracker_timer_id);
        this.playTracker_timer_id = null;
    }
    this.play = false;
}
