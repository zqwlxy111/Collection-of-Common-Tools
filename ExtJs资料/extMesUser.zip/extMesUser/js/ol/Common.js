/*
 * 常量，图层常量，空间运算符，过滤器选项
 * 样式创建
*/

if(!window.gisApp){
    window.gisApp={};
}

var gisApp = window.gisApp;


var mapUtils;
function mapInitPrepared() {
    var map_obj = document.getElementById("map");
    if(map_obj===null || map_obj===undefined){
        window.setTimeout("mapInitPrepared()",100);
    }
    else{
        mapUtils = new gisApp.MapUtils(this, options);
        mapUtils.InitMap(gisApp.MAP_STATE.INIT);
        InitDateTimePicker();
        console.info("map has been loaded.")
    }
}

mapInitPrepared();

gisApp.Common = function(){

}

gisApp.Common.VisibleTerminals = new ol.Collection();

// gisApp.GEOMETRY_TYPE={
//     Point: 'Point',
//     LineString: 'LineString',
//     Rectangle: 'Rectangle', //矩形
//     Ploygon: 'Ploygon' //多边形
// }

//关系运算符
gisApp.RELATION_EXPRESSION={
    Equal: "==",
    LessThan: "<",
    GreaterThan: ">",
    Like: ""
};

//空间关系运算符
gisApp.SPATIAL_OPERATOR = {
    WithIn: "WithIn",
    Intersects: "Intersects"
};

//逻辑关系运算符
gisApp.LOGICAL_OPERATOR = {
    Null: "Null", //默认不操作
    And: "And",
    Or: "Or"
};

//过滤器选项
gisApp.FilterOptions = {
    "Filters": [], //FeatureFilter 数组
    "SpatialOperator": null,
    "Geometry": null
};

//要素过滤器
gisApp.FeatureFilter = {
    "PropertyName": "", //属性名称
    "RelationExpression": gisApp.RELATION_EXPRESSION.Equal, //关系运算符
    "Expression": null, //属性值
    "LogicalOperator": gisApp.LOGICAL_OPERATOR.Null
}


gisApp.Common.CreateFeatureFilter = function(){
    var retval = {};
    retval.PropertyName = "";
    retval.RelationExpression = gisApp.RELATION_EXPRESSION.Equal;
    retval.Expression = "";
    retval.LogicalOperator = gisApp.LOGICAL_OPERATOR.Null;
    return retval;
}

gisApp.Common.CreateTaxiObject = function(id,entity) {
    var retval = new ol.Feature();
    retval.set("name",id);
    retval.setId(id);
    retval.set("latitude",entity.lat);
    retval.set("longitude",entity.lng);
    retval.set("normalTime",new Date().Format("yyyy-MM-dd hh:mm:ss"));
    retval.setGeometry(new ol.geom.Point(0,0));
    return retval;
}

//返回车辆对象

gisApp.Common.CreateVehicleObject = function(vehno){
    var car = {};
    car["type"] = "Feature";
    car["id"] = vehno;
    car["geometry"] = {};
    car["geometry"]["type"] = "Point";
    car["geometry"]["coordinates"] = [];
    car["properties"]={};
    car["properties"]["name"] = (vehno) ? vehno : "";

    return car;
}

gisApp.Common.FenceObject = {
    //var fence = {};
    id : undefined,
    name :  "",
    userId : "",
    geometry : undefined,
    warningType : 0,
    durationType : 0,
    startTime : new Date(),
    endTime : new Date(),
    deleteStatus : 1
}

gisApp.Common.CreateRegionObject = function(){
    var region = {};
    region.id = undefined;
    region.name = "";
    region.userId = "";
    region.geometry = undefined;
    region.prewarning = 0;
    region.warning = 0;
    region.startTime = "08:00:00";
    region.endTime = "10:00:00";
    region.withinAmount=0;
    region.deleteStatus =1;
    return region;
};

gisApp.Common.CreateStyle = function(fillColor, strokeColor, strokeWidth, textContent){
    var opts = {
        fill: new ol.style.Fill({
            color: fillColor
        }),
        stroke: new ol.style.Stroke({
            color: strokeColor,
            width: strokeWidth
        }),
        image: new ol.style.Circle({
            radius: 7,
            fill: new ol.style.Fill({
                color: '#cc33ff'
            })
        })
    };

    if(textContent){
        opts.text = new ol.style.Text({
            text: textContent,
            fill: new ol.style.Fill({
                color: '#000'
            }),
            stroke: new ol.style.Stroke({
                color: '#fff',
                width: 3
            })
        });
    }

    var style = new ol.style.Style(opts);


    return style;
}

/*
 * NOTE: this method have to be invoked by $.proxy.
 *
 */
gisApp.Common.RequestRealtimeData = function(index){
    //NOTE: 'this' is passed from $.proxy method.
    mapUtils = this;
    var that = this;
    //if(location.hash.indexOf("homepage")==-1) return;
    mapUtils.map.updateSize();

    if(!window.localStorage.requestTimestamp)
        window.localStorage.requestTimestamp = new Date("1970-01-01 01:00:00");

    /*function compactPartOfTerminals(data){

        gisApp.Common.VisibleTerminals = new ol.Collection();

        if(mapUtils.map.getView().getZoom()<15 && data.length>options.maxTerminal){
            for(var i=0;i<options.maxTerminal;i++){
                var key = data[i].isu;
                gisApp.Common.VisibleTerminals.set(key,true);
            }
        }
        else{
            for(var i=0;i<data.length;i++){
                var key = data[i].isu;
                gisApp.Common.VisibleTerminals.set(key,true);
            }
        }
    }*/

    function appendTestData(){
        //地王大厦坐标
        var feature = gisApp.Common.CreateTaxiObject();
        feature.set("name","地王大厦（GCJ02）");
        feature.setId("地王大厦（GCJ02）");
        feature.setGeometry(new ol.geom.Point([114.111037, 22.543427]));
        mapUtils.RefreshCarData(feature);

        //calculating the distance form gcj02 to wgs84.
        // var offset_x = gisApp.TopoAlgorithm.PathLength([[114.111037, 22.543427],[114.105920, 22.543427]]);
        // var offset_y = gisApp.TopoAlgorithm.PathLength([[114.111037, 22.543427],[114.111037, 22.546080]]);
        // console.info("offset distance:" + offset_x + "," + offset_y);

        //114.105920,22.546080
        //GCJ02到WGS84 的偏移量-0.005117,0.002653
        var f = gisApp.Common.CreateTaxiObject();
        f.set("name","地王大厦（wgs84）");
        f.setId("地王大厦（wgs84）");
        f.setGeometry(new ol.geom.Point([114.106053,22.546355]));
        mapUtils.RefreshCarData(f);

        var coords = coordtransform.wgs84togcj02(114.106053,22.546355);
        var s = gisApp.Common.CreateTaxiObject();
        s.set("name","转换后坐标gcj");
        s.setId("转换后坐标gcj");
        s.setGeometry(new ol.geom.Point(coords));
        mapUtils.RefreshCarData(s);

        var f = gisApp.Common.CreateTaxiObject();
        f.set("name","国人");
        f.setId("grtech");
        f.setGeometry(new ol.geom.Point([113.936150,22.546530]));
        mapUtils.RefreshCarData(f);

    }

    function constructDataSource(data){
        //compactPartOfTerminals(data);

        for(var i=0;i<data.length;i++){
            if(!data[i].isu) return;
            var key = data[i].isu;
            var feature = gisApp.Common.CreateTaxiObject((data[i].cno==undefined) ? data[i].isu : data[i].cno);
            //checks the terminal is existing in collection or not.
            //in order to improve the performance, it just show first set of terminals on the map.
            if(!gisApp.Common.VisibleTerminals.get(key) && mapUtils.map.getView().getZoom()<15){
                var f = mapUtils.source_cars.getFeatureById(key);
                if(f)
                    mapUtils.source_cars.removeFeature(f);
                continue;
            }

            feature.set("stateText",gisApp.Common.FormatTaxiState(data[i].sta, data[i].onl));

            feature.set("carNo",(data[i].cno==undefined) ? "" : data[i].cno);
            feature.set("speed",data[i].spe);
            feature.set("angle",data[i].ang);
            feature.set("driverNo",(data[i].dn==undefined) ? "" : data[i].dn);
            feature.set("driverTel",(data[i].dt==undefined) ? "" : data[i].dt);
            feature.set("driverName",(data[i].dnm==undefined) ? "" : data[i].dnm);
            feature.set("companyId",(data[i].coId==undefined) ? "" : data[i].coId);
            feature.set("companyName",(data[i].coNm==undefined) ? "" : data[i].coNm);
            feature.set("carSerialNum",(data[i].sn==undefined) ? "" : data[i].sn);
            feature.set("carPhone",(data[i].pho==undefined) ? "" : data[i].pho);
            feature.set("normalTime",(data[i].tim==undefined) ? "" : new Date(data[i].tim).Format("yyyy-MM-dd hh:mm:ss"));

            //var coord = coordtransform.gcj02towgs84(data[i].Longitude, data[i].Latitude);
            //for test.
            var offset = Math.random()/1000;
            offset = 0;
            feature.setGeometry(new ol.geom.Point([data[i].lon+offset, data[i].lat+offset]));
            mapUtils.RefreshCarData(feature);
        }
        mapUtils.source_cars.refresh();
    };

    //calculating timestamp.
    var now = new Date().Format("yyyy-MM-dd hh:mm:ss");
    //console.info(Date.parse(now) - Date.parse(window.localStorage.requestTimestamp));
    //console.info("refreshing location.");
    if(index==undefined) index=0;

    if(Date.parse(now) - Date.parse(window.localStorage.requestTimestamp)<options.refreshInterval && window.localStorage.realtimeData!=null){
        var data = JSON.parse(window.localStorage.realtimeData);
        constructDataSource(data);
        if(typeof mapUtils.dataUpdatedEvent=='function')
            mapUtils.dataUpdatedEvent(data);
    }
    else{ //reload data from remote.
        $.ajax({
            method: 'GET',
            url: baseuri.service + '/gis/getPartOfRealtimeLocation/' + index,
            contentType: "application/json; charset=UTF-8",
            dataType: "json",
            success: function(data){

                if(data) {
                    //updating the timestamp and data.
                    if(index==0) {
                        window.localStorage.realtimeData = JSON.stringify(data);
                        gisApp.Common.VisibleTerminals = new ol.Collection();
                        for(var i=0;i<data.length;i++){
                            var key = data[i].isu;
                            gisApp.Common.VisibleTerminals.set(key,true);
                        }
                    }
                    else{ //appends data to the localStorage.
                        var previous = JSON.parse(window.localStorage.realtimeData);
                        for(var i=0;i<data.length;i++) {
                            previous.push(data[i]);
                        }
                        window.localStorage.realtimeData = JSON.stringify(previous);
                    }

                    constructDataSource(data);

                    //调用事件
                    if(typeof mapUtils.dataUpdatedEvent=='function')
                        mapUtils.dataUpdatedEvent(data);
                    mapUtils.source_cars.refresh();

                    if(data!=null){
                        index++;
                        window.setTimeout($.proxy(gisApp.Common.RequestRealtimeData,that,index),10);
                    }
                    //f.setGeometry(new ol.geom.Point([data[0].Longitude, data[0].Latitude]));
                }
                else{ //分批查询完后再赋时间戳
                    window.localStorage.requestTimestamp = new Date().Format("yyyy-MM-dd hh:mm:ss");
                }
            }
        })
    }
    //

};

gisApp.Common.FormatTaxiState = function (arrState,online){
    var retval = "";
    if(online==false) retval = ",离线";
    if(arrState["0005"]=="01") retval = retval + ",电召";
    if(arrState["0009"]=="00") retval = retval + ",熄火";
    if(arrState["000A"]=="00") retval = retval + ",空车";
    if(arrState["000A"]=="01") retval = retval + ",重车";
    return retval.substring(1,retval.length);
}

gisApp.Common.FormatDirection = function(angle){
    if(angle==null || angle==undefined) return "";

    var angle = Math.abs(angle * 2);
    var dir = "北";
    if(angle>=22.5 && angle<=67.5) dir = "东北";
    if(angle>=67.5 && angle<=112.5) dir = "东";
    if(angle>=112.5 && angle<=157.5) dir = "东南";
    if(angle>=157.5 && angle<=202.5) dir="南";
    if(angle>=202.5 && angle<=247.5) dir="西南";
    if(angle>=247.5 && angle<=292.5) dir="西";
    if(angle>=292.5 && angle<=337.5) dir="西北";
    if((angle>=337.5 && angle<=360) || (angle>=0 && angle<=22.5)) dir = "北";
    return dir;
}

//返回天地图图层（矢量、标注、卫星）
gisApp.Common.GetTdtLayer = function(lyr){
    //var url = "http://localhost:8081/lzugis/tdttile?T="+lyr+"&X={x}&Y={y}&L={z}";
    var url = "http://t4.tianditu.com/DataServer?T="+lyr+"&x={x}&y={y}&l={z}";
    //卫星影像
    if(lyr.indexOf("img")>-1)
        url = "http://t0.tianditu.com/img_c/wmts?layer=img&style=default&tilematrixset=c&Service=WMTS&Request=GetTile&Version=1.0.0&Format=tiles&TileMatrix={z}&TileCol={x}&TileRow={y}";
    var projection = ol.proj.get("EPSG:4326");
    var projectionExtent = [ -180, -90, 180, 90 ];
    var maxResolution = (ol.extent.getWidth(projectionExtent) / (256 * 2));
    var resolutions = new Array(16);
    var z;
    for (z = 0; z < 16; ++z) {
        resolutions[z] = maxResolution / Math.pow(2, z);
    }
    var tileOrigin = ol.extent.getTopLeft(projectionExtent);
    var layer = new ol.layer.Tile({
        extent: [ -180, -90, 180, 90 ],
        source: new ol.source.TileImage({
            tileUrlFunction: function(tileCoord) {
                var z = tileCoord[0]+1;
                var x = tileCoord[1];
                var y = -tileCoord[2]-1;
                var n = Math.pow(2, z + 1);
                x = x % n;
                if (x * n < 0) {
                    x = x + n;
                }
                //console.info("vector: x:" + x.toString() + ",y:" + y.toString() + ",z:" + z.toString());

                return url.replace('{z}', z.toString())
                    .replace('{y}', y.toString())
                    .replace('{x}', x.toString());
            },
            projection: projection,
            tileGrid: new ol.tilegrid.TileGrid({
                origin: tileOrigin,
                resolutions: resolutions,
                tileSize: 256
            })
        })
    });
    return layer;
};

//obsoleted method.
gisApp.Common.GetTrafficFlowLayer = function(){
    //var url = "http://its.map.baidu.com:8002/traffic/TrafficTileService?level={z}&x={x}&y={y}&time=1478768786115&v=081&smallflow=1&scaler=1";
    var url = "http://its.map.baidu.com:8002/traffic/TrafficTileService?level={z}&x={x}&y={y}&time=1373790856265&label=web2D&v=017";
    var projection = ol.proj.get("EPSG:3857");
    var resolutions = [];
    for(var i=0; i<19; i++){
        resolutions[i] = Math.pow(2, 18-i);
    }
    var tilegrid  = new ol.tilegrid.TileGrid({
        origin: [-1475,16050], //偏移量
        resolutions: resolutions
    });

    var layer = new ol.layer.Tile({
        source: new ol.source.TileImage({
            projection: projection,
            tileGrid: tilegrid,
            tileUrlFunction: function(tileCoord, pixelRatio, proj) {
                if (!tileCoord) {
                    return "";
                }
                var z = tileCoord[0];
                var x = tileCoord[1];
                var y = tileCoord[2];

                if (x < 0) {
                    x = "M" + (-x);
                }
                if (y < 0) {
                    y = "M" + (-y);
                }

                var now = Date.parse(new Date());
                //return "http://online3.map.bdimg.com/onlinelabel/?qt=tile&x=" + x + "&y=" + y + "&z=" + z + "&styles=pl&udt=20151021&scaler=1&p=1";
                return "http://its.map.baidu.com:8002/traffic/TrafficTileService?level=" + z + "&x=" + x + "&y=" + y + "&time=" + now + "&label=web2D&v=017"
            }
        })
    });

    return layer;
};

gisApp.Common.GetBdLayer = function(isBaseLayer){
    var projection = ol.proj.get("EPSG:3857");
    var resolutions = [];
    for(var i=0; i<19; i++){
        resolutions[i] = Math.pow(2, 18-i);
    }
    var tilegrid  = new ol.tilegrid.TileGrid({
        //origin: [-1475,16050], //偏移量
        origin: [-1430,16215], //偏移量
        resolutions: resolutions
    });

    var layer = new ol.layer.Tile({
        source: new ol.source.TileImage({
            projection: projection,
            tileGrid: tilegrid,
            tileUrlFunction: function(tileCoord, pixelRatio, proj) {
                if (!tileCoord) {
                    return "";
                }
                var z = tileCoord[0];
                var x = tileCoord[1];
                var y = tileCoord[2];

                if (x < 0) {
                    x = "M" + (-x);
                }
                if (y < 0) {
                    y = "M" + (-y);
                }

                var now = new Date();
                var ymd = now.getYear().toString() + now.getMonth().toString().PadLeft(2,'0') + now.getDay().toString().PadLeft(2,'0');
                var url = "http://online3.map.bdimg.com/onlinelabel/?qt=tile&x="+x+"&y="+y+"&z="+z+"&styles=pl&udt=" + ymd + "&scaler=1&p=1";
                if(!isBaseLayer) {
                    now = Date.parse(new Date());
                    url = "http://its.map.baidu.com:8002/traffic/TrafficTileService?level=" + z + "&x=" + x + "&y=" + y + "&time=" + now + "&label=web2D&v=017";
                }
                return url;
            }
        })
    });

    return layer;
};

gisApp.Common.GetSatellitePicture = function(options){
    var url = "http://t0.tianditu.com/img_c/wmts?layer=img&style=default&tilematrixset=c&Service=WMTS&Request=GetTile&Version=1.0.0&Format=tiles&TileMatrix={z}&TileCol={x}&TileRow={y}";
    var projection = ol.proj.get("EPSG:4326");
    var projectionExtent = [ -180, -90, 180, 90 ];
    var maxResolution = (ol.extent.getWidth(projectionExtent) / (256 * 2));
    var resolutions = new Array(18);
    var z;
    for (z = 0; z < 18; ++z) {
        resolutions[z] = maxResolution / Math.pow(2, z);
    }
    var tileOrigin = ol.extent.getTopLeft(projectionExtent);
    var layer = new ol.layer.Tile({
        extent: [ -180, -90, 180, 90 ],
        source: new ol.source.TileImage({
            tileUrlFunction: function(tileCoord) {
                var z = tileCoord[0]+1;
                var x = tileCoord[1];
                var y = -tileCoord[2]-1;
                var n = Math.pow(2, z + 1);
                x = x % n;
                if (x * n < 0) {
                    x = x + n;
                }
                //console.info("satellite: x:" + x.toString() + ",y:" + y.toString() + ",z:" + z.toString());

                return url.replace('{z}', z.toString())
                    .replace('{y}', y.toString())
                    .replace('{x}', x.toString());
            },
            projection: projection,
            tileGrid: new ol.tilegrid.TileGrid({
                origin: tileOrigin,
                resolutions: resolutions,
                tileSize: 256
            })
        })
    });

    return layer;
};

//底图：本地arcgis切片地图（高德）
gisApp.Common.BASELAYER_LOCAL_ARCGIS_TILE = new ol.layer.Tile({
    source: new ol.source.XYZ({
        tileUrlFunction: function(xyz){
            var z = xyz[0];
            var x = Math.abs(xyz[1]);
            var y = Math.abs(xyz[2])-1;
            x = 'C' + x.toString(16).PadLeft(8,'0').toUpperCase();

            y = 'R' + y.toString(16).PadLeft(8,'0').toUpperCase();
            z = 'L' + z.toString().PadLeft(2,'0');

            var url = baseuri.local_arcgis_tile + z + '/' + y + '/' + x + '.png';
            return url;
        }
        // tileGrid: new ol.tilegrid.TileGrid({
        //     origin: [options.originX, -options.originY]
        // })
    })
});

gisApp.Common.BASELAYER_LOCAL_ARCGIS_GOOGLE_TILE = new ol.layer.Tile({
    source: new ol.source.XYZ({
        tileUrlFunction: function(xyz){
            var z = xyz[0];
            var x = Math.abs(xyz[1]);
            var y = Math.abs(xyz[2])-1;
            x = 'C' + x.toString(16).PadLeft(8,'0').toUpperCase();

            y = 'R' + y.toString(16).PadLeft(8,'0').toUpperCase();
            z = 'L' + z.toString().PadLeft(2,'0');

            var url = baseuri.local_arcgis_google_tile + z + '/' + y + '/' + x + '.png';
            return url;
        }
    })
});

//底图：远程天地图
gisApp.Common.BASELAYER_REMOTE_TDT = gisApp.Common.GetTdtLayer("vec_c");

//底图：百度
gisApp.Common.BASELAYER_REMOTE_BAIDU = gisApp.Common.GetBdLayer(true);

//标注图层：远程天地图
gisApp.Common.MARKED_REMOTE_TDT = gisApp.Common.GetTdtLayer("cva_c");

//卫星影像：远程天地图
gisApp.Common.SATELLITE_REMOTE_TDT = gisApp.Common.GetTdtLayer("img_w");

//实时路况：远程百度
gisApp.Common.TRAFFICFLOW_REMOTE_BD = gisApp.Common.GetBdLayer(false);

//字符串左边不足补齐
String.prototype.PadLeft = function(totalWidth, paddingChar)
{
    if ( paddingChar != null )
    {
        return this.PadHelper(totalWidth, paddingChar, false);
    } else {
        return this.PadHelper(totalWidth, ' ', false);
    }
}

//字符串右边不足补齐
String.prototype.PadRight = function(totalWidth, paddingChar)
{
    if ( paddingChar != null )
    {
        return this.PadHelper(totalWidth, paddingChar, true);
    } else {
        return this.PadHelper(totalWidth, ' ', true);
    }

}

String.prototype.PadHelper = function(totalWidth, paddingChar, isRightPadded)
{

    if ( this.length < totalWidth)
    {
        var paddingString = new String();
        for (i = 1; i <= (totalWidth - this.length); i++)
        {
            paddingString += paddingChar;
        }

        if ( isRightPadded )
        {
            return (this + paddingString);
        } else {
            return (paddingString + this);
        }
    } else {
        return this;
    }
}

// 对Date的扩展，将 Date 转化为指定格式的String
// 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符，
// 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
// 例子：
// (new Date()).Format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423
// (new Date()).Format("yyyy-M-d h:m:s.S")      ==> 2006-7-2 8:9:4.18
Date.prototype.Format = function(fmt)
{ //author: meizz
    var o = {
        "M+" : this.getMonth()+1,                 //月份
        "d+" : this.getDate(),                    //日
        "h+" : this.getHours(),                   //小时
        "m+" : this.getMinutes(),                 //分
        "s+" : this.getSeconds(),                 //秒
        "q+" : Math.floor((this.getMonth()+3)/3), //季度
        "S"  : this.getMilliseconds()             //毫秒
    };
    if(/(y+)/.test(fmt))
        fmt=fmt.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length));
    for(var k in o)
        if(new RegExp("("+ k +")").test(fmt))
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));
    return fmt;
}

//所有样式名为datetimeInput都会被格式化
function InitDateTimePicker() {
    console.info("InitDateTimePicker.");
    var now = new Date();
    window.setTimeout(function(){
        $.datetimepicker.setLocale('ch');

        $(".datetimeInput").datetimepicker({
            lang: 'ch',
            format: 'Y-m-d H:i:s',
            value: now.getFullYear().toString() + '-' + (now.getMonth() + 1) + '-' + now.getDate().toString() + ' 06:00:00',
            step: 30
        });
    });
}

//格式化日期
function FormatTimePicker(that,format,dt_value){
    var now = new Date();
    window.setTimeout(function(){
        $.datetimepicker.setLocale('ch');

        $(that).datetimepicker({
            datepicker:false,
            lang: 'ch',
            format: format, //'Y-m-d H:i:s',
            value: dt_value, //now.getFullYear().toString() + '-' + (now.getMonth() + 1) + '-' + now.getDate().toString() + ' 06:00:00',
            step: 30
        });
    });
}

//扩展ol.Collection方法，代替push方法，增加时检查item是否存在，存在则不再增加
ol.Collection.prototype.append = function(item){
    var exist = false;
    this.forEach(function(ele,index,array){
        if(ele === item) {
            exist = true;
        }
    });
    if(!exist)
        this.push(item);
};

//自定义日期列（jsgrid扩展)
/*var CustomDateField = function(config) {
    jsGrid.Field.call(this, config);
};

var CustomTimeField = function(config) {
    jsGrid.Field.call(this, config);
};

CustomDateField.prototype = new jsGrid.Field({
    css: "date-field",            // redefine general property 'css'
    align: "center",              // redefine general property 'align'
    //myCustomProperty: "foo",      // custom property

    sorter: function(date1, date2) {
        return new Date(date1) - new Date(date2);
    },

    itemTemplate: function(value) {
        return new Date(value).Format("yyyy-MM-dd hh:mm:ss");
    },

    insertTemplate: function(value) {
        return this._insertPicker = $("<input>").datetimepicker({ lang: 'ch', format: 'Y-m-d H:i:s', value : new Date(value)});
    },

    editTemplate: function(value) {
        return this._editPicker = $("<input>").datetimepicker({lang: 'ch', format: 'Y-m-d H:i:s', value : new Date(value)});
    },
    insertValue: function() {
        return this._insertPicker.val();
    },

    editValue: function() {
        return this._editPicker.val();
    }
});

CustomTimeField.prototype = new jsGrid.Field({
    css: "date-field",            // redefine general property 'css'
    align: "center",              // redefine general property 'align'
    //myCustomProperty: "foo",      // custom property

    sorter: function(date1, date2) {
        return new Date(date1) - new Date(date2);
    },

    itemTemplate: function(value) {
        return value;
        //return new Date(value).Format("hh:mm:ss");
    },

    insertTemplate: function(value) {

        return this._insertPicker = $("<input>").datetimepicker({ lang: 'ch', datepicker:false, format: 'H:i:s', value : value});
    },

    editTemplate: function(value) {
        return this._editPicker = $("<input>").datetimepicker({lang: 'ch', datepicker:false, format: 'H:i:s', value : value});
    },
    insertValue: function() {
        return this._insertPicker.val();
    },

    editValue: function() {
        return this._editPicker.val();
    }
});

jsGrid.fields.date = CustomDateField;
jsGrid.fields.time = CustomTimeField;*/

function SimpleQuene(len){
	    var capacity=len;
	    var list=[];
	    this.in=function(data){
	        if(!data){return false;}
	        if(list.length == capacity){
	            this.out();
	        }
	        list.push(data);
	        return true;
	    };
	    this.out=function(){
	        return list.splice(0,1).join();
	    }
	    this.isEmpty=function(){
	        return list.length==0?true:false;
	    }
	    this.size=function(){
	        return list.length;
	    }

		this.forEach=function(fn){
			 var i, ii;
			  for (i = 0, ii = list.length; i < ii; ++i) {
				  fn(list[i]);
			  }
		    }
	}

function HashMap(){
    //定义长度
    var length = 0;
    //创建一个对象
    var obj = new Object();

    /**
     * 判断Map是否为空
     */
    this.isEmpty = function(){
        return length == 0;
    };

    /**
     * 判断对象中是否包含给定Key
     */
    this.containsKey=function(key){
        return (key in obj);
    };

    /**
     * 判断对象中是否包含给定的Value
     */
    this.containsValue=function(value){
        for(var key in obj){
            if(obj[key] == value){
                return true;
            }
        }
        return false;
    };

    /**
     *向map中添加数据
     */
    this.put=function(key,value){
        if(!this.containsKey(key)){
            length++;
        }
        obj[key] = value;
    };

    /**
     *向map中添加数据
     */
    this.putAll=function(map){
        for(var key in map.keySet()){
            if (!this.containsKey(map.keySet()[key]))
                this.put(map.keySet()[key],map.get(map.keySet()[key]));
        }
    };

    /**
     * 根据给定的Key获得Value
     */
    this.get=function(key){
        return this.containsKey(key)?obj[key]:null;
    };

    /**
     * 根据给定的Key删除一个值
     */
    this.remove=function(key){
        if(this.containsKey(key)&&(delete obj[key])){
            length--;
        }
    };

    /**
     * 获得Map中的所有Value
     */
    this.values=function(){
        var _values= new Array();
        for(var key in obj){
            _values.push(obj[key]);
        }
        return _values;
    };

    /**
     * 获得Map中的所有Key
     */
    this.keySet=function(){
        var _keys = new Array();
        for(var key in obj){
            _keys.push(key);
        }
        return _keys;
    };

    /**
     * 获得Map的长度
     */
    this.size = function(){
        return length;
    };

    /**
     * 清空Map
     */
    this.clear = function(){
        length = 0;
        obj = new Object();
    };
}