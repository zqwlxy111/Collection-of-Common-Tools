'use restrict'

if(!window.gisApp){
	window.gisApp={};
}

var gisApp = window.gisApp;

gisApp.Canvas = function(that, options){
	this.options = options || {};
	this.mapUtils = that;
	// this.mapEvents = {};
	// this.mapEventsHolder = {};
	this.mapInteractions = [];
	this.allFeatures = new ol.Collection();

	this.drawingInteraction = null;
	this.source = new ol.source.Vector({features: this.allFeatures, wrapX: false});
	this.vectorLayer = new ol.layer.Vector({
		source: this.source,
		style: this.CanvasStyle //gisApp.Common.CreateStyle('rgba(200,200,200,0.5)','#333',1.5,'查询')
	});

	this.featureAdded = null; //the event on feature added.
	this.interactionRemoved = null; //the event will be triggered on user press the ESC key.

	this.source.on("addfeature",$.proxy(function(e){
			//only reserve last feature in collection of Features.
			if(this.options.singleDrawMode){
				var removingFeature = new ol.Collection();
				this.source.forEachFeature(function(feature){
					if(e.feature!==feature)
						removingFeature.push(feature);
				});

				while(feature = removingFeature.pop()){
					this.source.removeFeature(feature);
					console.info('last feature has been removed.');
				}
			}

			//transform circular geometry to an approximated polygon.
			if(e.feature.getGeometry().getType() == ol.geom.GeometryType.CIRCLE){
				var polygon = ol.geom.Polygon.fromCircle(e.feature.getGeometry());
				e.feature.setGeometry(polygon);
				//console.info(polygon);
			}

			if(typeof this.featureAdded == "function" && this.featureAdded){
				this.featureAdded(e.feature);
			}
		},this)
	);
	this.mapUtils.map.addLayer(this.vectorLayer);

	document.onkeydown = $.proxy(function(ev)
	{
		var oEvent=ev || event;
		//console.info(oEvent.keyCode);

		//Esc键的keyCode是27
		if(oEvent.keyCode==27)
		{
			if(this.drawingInteraction!=null) {
				this.mapUtils.map.removeInteraction(this.drawingInteraction);
				if(this.interactionRemoved && typeof this.interactionRemoved == "function")
					this.interactionRemoved(this.drawingInteraction);
				this.drawingInteraction = null;
			}
		}
	},this);

	//this.callbackFunction = null;
};

gisApp.Canvas.prototype.CanvasStyle = function(feature,solution){
	var lineColor = feature.get("lineColor");
	if(!lineColor)
		lineColor = "#6AA4D2";
	
	var opts = {
		fill: new ol.style.Fill({
			color: 'rgba(200,200,200,0.5)'
		}),
		stroke: new ol.style.Stroke({
			color: lineColor,
			width: 4
		}),
		image: new ol.style.Circle({
			radius: 7,
			fill: new ol.style.Fill({
				color: '#cc33ff'
			})
		})
	};

	var textContent = feature.get("name") ? feature.get("name") : "";

	if(textContent){
		opts.text = new ol.style.Text({
			text: textContent,
			fill: new ol.style.Fill({
				color: '#000'
			}),
			stroke: new ol.style.Stroke({
				color: '#fff',
				width: 3
			})
		});
	}

	var style = new ol.style.Style(opts);


	return style;
}

// 打开画板，同时将状态置为指定的编辑模式
// @geo_type = gisApp.GEOMETRYTYPE,几何类型
gisApp.Canvas.prototype.Open = function(geo_type,isSingleDrawMode){

	this.mapUtils.ClearInteraction();
	//重新设置一下样式
	this.SetStyle(this.CanvasStyle);

	if(isSingleDrawMode)
		this.options.singleDrawMode = isSingleDrawMode;
	var geoFun = null;
	if(geo_type==="Rectangle")
	{
		geo_type="LineString";
		// this paragraph code can be replaced by ol.interaction.Draw.createBox in higher version
		geoFun = function(coordinates, geometry) {
			if (!geometry) {
				geometry = new ol.geom.Polygon(null);
			}
			var start = coordinates[0];
			var end = coordinates[1];
			geometry.setCoordinates([
				[start, [start[0], end[1]], end, [end[0], start[1]], start]
			]);
			return geometry;
		}
	};

	var opts = {source: this.source, type: geo_type, deleteCondition: function(e){
		console.info(e);
	}};
	if(geo_type === "Rectangle") opts.maxPoints = 2;
	if(geoFun) opts.geometryFunction = geoFun;

	var appendInteraction = new ol.interaction.Draw(opts);
	this.drawingInteraction = appendInteraction;
	this.mapUtils.mapInteractions.push(appendInteraction);
};

//编辑模式（只编辑选中的要素）
gisApp.Canvas.prototype.Modify = function(){
	//移动feature还未实现
	this.mapUtils.mapInteractions.clear();
	var selectInteraction = new ol.interaction.Select({condition: ol.events.condition.click, wrapX: false});
	var modifyInteraction = new ol.interaction.Modify({features:  selectInteraction.getFeatures(), wrapX: false});
	//var moveInteraction = new ol.interaction.DragAndDrop({wrapX: false});

	this.mapUtils.mapInteractions.push(selectInteraction);
	this.mapUtils.mapInteractions.push(modifyInteraction);
	//this.mapUtils.mapInteractions.push(moveInteraction);
};

//结束编辑状态，关闭canvas
gisApp.Canvas.prototype.Close = function(){
	this.source.clear();
	this.mapUtils.Clear();
	//关闭地图画布的交互状态
	// while(this.interaction = this.mapInteractions.pop())
	// 	this.mapUtils.map.removeInteraction(this.interaction);
};

gisApp.Canvas.prototype.Clear = function () {
	this.source.clear();
	this.allFeatures.clear();
};

gisApp.Canvas.prototype.GetFeatures = function(){
	return this.source.getFeatures();
};

gisApp.Canvas.prototype.GetFeatureById = function(fid){
	return this.source.getFeatureById(fid);
};

gisApp.Canvas.prototype.SetStyle = function(style){
	this.vectorLayer.setStyle(style);
};

gisApp.Canvas.prototype.GetLastGeometry = function(closeCanvas){
	var idx = this.source.getFeatures().length-1;
	if(idx==-1) return null;
	if(closeCanvas) this.Close();
	return this.source.getFeatures()[idx].getGeometry();
};

//绘制给定的几何图形
gisApp.Canvas.prototype.DrawGeometry = function(geom, clear){
	var feature = null;
	if(geom.getType() == ol.geom.GeometryType.POLYGON)
		feature = new ol.Feature({geometry: new ol.geom.Polygon(geom.getCoordinates())});
	if(geom.getType() == ol.geom.GeometryType.LINE_STRING)
		feature = new ol.Feature({geometry: geom});

	if(feature!=null) {
		if(clear) this.Clear();
		this.source.addFeature(feature);
	}
};

gisApp.Canvas.prototype.AppendFeature = function(feature,clear){
	if(feature){
		if(clear) this.Clear();
		this.source.addFeature(feature);
	}
};

gisApp.Canvas.prototype.DrawPoint = function(){

};

gisApp.Canvas.prototype.DrawRectangle = function () {
	return ol.interaction.Draw.createBox();
};

gisApp.Canvas.prototype.DrawPolygon = function () {
	return ol.interaction.Draw.createRegularPolygon(4);
};