/**
 * Created by Justinguo on 2016-11-1.
 */
if (!window.gisApp) {
    window.gisApp = {};
}
var gisApp = window.gisApp;

gisApp.TopoAlgorithm=function(){

};

//a,b均为OpenLayers中的geometry类型;
gisApp.TopoAlgorithm.DistanceOp = function(a,b){
    var parser = new jsts.io.OL3Parser();
    if(a instanceof Array && b instanceof Array){
        a = new ol.geom.Point(a);
        b = new ol.geom.Point(b);
    }
    var a1 = parser.read(a);
    var b1 = parser.read(b);

    var op = new jsts.operation.distance.DistanceOp(a1,b1);
    return op.distance();


}

gisApp.TopoAlgorithm.Covers = function(a,b){
    var parser = new jsts.io.OL3Parser();
    var a1 = parser.read(a);
    var b1 = parser.read(b);
    return a1.covers(b1);
};

gisApp.TopoAlgorithm.GetEnvelope = function(geom){
    var parser = new jsts.io.OL3Parser();
    var geo = parser.read(geom);
    return parser.write(geo.getEnvelope());
};

/**
 * it will obtain a buffer area by a specified meters.
 * @param coord
 * @param meters
 * @returns {*}
 * @constructor
 */
gisApp.TopoAlgorithm.Buffer = function(coord, meters){
    var p = new ol.geom.Point(coord);
    var mercator_p = p.transform("EPSG:4326","EPSG:3857");
    var parser = new jsts.io.OL3Parser();
    var geo = parser.read(mercator_p);

    var result = parser.write(geo.buffer(meters));
    return result.transform("EPSG:3857","EPSG:4326");
};

gisApp.TopoAlgorithm.Distance = function(a,b){
    var wgs84Sphere = new ol.Sphere(6378137);
    return wgs84Sphere.haversineDistance(a,b);
};

gisApp.TopoAlgorithm.PathLength = function(coords){
    var totalLength = 0;
    for(var i=0;i<coords.length-1;i++){
        totalLength += gisApp.TopoAlgorithm.Distance(coords[i],coords[i+1]);
    }
    return totalLength;
}