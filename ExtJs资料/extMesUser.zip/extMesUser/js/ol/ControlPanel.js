/**
 * Created by Justinguo on 2016-09-07.
 */

if (!window.gisApp) {
    window.gisApp = {};
}
var gisApp = window.gisApp;

gisApp.ControlPanel = function(that, options) {
    this.mapUtils = that;
    // var db = new loki();
    // var db_cars = db.addCollection('cars');
    // db_cars.ensureUniqueIndex('id');
    // this.cars = db_cars;
    this.initialized = false;
    this.currentcar = {}; //当前选中的播放历史轨迹的车辆信息
    this.intervalId = null;
    this.subscribeId = null;  // 订阅websocket ID
    this.ws = null;           // websocket handler
    //this.ProtoBuf = dcodeIO.ProtoBuf;
    // 显示画框查询
    this.extentSearchResult = null;
    //this.Message = this.ProtoBuf.loadProtoFile("./msgList.proto").build("MsgList");
}

gisApp.ControlPanel.prototype.Initialize = function(){


    if(this.initialized==false && this.mapUtils.mapStatus == gisApp.MAP_STATE.REALTIME) {
        // var filterString = gisApp.FilterOptions;
        // filterString.filter.PropertyName = "name";
        // filterString.filter.RelationExpression = gisApp.RELATION_EXPRESSION.Equal;
        // filterString.filter.Expression = "car100";
        //
        // mapUtils.filter = coll;

        setInterval('mapUtils.controlPanel.validatePerformance()',5000);
        //this.LoadTreeview("jstree_car");
    }
    this.initialized=true;


}

gisApp.ControlPanel.prototype.showOnMap = function(busno,checked){
    mapUtils.switchMapStatus(gisApp.MAP_STATE.REALTIME);
    if(checked) {
        this.describe();
    }else{
        var removingFea = mapUtils.source_cars.getFeatureById("car" + busno);
        if(removingFea!=null)
        mapUtils.source_cars.removeFeature(removingFea);
    }
};

gisApp.ControlPanel.prototype.validatePerformance = function(){
    for(var i=0;i<1000;i++){
        var long = 114 + Math.random();
        var lat = 22 + Math.random();

        var car = gisApp.Common.CreateVehicleObject();
        car.id = 'car' + i;
        car.properties.name = 'car' + i;
        car.geometry.coordinates[0] = Number(long);
        car.geometry.coordinates[1] = Number(lat);
        //car.geometry.coordinates[2] = 13590303139;
        mapUtils.RefreshCarData(car);
    }

    //this.refreshLocation();
};

gisApp.ControlPanel.prototype.refreshLocation = function(){
    var retval = [];
    $.ajax({
        method: 'GET',
        url: baseuri.service + '/gis/getAllRealtimeLocation',
        contentType: "application/json; charset=UTF-8",
        dataType: "json",
        success: function(data){
            var f = mapUtils.source_cars.getFeatureById('car100');
            if(f!=null && data!=null)
                f.setGeometry(new ol.geom.Point([data[0].Longitude, data[0].Latitude]));
        }
    })

    return retval;
};

gisApp.ControlPanel.prototype.describe = function () {
    var selectedIDs = [];
    var selectedRows;
    // if($location.search().A!=undefined)
    //     selectedRows = $scope.carGridOptions.data;
    // else
    //     selectedRows = $scope.carGridApi.selection.getSelectedRows();
    // for(var i in selectedRows)
    //     selectedIDs.push(selectedRows[i].properties.serial);
    var selectedIDs="";
    $.each($("#ddl-bus").val(),function(idx,ele){
        selectedIDs = (idx==0) ? ele[1] : ',' + ele[1];
    });

    this.subscribeId = new Date().getTime();
    var data = {
        "id": this.subscribeId,
        "subscribeType": ["001", "002", "003", "004"],
        "deviceTypeList": selectedIDs
    };

    $.ajax({
        type: 'GET',
        url: pathdatas.path + "background/subscribe/wskey",
        data: JSON.stringify(data),
        contentType: "application/json; charset=UTF-8",
        dataType: "json",
        success: function (data) {
            this.ws = new WebSocket("ws://192.168.13.73:8090/" + data.wsKey);
            this.ws.binaryType = "arraybuffer"; // We are talking binary
            this.ws.onopen = function () {
                console.info("WebsocketOpen");
            };
            this.ws.onmessage = function (e) {
                //this.ws.send('1');
                //var messageInfo = Message.decode(e.data);
                var gpsinfo = JSON.parse(e.data);
                if ((Number(gpsinfo.longitude) != 0) &&
                    (Number(gpsinfo.latitude) != 0)) {
                    //car object should be initialized first here.

                    var car = {};
                    car["type"] = "Feature";
                    car["id"] = "car"+gpsinfo.deviceNum;
                    car["geometry"] = {};
                    car["geometry"]["type"] = "Point";
                    car["geometry"]["coordinates"] = [];
                    car["properties"] = {};
                    car["properties"]["serial"] = "";
                    car["properties"]["name"] = gpsinfo.deviceNum;
                    car["properties"]["dis"] = true;


                    //var car = {}; //this.db_cars.by('id', 'car' + messageInfo.serialnum + messageInfo.protocol);
                    car.geometry.coordinates[0] = Number(gpsinfo.longitude);
                    car.geometry.coordinates[1] = Number(gpsinfo.latitude);
                    car.geometry.coordinates[2] = new Date(gpsinfo.sendTime);
                    car.properties.direction = gpsinfo.angle;
                    car.properties.temp = gpsinfo.carTemp;
                    car.properties.speed = gpsinfo.speed;
                    var point = (new ol.format.GeoJSON()).readFeature(JSON.stringify(car));

                    mapUtils.RefreshCarData(point);
                    //this.db_cars.update(car);
                }
            };

            this.ws.onclose = function () {
                console.info("WebsocketClose");
                this.ws = null;
            };
            this.ws.onerror = function () {
                console.info("WebsocketError");
                this.ws = null;
            };
        }
    });
};

gisApp.ControlPanel.prototype.showTracker = function () {
    if ($('#hsStartTime')[0].value==null || $('#hsEndTime')[0].value==null){
        bootbox.alert("请先选择时间");
        return;
    }
    if ($('#hsEndTime')[0].value<$('#hsStartTime')[0].value){
        bootbox.alert("结束时间不能小于开始时间");
        return;
    }

    $('#alertModal').modal('show');
    var spinner = new Spinner().spin();
    document.getElementById("spin").appendChild(spinner.el);
    document.getElementById('spinInfo').innerHTML = "正在获取轨迹数据,耗时0秒...";

    var info = document.getElementById('spinInfo');
    var startTime = new Date(); //开始时间
    var intervalId = window.setInterval(function () {
        info.innerHTML = "正在获取轨迹数据,耗时" +
            parseInt((new Date() - startTime) / 1000) +
            "秒...";
    }, 1000);

    //将线路的起终点feature赋给ShowTracker
    //var line_param = this.currentcar.l_id;
    var line_param = $("#ddl-bus-single").val().split(',')[1];
    $.ajax({
        method: 'GET',
        url: pathdatas.path + "background/gis/findStation/" + line_param + "_1",
        contentType: "application/json; charset=UTF-8",
        dataType: "json",
        success: function (data) {
            if(data.features.length>0) {
                mapUtils.showTracker.showStation(data.features);
                mapUtils.showTracker.startStation = data.features[0].geometry.coordinates;
                mapUtils.showTracker.endStation = data.features[data.features.length-1].geometry.coordinates;
            }
        }
    });

    var sdt = new Date($("#hsStartTime")[0].value).Format("YYYYMMDDhhmm");
    var edt = new Date($("#hsEndTime")[0].value).Format("YYYYMMDDhhmm");
    this.currentcar.name = $("#ddl-bus-single option:selected").text();
    var postData = {
        "busId": this.currentcar.name,
        "startTime": sdt,
        "endTime": edt
    };

    $.ajax({
        type: 'POST',
        url: pathdatas.service + "interfaceservice/data/gpsinfo",
        data: JSON.stringify(postData),
        contentType: "application/json; charset=UTF-8",
        dataType: "json",
        success: function (data) {
            window.clearInterval(this.intervalId);
            //document.getElementById("info").style.display = "inline";
            if (data.length > 0) {
                var info = document.getElementById('spinInfo');
                info.innerHTML += "</br>成功获取" + data.length + "个坐标点,正在绘制轨迹...";
                window.setTimeout(function () {
                    mapUtils.showTracker.turnOn();
                    mapUtils.showTracker.AppendJsonData(mapUtils.controlPanel.currentcar.name, data);
                    mapUtils.panToPoints(mapUtils.showTracker.extent);
                    mapUtils.map.render();
                    document.getElementById("primaryHolder").style.display="block";
                    for(var i=0;i<data.length;i++){
                        data[i].rowindex = i; //增加数据行索引
                        data[i].standardTime = new Date(data[i].time).Format("YYYY-MM-DD HH:mm");
                    }
                    $("#primaryGrid").jsGrid({
                        width: "360px",
                        height: "400px",

                        data: data,

                        fields: [
                            // {title: '线路号', name: 'properties.lineSerial'},
                            // {title: '线路名称', name: 'properties.l_name'},
                            // {title: '司机姓名', name: 'properties.drive_name'},
                            // {title: '电话', name: 'properties.phone'},
                            // {title: '状态', name: 'properties.statusStr'},
                            // {title: '当前站', name: 'properties.self_station'},
                            {title: '时间', width:80, name: 'standardTime'},
                            {title: '车速', width:60, name: 'speed'},
                            {title: '角度', width:60, name: 'angle'},
                            {title:'是否超速', width:80, name: 'overspeed'}
                        ],
                        rowClick:function(e){
                            console.info(e);
                            mapUtils.showTracker.trackerVal = e.itemIndex;
                            mapUtils.showTracker.trackAnimation(e.itemIndex/data.length,mapUtils.showTracker);
                        }
                    });
                });

                window.setTimeout(function () {
                    document.getElementById("spin").removeChild(spinner.el);
                    $('#alertModal').modal('hide');
                    if(data.length>0) {
                        document.getElementById("traceHolder").innerHTML = document.getElementById("tracePlayer").innerHTML;
                        //console.info(document.getElementById("traceHolder").innerHTML);
                        document.getElementById("tracePlayer").innerHTML = "";
                    }
                }, 3000);
            } else {
                bootbox.alert("没有查到数据");
                document.getElementById("spin").removeChild(spinner.el);
                $('#alertModal').modal('hide');
            }
        }
    });
};

gisApp.ControlPanel.prototype.LocateVehicle = function(f){
    if (f.geometry.coordinates[0] != 0 && f.geometry.coordinates[1] != 0) {
        scrollTo(0,0);
        mapUtils.panToPoint([f.geometry.coordinates[0], f.geometry.coordinates[1]], 15);
    }
    else
        bootbox.alert("未找到位置，无法定位");
    //console.info(item);
}

gisApp.ControlPanel.prototype.LoadTreeview = function(treeid,holder){
        //document.getElementById("primaryHolder").style.display="block";

        // $http.get($scope.app.path + "background/Utils/Line/" + ($scope.team.id || ""))
        //     .success(function(response) {
        //         $scope.lines = response;
        //document.getElementById("dtStart").value = new Date().toDateString();
        //$("#dtStart").datetimepicker("setStartDate",new Date().toDateString());

        var line_options = [];
        var bus_options = [];
        $.ajax({
           type:"GET",
            url: pathdatas.path + "background/Utils/Line/",
            contentType:"application/json; charset=UTF-8",
            success: function(data){
                var json = JSON.parse(data);
                $.each(json,function(i,n){
                    var item = {};
                    item.label = n.name;
                    item.value = n.id;
                    line_options.push(item);
                });

                $("#ddl-line").multiselect({
                    enableFiltering: true,
                    includeSelectAllOption: true,
                    nonSelectedText: "请选择线路",
                    allSelectedText: "全选",
                    nSelectedText: '已选择',
                    onChange: function (option, checked, select) {
                        var param = "";
                        var selectedValue = $('#ddl-line').val();
                        $.each(selectedValue,function(i,value){
                            param += "," + value;
                        });
                        param = param.substring(1);
                        $.ajax({
                            type: "GET",
                            url: pathdatas.path + "background/gis/findCar/" + param,
                            //url: pathdatas.path + "background/Utils/Bus/" + param,
                            contentType: "application/json; charset=UTF-8",
                            success: function (data) {
                                var json = JSON.parse(data);
                                $.each(json.features,function(i,n){
                                    var item = {};
                                    item.label = n.properties.name;
                                    item.value = n.properties.serial + ',' + n.properties.l_id;
                                    item.attribute = {};
                                    item.attribute.lineID  = n.properties.l_id;
                                    //item.value = n.properties.serial;
                                    bus_options.push(item);
                                });
                                $("#ddl-bus").multiselect({
                                    enableFiltering: true,
                                    includeSelectAllOption: true,
                                    maxHeight:250,
                                    nonSelectedText: "请选择车辆",
                                    allSelectedText: "全选",
                                    nSelectedText: '已选择',
                                    onChange: function(option, checked, select) {
                                        mapUtils.controlPanel.showOnMap(option.text(),checked);
                                    }
                                });
                                $("#ddl-bus").multiselect('dataprovider',bus_options);
                                $("#ddl-bus").multiselect('rebuild');

                                $("#ddl-bus-single").multiselect('dataprovider',bus_options);
                                $("#ddl-bus-single").multiselect('rebuild');
                                // $("#ddl-bus-single").multiselect({
                                //     enableFiltering: true
                                // });


                                //reloading bus data.

                            }
                        });
                        //onchange
                    }
                });
                $("#ddl-line").multiselect('dataprovider',line_options);
                // $("#ddl-bus").multiselect('dataprovider',bus_options);
                // $("#ddl-bus-single").multiselect('dataprovider',bus_options);

                // $("#ddl-bus").multiselect({
                //     nonSelectedText: "选择车辆",
                //     allSelectedText: "全选",
                //     nSelectedText: '已选择'
                // });
                //
                // $("#ddl-bus-single").multiselect({
                //     nonSelectedText: "选择车辆",
                //     allSelectedText: "全选",
                //     nSelectedText: '已选择'
                // });

                // window.setTimeout(function(){
                //     var content = document.getElementById("primaryContent").outerHTML;
                //     document.getElementById("primaryContent").outerHTML="";
                //     document.getElementById("primaryHolder").innerHTML = content ;
                // },10000);

            }
        });

        var dom = $('#' + treeid);
        var treeUrl = pathdatas.path + "background/gis/findCarTree/" + ((treeid=="jstree_mark") ? "1" : "0");

}

// 画框查询
gisApp.ControlPanel.prototype.searchInExtent = function (state) {
    if (!state) {
        // $scope.displayState.searchInExtent = false;
        // $scope.displayState.historyTracking = false;
        mapUtils.switchExtentSearchStatus(false);
        document.getElementById("info").style.display = "none";
        mapUtils.showTracker.playTracker(false);
        document.getElementById('position').value = 0;
        mapUtils.showTracker.trackerVal = 0;
        mapUtils.switchMapStatus(gisApp.MAP_STATE.REALTIME);
        return;
    }

    if ($('#hsStartTime')[0].value == null || $('#hsEndTime')[0].value == null) {
        bootbox.alert("请先选择时间");
        return;
    }
    if ($('#hsEndTime')[0].value < $('#hsStartTime')[0].value) {
        bootbox.alert("结束时间不能小于开始时间");
        return;
    }


    mapUtils.switchExtentSearchStatus(true, function (evt) {
        var extent = evt.feature.getGeometry().getExtent();
        var sdt = new Date($("#hsStartTime")[0].value).Format("YYYYMMDDhhmm");
        var edt = new Date($("#hsEndTime")[0].value).Format("YYYYMMDDhhmm");
        var data = {
            "startTime": sdt,
            "endTime": edt,
            "latitude1": extent[1],
            "longitude1": extent[0],
            "latitude2": extent[3],
            "longitude2": extent[2],
            "minutes": "1"
        };

        $('#alertModal').modal('show');
        var spinner = new Spinner().spin();
        document.getElementById("spin").appendChild(spinner.el);
        document.getElementById('spinInfo').innerHTML = "正在获取轨迹数据,耗时0秒...";

        var info = document.getElementById('spinInfo');
        var startTime = new Date(); //开始时间
         var intervalId = window.setInterval(function () {
            info.innerHTML = "正在获取轨迹数据,耗时" +
                parseInt((new Date() - startTime) / 1000) +
                "秒...";
        }, 1000);

        $.ajax({
            type: 'POST',
            url: pathdatas.service + "interfaceservice/data/inrect",
            data: JSON.stringify(data),
            contentType: "application/json; charset=UTF-8",
            dataType: "json",
            success: function (data) {
                window.clearInterval(intervalId);
                //$scope.displayState.historyTracking = true;
                document.getElementById("info").style.display = "inline";
                var info = document.getElementById('spinInfo');
                info.innerHTML += "</br>成功获取" + data.length + "个车辆通过该区域,正在绘制轨迹...";

                window.setTimeout(function () {
                    mapUtils.showTracker.turnOn();
                    for (var d in data) {
                        mapUtils.showTracker.AppendJsonData(data[d]["serialID"], data[d]["data"]);
                    }
                    mapUtils.panToPoints(mapUtils.showTracker.extent);
                    mapUtils.map.render();
                });

                window.setTimeout(function () {
                    document.getElementById("spin").removeChild(spinner.el);
                    $('#alertModal').modal('hide');
                }, 1000);

                this.extentSearchResult = data;
                //document.getElementById('location').innerHTML = "画框查询:查询到" + data.length + "辆车";

            }
        });
    })
};

//载入车辆查询结果，包含空间查询
gisApp.ControlPanel.prototype.LoadTerminalSearchResult = function(resultData){
    var holder = document.getElementById("PrimaryHolder");
    holder.style.display = "block";
    holder.innerHTML = "<div id='searchResultGrid'></div>"

    //loading data from restful interface.
    if(resultData==null || resultData == undefined){
        resultData = mapUtils.source_cars.getFeatures();
        var formatter = new ol.format.GeoJSON();
        resultData = formatter.writeFeatures(resultData);
        resultData = JSON.parse(resultData);
    }

    $("#searchResultGrid").jsGrid({
        width: "360px",
        height: "400px",
        data: resultData.features,
        fields: [
            {title: '时间', width:80, name: 'properties.name'},
            {title: '车速', width:60, name: 'properties.speed'},
            {title: '角度', width:60, name: 'properties.angle'},
            {title:'是否超速', width:80, name: 'properties.overspeed'}
        ],
        rowClick:function(e){
            var fid = e.item.id;
            var feature = mapUtils.source_cars.getFeatureById(fid);

            if(mapUtils.selectedFeature!=null)
                mapUtils.selectedFeature.set("selected",false);

            if(feature!=null) {
                mapUtils.selectedFeature = feature;
                feature.set("selected",true);
                mapUtils.panToPoint(feature.getGeometry().getCoordinates());
            }
            // console.info(e);
            // mapUtils.showTracker.trackerVal = e.itemIndex;
            // mapUtils.showTracker.trackAnimation(e.itemIndex/data.length,mapUtils.showTracker);
        }
    });

}

