/*
* 增加了新的天地图，数据源(source)设定影响未知，待验证
* 版本已升级到最新的3.19，部分方法需要重写；新版本支持即时刷新底图
* */

if (!window.gisApp) {
    window.gisApp = {};
}
var gisApp = window.gisApp;

//here using requestTimestamp to avoid repeated requesting, this variable will be shared in cross-page.
//window.localStorage.requestTimestamp;
//window.localStorage.realtimeData;

// map状态
gisApp.MAP_STATE = {
    INIT:0,
    REALTIME:1,
    TRACKER:2, //历史轨迹
    MEASUREMENT:3,
    EDIT:4,
    TRACING:5 //实时跟踪
};
// 图层状态
gisApp.CTRL_STATE = {
    CAR:0,
    CLUSTER:1,
    HEAPMAP:2,
    SPEED_HEAPMAP:3
};

gisApp.MapUtils = function(TOP_WINDOW, options){
    this.TOP_WINDOW = TOP_WINDOW;

    this.featureNS = options.featureNS;
    this.featurePrefix = options.featurePrefix;
    this.srsName = options.srsName;
    this.geometryName = options.geometryName;

    this.featureType = options.featureType;
    this.geometryType = options.geometryType;

    this.center = options.center;
    this.zoom = options.zoom;

    //地图HTML元素ID
    this.mapElementId = options.mapElementId;
    if(options.mapElementId == null)
        this.mapElementId = "map";

    this.map_bounds = options.map_bounds;
    this.projection = new ol.proj.Projection({
        code: this.srsName,
        units: 'degrees',
        axisOrientation: 'neu'
    });

    this.url = options.url;
    this.basemapurl = options.basemapurl;
    this.gispngurl = options.gispngurl;
    this.resolutions = options.resolutions;
    this.matrixIds = options.matrixIds;

    this.originX = options.originX;
    this.originY = options.originY;
    this.refreshInterval = options.refreshInterval;
    //实时状态下选中的feature; only work with layer_cars.
    this.hoveringFeature = null;
    this.terminalFilter = gisApp.FilterOptions;
    this.dataUpdatedEvent = null;
    this.selectInteraction = null;
    this.mapEvents = {};
    this.mapEventsHolder = {};
    //自定义交互对象，系统默认有8个交互对象；为了以示区分，将自定义事件置于collection中
    this.mapInteractions = new ol.Collection();
    this.mapInteractions.on("add",$.proxy(function(e){
        this.map.addInteraction(e.element);
    }),this);

    this.mapInteractions.on("remove",$.proxy(function(e){
        //pop() method will either trigger the removal event.
        if(e.element!=undefined && e.element!=null)
            this.map.removeInteraction(e.element);
    }),this);

    this.mapStatus = gisApp.MAP_STATE.INIT;
    //数据刷新函数
    this.dataRefreshFunction = null;

    // ##未选中时的样式
    this.style_unsel_func = (function() {
        return function(feature, resolution) {
            /*var styles;
            var src;
            var dir = feature.get('angle');
            var states = [];
            if(feature.get('stateText')!=null)
                states = feature.get('stateText').split(",");

            var suffix = ".png";
            if(this.map.getView().getZoom()>14)
                suffix = "_m.png";

            src = this.gispngurl + 'taxi_loaded' + suffix;

            switch (states[0]){
                case "离线":
                    src = this.gispngurl + 'taxi_offline' + suffix;
                    break;
                case "重车":
                    src = this.gispngurl + 'taxi_loaded' + suffix;
                    break;
                case "空车":
                    src = this.gispngurl + 'taxi_empty' + suffix;
                    break;
                case "电召":
                    src = this.gispngurl + 'taxi_assign' + suffix;
                    break;
                case "熄火":
                    src = this.gispngurl + 'taxi_off' + suffix;
                    break;
            }
            
            //if(dir<90) dir = dir-90;
            dir = (dir*2+90)*Math.PI/180.0;*/
            dir=0;
            var type = feature.get("type");
            var name = feature.get("name");
            var text = "";
            var status = feature.get("status");
            var fontColor = "";
            var src = "res/icons/building-"+ type +".gif";
            if(type==1){
                text = '站点:'+ name;
            }else if(type==2){
                text = '基站:' + name;
            }else if(type==3) {
                text = '设备:' + name;

                if (status == 0) {
                    fontColor = "#0ee40b";
                } else if (status == 1) {
                    fontColor = "#ff0000";
                } else if (status == 2) {
                    fontColor = "#ff00ff";
                } else if (status == 3) {
                    fontColor = "#e97a21";
                } else if (status == 4) {
                    fontColor = "#e6e614";
                }
            }

            styles = [new ol.style.Style({
                stroke: new ol.style.Stroke({
                    color: 'red',
                    width: 3
                }),
                text: new ol.style.Text({
                    font: '12px Calibri,sans-serif',
                    text: (this.map.getView().getZoom()<13) ? text : text,
                    offsetY: -10,
                    textAlign:'center',
                    fill: new ol.style.Fill({
                        color: fontColor
                    }),
                    stroke: new ol.style.Stroke({
                        color: feature.get("selected") ? '#ff0' : '#fff',
                        width: feature.get("selected") ? 4 : 2
                    })
                }),
                image: new ol.style.Icon({
                    src: src,
                    rotateWithView: false,
                    rotation: dir
                })
            })];

            return styles;
        };
    })();


    // ##选中时的样式
    this.style_sel_func = (function() {
        return function(feature, resolution) {
            var styles = this.style_unsel_func(feature,resolution);
            styles[0].getText().setFont("'16px Calibri,sans-serif'");
            styles[0].getText().getFill().setColor('#f00');
            styles[0].getText().getStroke().setColor("#ff0");
            styles[0].getText().getStroke().setWidth(5);
            return styles;
        };
    })();

    this.mousePositionControl = new ol.control.MousePosition({
        className: 'custom-mouse-position',
        target: document.getElementById('location'),
        coordinateFormat: ol.coordinate.createStringXY(8),
        undefinedHTML: '&nbsp;'
    });

    this.base_tiled_layer = gisApp.Common.BASELAYER_LOCAL_ARCGIS_TILE;

    //wmts图层，可以自定义坐标原点以纠正偏移；仅仅作为测试
    this.wmts_layer = new ol.layer.Tile({
        source: new ol.source.WMTS({
            url: this.basemapurl,
            layer: 'ArcGISCache',
            matrixSet: 'AZMap_ArcGISCache',
            format: 'image/png',
            opacity: 1,
            projection: 'EPSG:3857',
            tileGrid: new ol.tilegrid.WMTS({
                origin: [this.originX,this.originY],
                resolutions: this.resolutions,
                matrixIds: this.matrixIds
            }),
            style: 'default',
            wrapX: false
        })
    });

    //基础图层，替换base_tiled_alyer
    this.basic_layers = new ol.Collection();

    this.stations_lines_layer = null;

    this.source_cars = new ol.source.Vector({
        format: new ol.format.GeoJSON()
    });
    this.layer_cars = new ol.layer.Vector({
        visible: true,
        title: 'Cars',
        source: this.source_cars,
        zIndex:100,
        style: $.proxy(this.style_unsel_func, this)
    });
    this.map = new ol.Map({
        //interactions: ol.interaction.defaults().extend([sel_interaction]),
        controls: ol.control.defaults({
            attribution: false
        }).extend([
            this.mousePositionControl,
            new ol.control.FullScreen({
                tipLabel: '全屏显示'
            }),
            new ol.control.ScaleLine()
            // new ol.control.Zoom({
            //     zoomInTipLabel: '拉近',
            //     zoomOutTipLabel: '拉远'
            // })
            // new ol.control.ZoomSlider(),
            // new ol.control.ZoomToExtent({
            //     extent: this.map_bounds,
            //     label: '全',
            //     tipLabel: '显示全部地图'
            // })
        ]),
        target: this.mapElementId, //'map',
        //layers: [base_tiled_layer],
        view: new ol.View({
            projection: this.projection,
            center: this.center,
            zoom: this.zoom,
            maxZoom: this.matrixIds[this.matrixIds.length-1],
            minZoom: this.matrixIds[0]
        }),
        loadTilesWhileAnimating: true
    });

    //固定
    //this.map.on('moveend', this.adjustOrigin,this);

    this.map.getView().on('change:resolution',$.proxy(zoomHandler,this));

    function zoomHandler() {
        //var level = this.map.getView().getZoom();
        // console.log(this.map.getView().getZoom());
        // console.info(this.source_cars.getFeatures());
    }

    
    this.realtimeTracker = new gisApp.RealtimeTracker(this);
    this.measurement = new gisApp.Measurement(this);
    this.showTracker = new gisApp.ShowTracker(this);
    this.customCtrl = new gisApp.CustomCtrl(this);
    //this.controlPanel = new gisApp.ControlPanel(this);
    this.canvas = null;

    this.popup = null;

    // 画框查询
    this.extentSearchSource = null;
    this.extentSearchLayer = null;
    this.extentSearchInteraction = null;

    // 标注图层
    this.markFeatures = null;
    this.markVector = null;
    this.modifyInteraction = null;
    this.modifyDrawInteraction = null;
    this.markSelectAltClick = null;

    //this.map.addControl(new this.customCtrl.MeasureCtrl(this.customCtrl));
    this.map.addControl(new this.customCtrl.ClusterCtrl(this.customCtrl));
    this.map.addControl(new this.customCtrl.HeapmapCtrl(this.customCtrl));
    this.map.addControl(new this.customCtrl.SpeedHeapmapCtrl(this.customCtrl));
    this.map.addControl(new this.customCtrl.RealtimeTraceCtrl(this.customCtrl));
    //this.map.addControl(new this.customCtrl.InfoLabelCtrl(this.customCtrl));
    this.map.addControl(new this.customCtrl.TracePlayerCtrl(this.customCtrl));
    this.map.addControl(new this.customCtrl.LeftPanelCtrl(this.customCtrl));
    this.map.addControl(new this.customCtrl.RightPrimaryCtrl(this.customCtrl));
    this.map.addControl(new this.customCtrl.ToolbarCtrl(this.customCtrl));
    //this.map.addControl(new this.customCtrl.Statusbar(this.customCtrl));
    this.AttachClickEvent();
    // this.layerStations = new gisApp.LayerStations(this);
    // this.layerLines = new gisApp.LayerLines(this);
    // this.layerMarkers = new gisApp.LayerMarkers(this);
};

gisApp.MapUtils.prototype.InitMap = function(map_state,refresh_func) {
    this.Clear();
    this.map.getLayers().clear();


    var gcj02_arcgis_tile = gisApp.Common.BASELAYER_LOCAL_ARCGIS_TILE;
    //setting adjusted origin coordinates.gcj02 tiles transform to wgs84 CS.
    gcj02_arcgis_tile.getSource().tileGrid.origin_ = [options.originX, options.originY];
    this.basic_layers.push(gcj02_arcgis_tile);
    this.map.addLayer(gcj02_arcgis_tile);
    //this.map.addLayer(this.wmts_layer);
    this.canvas = new gisApp.Canvas(this);
    this.popup = new gisApp.Popup(this,
        {
            element: document.getElementById('popup')
        });
    //初始化控制面板
    //this.controlPanel.Initialize();
    this.switchMapStatus(map_state);
    //根据刷新间隔和函数指针刷新车辆位置信息等
    if(map_state == gisApp.MAP_STATE.REALTIME && refresh_func) {
        window.setInterval($.proxy(refresh_func,this), this.refreshInterval);
        this.dataRefreshFunction = refresh_func;
        this.RefreshImmediate();
        
        //window.localStorage.RealtimeDataRequested=true;
    }
    //右键菜单显示
    if(options.showContextMenu)
        this.customCtrl.InitializeContextMenu();

    this.source_cars.clear();
    this.map.updateSize();
};

gisApp.MapUtils.prototype.AttachClickEvent = function(){

/*    var ele = document.getElementById(this.mapElementId);
    ele.addEventListener("click",function(e) {
        //console.log("游戏开始！");
        var event = new Event("featureClicked");
        ele.dispatchEvent(event);

    });*/

    this.selectInteraction = new ol.interaction.Select({
        //style: $.proxy(that.style_sel_func, that),
        //layers: [this.layer_cars],
        condition: ol.events.condition.click
    });
    // 选择事件，获取信息
    this.selectInteraction.on('select', function (e) {
        if (e.selected.length > 0) {
            var ele = document.getElementById(this.mapElementId);
            var event = new Event("featureClicked");
            ele.dispatchEvent(event);

/*            var sel = e.selected[0];
            var name = sel.get('name');
            var id = sel.getId();*/
        }
    });
    this.mapInteractions.push(this.selectInteraction);
}
/*
* 图层控制（不存在则添加）
 */
gisApp.MapUtils.prototype.SetLayer = function(targetLayer,visible,index){
    var layer = null;
    if(visible==undefined) visible=true;

    this.map.getLayers().forEach(function(ele){
        if(ele==targetLayer) {
            layer = targetLayer;
            layer.setVisible(visible);

        }
    });

    if(layer===null) {
        this.map.addLayer(targetLayer);
    }

    if(index!=null)
        targetLayer.setZIndex(index);
};

gisApp.MapUtils.prototype.ReloadBaseMap = function(layerenum){

    // var arrfunc = layerenum.split(",");
    // this.map.removeLayer(mapUtils.base_tiled_layer);
    // mapUtils.base_tiled_layer = eval('gisApp.Common.' + layerenum);
    //
    //
    // if(layerenum == "BASELAYER_REMOTE_TDT"){
    //     mapUtils.base_tiled_layer = this.GetTdtLayer("cva_c");
    // }
    // //mapUtils.base_tiled_layer.setZIndex(-999);
    // this.map.addLayer(mapUtils.base_tiled_layer);

    while(lyr = mapUtils.basic_layers.pop()){
        this.map.removeLayer(lyr);
    }
    var arrfunc = layerenum.split(",");
    for(var i=0;i<arrfunc.length;i++){
        var lyr = eval('gisApp.Common.' + arrfunc[i]);
        lyr.setZIndex(i+1);
        this.map.addLayer(lyr);
        this.basic_layers.push(lyr);
    }


    mapUtils.base_tiled_layer.getSource().refresh();
};

//清除地图上的事件、交互及overlays图层
gisApp.MapUtils.prototype.Clear = function(){
    this.ClearInteraction();
    this.map.getOverlays().clear();
    if(this.showTracker.featureOverlay) this.showTracker.featureOverlay.getSource().clear();
    if(this.mapStatus == gisApp.MAP_STATE.REALTIME)
        this.popup.turnOn();
    //这里需调整，每次清除popup图层
    //this.map.addLayer(this.popup.popup);
    if(this.canvas!=null) this.canvas.Clear();
};


//清除地图上的交互及事件
gisApp.MapUtils.prototype.ClearInteraction = function(){
    for ( var event in this.mapEvents ){
        this.map.un(event,this.mapEvents[event],this.mapEventsHolder[event]);
        delete this.mapEvents[event];
        delete this.mapEventsHolder[event];
    }
    while(this.interaction = this.mapInteractions.pop())
        this.map.removeInteraction(this.interaction);
};

gisApp.MapUtils.prototype.AddBusStationLayer = function () {
    if (this.stations_lines_layer)
        this.map.removeLayer(this.stations_lines_layer);

    this.stations_lines_layer = new ol.layer.Tile({
        source: new ol.source.TileWMS({
            url: this.url,
            params: {
                'FORMAT': 'image/png',
                'VERSION': '1.3.0',
                tiled: true,
                LAYERS: this.featurePrefix+':stations_lines',
                filter: this.filterString
            }
        })
    });
    this.map.addLayer(this.stations_lines_layer);
};

//unused method
gisApp.MapUtils.prototype.UpdateFilter = function (arr) {
    if(arr.length == 0)
        filterString = '';
    else{
        filterString = '<Filter xmlns="'+ featureNS+ '>';
        for(x in arr){
            filterString += '<FeatureId fid="'+arr[x]+'"/>';
        }
        filterString += '</Filter>';
    }
    this.AddBusStationLayer();
};

gisApp.MapUtils.prototype.setWidth = function (size) {
    var mapDiv = document.getElementById('map');
    var wrapper = document.getElementById('wrapper');
    if (size == "auto") {
        // reset back to the default value
        mapDiv.style.width = null;
        wrapper.style.width = null;
    } else {
        mapDiv.style.width = size + "px";
        wrapper.style.width = size + "px";
    }
    // notify OL TOP_WINDOW we changed the size of the map div
    this.map.updateSize();
};

gisApp.MapUtils.prototype.setHeigh = function (size) {
    var mapDiv = document.getElementById('map');
    if (size == "auto") {
        // reset back to the default value
        mapDiv.style.height = null;
    } else {
        mapDiv.style.height = size + "px";
    }
    // notify OL TOP_WINDOW we changed the size of the map div
    this.map.updateSize();
};


/*  移动到指定点
*   @disPoint=ol.coordiate
 */
gisApp.MapUtils.prototype.panToPoint = function (desPoint, zoomlevel) {
    var view = this.map.getView();
    var pan = ol.animation.pan({
        duration: 500,
        source: view.getCenter()
    });
    var bounce = ol.animation.zoom({
        duration: 1000,
        resolution: view.getResolution()
    });
    this.map.beforeRender(pan, bounce);

    // //转换成墨卡托坐标
    // view.setCenter(ol.proj.transform(desPoint, 'EPSG:4326', 'EPSG:3857'));
    view.setCenter(desPoint);
    if(zoomlevel != undefined)
        view.setZoom(zoomlevel);
};

/**
 * 移动到指定geo对象的中心点（用于模态窗口中，不使用animation，不然显示时会导致底图的瓦片错开）
 * @param geo
 * @param zoomlevel
 */
gisApp.MapUtils.prototype.panToGeometry = function (geo, zoomlevel) {
    var view = this.map.getView();
    var extent = geo.getExtent();
    var x = extent[0] + (extent[2]-extent[0])/2;
    var y = extent[1] + (extent[3]-extent[1])/2;

    if(x>0&&y>0) {
        //view.animate({center:[x,y]},{zoom:16});
        view.setCenter([x,y]);
    }
    if(zoomlevel != undefined)
        view.setZoom(zoomlevel);
};

// 移动到指定点群
gisApp.MapUtils.prototype.panToPoints = function (desPoints) {
    var view = this.map.getView();
    var pan = ol.animation.pan({
        duration: 500,
        source: view.getCenter()
    });
    var bounce = ol.animation.zoom({
        duration: 1000,
        resolution: view.getResolution()
    });
    this.map.beforeRender(pan, bounce);
    view.fit(new ol.geom.MultiPoint(desPoints), this.map.getSize());
};

/**
 * 移动到指定线路
 * @param LineString [ol.geom.LineString| [ol.Coordiante]]
 */
gisApp.MapUtils.prototype.panToLine = function (LineString) {
    var view = this.map.getView();
    var pan = ol.animation.pan({
        duration: 500,
        source: view.getCenter()
    });
    var bounce = ol.animation.zoom({
        duration: 1000,
        resolution: view.getResolution()
    });
    this.map.beforeRender(pan, bounce);

    view.fit((LineString instanceof ol.geom.LineString) ? LineString : new ol.geom.LineString(LineString), this.map.getSize());
};

// 移动到多个线路
gisApp.MapUtils.prototype.panToLines = function (MultiLineString) {
    var view = this.map.getView();
    var pan = ol.animation.pan({
        duration: 500,
        source: view.getCenter()
    });
    var bounce = ol.animation.zoom({
        duration: 1000,
        resolution: view.getResolution()
    });
    this.map.beforeRender(pan, bounce);
    view.fit(new ol.geom.MultiLineString(MultiLineString), this.map.getSize());
};

gisApp.MapUtils.prototype.LocateFeature = function (fid){
    var feature = this.source_cars.getFeatureById(fid);
    if(feature){
        var coords = feature.getGeometry().getCoordinates();
        this.panToPoint(coords);
    }
};

/**
 * 动态调整地图原点坐标（将GCJ02坐标原点转换成WGS84坐标系）
 * @param evt
 */
gisApp.MapUtils.prototype.adjustOrigin = function (evt) {
    // function wrapLon(value) {
    //     var worlds = Math.floor((value + 180) / 360);
    //     return value - (worlds * 360);
    // }
    // var map = evt.map;
    // var extent = map.getView().calculateExtent(map.getSize());
    var center = evt.map.getView().getCenter();

    //将中心点坐标转换成gcj02坐标，然后计算偏移距离（偏移距离是动态的，不同城市不同位置偏移的距离不一致）
    var gcj = coordtransform.wgs84togcj02(center[0],center[1]);
    var offset_x = gisApp.TopoAlgorithm.PathLength([[center[0], center[1]],[gcj[0], center[1]]]);
    var offset_y = gisApp.TopoAlgorithm.PathLength([[center[0], center[1]],[center[0], gcj[1]]]);
    gisApp.Common.BASELAYER_LOCAL_ARCGIS_TILE.getSource().tileGrid.origin_ = [options.originX - offset_x, options.originY + offset_y];
    gisApp.Common.BASELAYER_LOCAL_ARCGIS_GOOGLE_TILE.getSource().tileGrid.origin_ = [options.originX - offset_x, options.originY + offset_y];
    
    //console.info(offset_x + "," + offset_y);
    gisApp.Common.BASELAYER_LOCAL_ARCGIS_TILE.getSource().refresh();
    
    var bd = coordtransform.gcj02tobd09(gcj[0],gcj[1]);
    var bd_offset_x = gisApp.TopoAlgorithm.PathLength([[center[0], center[1]],[bd[0], center[1]]]);
    var bd_offset_y = gisApp.TopoAlgorithm.PathLength([[center[0], center[1]],[center[0], bd[1]]]);
    console.info(bd_offset_x + "," + bd_offset_y);
    gisApp.Common.BASELAYER_REMOTE_BAIDU.getSource().tileGrid.origin_ = [-bd_offset_x-250,15800+bd_offset_y];
    gisApp.Common.TRAFFICFLOW_REMOTE_BD.getSource().tileGrid.origin_ = [-bd_offset_x-250,15800+bd_offset_y];

    // var bottomLeft = ol.proj.transform(ol.extent.getBottomLeft(extent), 'EPSG:4326', 'EPSG:4326');
    // var topRight = ol.proj.transform(ol.extent.getTopRight(extent), 'EPSG:4326', 'EPSG:4326');
    //document.getElementById('scale').innerHTML = "当前视图范围:" + wrapLon(bottomLeft[0]) + "," + bottomLeft[1] + ";" + wrapLon(topRight[0]) + "," + topRight[1];
};

/*  layer_cars 要素是否符合查询条件，包含空间过滤，符合返回true
 *  可以直接使用layers_cars.getFeatures取得所有符合条件的记录
 */
gisApp.MapUtils.prototype.Filtering = function(feature){
    var retval = true;
    if(!this.terminalFilter) return true;
    //feature属性作为查询条件
    if(this.terminalFilter.Filters != null){
        var arr = this.terminalFilter.Filters;

        var last_logic_exp = null;
        var last_pass = true;
        var state_pass = undefined;

        for(var i=0;i<arr.length;i++){
            var prop = arr[i].PropertyName;
            var pass;

            if(prop!=""){
                //所有的状态都作特殊处理
                if(prop=="stateText"){
                    if(feature.get("stateText"))
                        state_pass = state_pass || feature.get("stateText").indexOf(arr[i].Expression)>-1;
                }
                else {
                    if (arr[i].RelationExpression == gisApp.RELATION_EXPRESSION.Like)
                        pass = eval("feature.getProperties()." + prop + ".indexOf(arr[i].Expression)>-1");
                    else
                        pass = eval("feature.getProperties()." + prop + arr[i].RelationExpression + "arr[i].Expression");

                    if(last_logic_exp!=null){
                        if(last_logic_exp == gisApp.LOGICAL_OPERATOR.And)
                            retval = last_pass && pass;
                        if(last_logic_exp == gisApp.LOGICAL_OPERATOR.Or)
                            retval = last_pass || pass;
                    }
                    else{
                        retval = pass;
                    }
                    last_pass = pass;
                    last_logic_exp = arr[i].LogicalOperator;
                }

            }
        }

        if(state_pass!=undefined) retval = retval && state_pass;
    } //feature 运算结束

    // 空间比较运算
    if(this.terminalFilter.Geometry!=null && retval){
        //空间拓扑关系运算
        if(this.terminalFilter.SpatialOperator == gisApp.SPATIAL_OPERATOR.WithIn)
            retval = retval && gisApp.TopoAlgorithm.Covers(this.terminalFilter.Geometry,feature.getGeometry());
    }

    return retval;
};

//refresh map immediately according to terminalFilter property.
gisApp.MapUtils.prototype.RefreshImmediate = function(){
    //this.map_state == gisApp.MAP_STATE.REALTIME &&
    if(this.dataRefreshFunction) {
        //unkown reason that the $.proxy just only work with 'setTimeout' method.
        window.setTimeout($.proxy(this.dataRefreshFunction,this));
    }
};

/** 根据过滤器更新车辆feature
** @val=[ol.Feature|string(json)]
 */
gisApp.MapUtils.prototype.RefreshCarData = function (val) {
    var f = (val instanceof ol.Feature) ? val : (new ol.format.GeoJSON()).readFeature(val);
    var feature = this.source_cars.getFeatureById(f.getId());
    var weight;

    //不符合过滤条件则不显示
    if(this.Filtering(f)==false) {
        if(feature)
            this.source_cars.removeFeature(feature);
        return;
    }

    if(this.customCtrl.ctrlState == gisApp.CTRL_STATE.SPEED_HEAPMAP)
        weight = parseInt(f.get('speed'),10)/40.0;
    else
        weight = 1;

    // 修改坐标会导致ZOOM IN时要素丢失的现象，未找到原因
    // if(feature) {
    //     feature.setProperties(f.getProperties(),true);
    //     feature.setGeometry(f.getGeometry());
    //     feature.set('weight', weight);
    // }
    // else{
    //     f.set('weight', weight);
    //     this.source_cars.addFeature(f);
    // }
    if(feature)
        this.source_cars.removeFeature(feature);
    this.source_cars.addFeature(f);
    if(this.mapStatus == gisApp.MAP_STATE.TRACING){
        this.realtimeTracker.AppendTraceData(f);
    }
};

gisApp.MapUtils.prototype.switchMapStatus = function(status){
    //if(this.mapStatus == status) return;
    this.mapStatus = status;

    switch(status){
        case gisApp.MAP_STATE.REALTIME:
            this.SetLayer(this.layer_cars);



            this.popup.turnOn();
            break;
        case gisApp.MAP_STATE.MEASUREMENT:
            this.measurement.turnOn();
            break;
        case gisApp.MAP_STATE.TRACKER:
            this.showTracker.turnOn();
            break;
        case gisApp.MAP_STATE.TRACING:
            this.realtimeTracker.turnOn();
            break;
        default:
            this.SetLayer(this.layer_cars);
            break;
    }
    this.customCtrl.refreshCtrl(this);
};

// 画框查询
gisApp.MapUtils.prototype.switchExtentSearchStatus = function(status, func) {
    if(status){
        this.extentSearchSource = new ol.source.Vector({wrapX: false});
        this.extentSearchLayer = new ol.layer.Vector({
            source: this.extentSearchSource,
            style: new ol.style.Style({
                fill: new ol.style.Fill({
                    color: 'rgba(230, 210, 255, 0.2)'
                }),
                stroke: new ol.style.Stroke({
                    color: '#cc33ff',
                    width: 2
                }),
                image: new ol.style.Circle({
                    radius: 7,
                    fill: new ol.style.Fill({
                        color: '#cc33ff'
                    })
                })
            })
        });
        this.map.addLayer(this.extentSearchLayer);

        this.extentSearchInteraction = new ol.interaction.Draw({
            source: this.extentSearchSource,
            type: 'LineString',
            geometryFunction: function(coordinates, geometry) {
                if (!geometry) {
                    geometry = new ol.geom.Polygon(null);
                }
                var start = coordinates[0];
                var end = coordinates[1];
                geometry.setCoordinates([
                    [start, [start[0], end[1]], end, [end[0], start[1]], start]
                ]);
                return geometry;
            },
            maxPoints: 2
        });
        this.extentSearchInteraction.on('drawend', func);
        this.map.addInteraction(this.extentSearchInteraction);
    }
    else {
        this.map.removeInteraction(this.extentSearchInteraction);
        this.map.removeLayer(this.extentSearchLayer);
        this.extentSearchSource.clear();
    }
};