{
  "code": 0
  ,"msg": ""
  ,"data": {
    "username": "大神"
    ,"sex": "男"
    ,"role": 1
  }
}