{
  "code": 0
  ,"msg": ""
  ,"count": 60
  ,"data": [{
    "id": 123
    ,"title": "10001"
    ,"date": 1510363800000
    ,"viewNum":"6"
    ,"status":"在职"
    ,"location":"前端"
    ,"platform":"研发部"
  }, {
    "id": 111
    ,"title": "10002"
    ,"date": 1510212370000
    ,"viewNum":"50"
    ,"status":"在职"
    ,"location":"后端"
    ,"platform":"研发部"
  }, {
    "id": 111
    ,"title": "10003"
    ,"date": 1510212370000
    ,"viewNum":"0"
    ,"status":"在职"
    ,"location":"移动端"
    ,"platform":"研发部"
  }, {
    "id": 111
    ,"title": "10004"
    ,"date": 1510212370000
    ,"viewNum":"999"
    ,"status":"离职"
    ,"location":"产品经理"
    ,"platform":"产品部"
  }, {
    "id": 111
    ,"title": "10005"
    ,"date": 1510212370000
    ,"viewNum":"0"
    ,"status":"离职"
    ,"location":"运营"
    ,"platform":"市场部"
  }, {
    "id": 111
    ,"title": "10006"
    ,"date": 1510212370000
    ,"viewNum":"999"
    ,"status":"在职"
    ,"location":"客服"
    ,"platform":"客服部"
  }, {
    "id": 111
    ,"title": "10007"
    ,"date": 1510212370000
    ,"viewNum":"50"
    ,"status":"在职"
    ,"location":"销售"
    ,"platform":"市场部"
  }, {
    "id": 111
    ,"title": "10008"
    ,"date": 1510212370000
    ,"viewNum":"0"
    ,"status":"离职"
    ,"location":"测试"
    ,"platform":"安全中心"
  }, {
    "id": 111
    ,"title": "10009"
    ,"date": 1510212370000
    ,"viewNum":"50"
    ,"status":"离职"
    ,"location":"设计"
    ,"platform":"设计部"
  }, {
    "id": 111
    ,"title": "10010"
    ,"date": 1507447570000
    ,"viewNum":"6"
    ,"status":"在职"
    ,"location":"产品经理"
    ,"platform":"产品部"
  }]
}