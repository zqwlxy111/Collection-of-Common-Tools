{
    "title": "城市下拉数据"
    ,"data": [
    {
        "location": "郑州"
    }
    ,{
        "location": "开封"
    }
    ,{
        "location": "南阳"
    }
    ,{
        "location": "海南"
    }
    ,{
        "location": "东海"
    }
]
}
