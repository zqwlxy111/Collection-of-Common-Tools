{
  "code": 0
  ,"msg": ""
  ,"count": 60
  ,"data": [{
    "id": 123
    ,"title":"标题"
    ,"platform":"公众号"
    ,"type":"热门"
    ,"createTime": 1510361800000
    ,"status":true
  },{
    "id": 123
    ,"title":"标题"
    ,"platform":"微信"
    ,"type":"推荐"
    ,"createTime": 1510361800000
    ,"status":true
},{
    "id": 123
    ,"title":"标题"
    ,"platform":"pc"
    ,"type":"普通"
    ,"createTime": 1510361800000
    ,"status":true
},{
    "id": 123
    ,"title":"标题"
    ,"platform":"web"
    ,"type":"节气"
    ,"createTime": 1510361800000
    ,"status":true
},{
    "id": 123
    ,"title":"标题"
    ,"platform":"小程序"
    ,"type":"体育"
    ,"createTime": 1510361800000
    ,"status":true
},{
    "id": 123
    ,"title":"标题"
    ,"platform":"公众号"
    ,"type":"很好"
    ,"createTime": 1510361800000
    ,"status":true
},{
    "id": 123
    ,"title":"标题"
    ,"platform":"公众号"
    ,"type":"很好"
    ,"createTime": 1510361800000
    ,"status":true
}]
}