{
  "code": 0
  ,"msg": ""
  ,"count": 60
  ,"data": [{
    "id": 123
    ,"title": "春天，你好"
    ,"thumbnail":"http://cdn.zhmf.com//Upload/images/20170525/2746a177-e06d-4c7a-a9b2-c1a5194084ff.jpg"
    ,"platform":"智汇魔方"
    ,"type":"普通海报"
    ,"label":"节气"
    ,"hot":"666"
    ,"createTime": 1510361800000
    ,"startTime": 1510361800000
    ,"status":true
  },{
    "id": 124
    ,"title": "大圣归来"
    ,"thumbnail":"http://cdn.zhmf.com//Upload/images/20170525/2746a177-e06d-4c7a-a9b2-c1a5194084ff.jpg"
    ,"platform":"汇贷客"
    ,"type":"热门"
    ,"label":"英雄"
    ,"hot":"999"
    ,"createTime": 1510353800000
    ,"startTime": 1510361800000
    ,"status":true
},{
    "id": 125
    ,"title": "送子观音"
    ,"thumbnail":"http://cdn.zhmf.com//Upload/images/20170525/2746a177-e06d-4c7a-a9b2-c1a5194084ff.jpg"
    ,"platform":"公众号"
    ,"type":"推荐"
    ,"label":"喜庆"
    ,"hot":"796"
    ,"createTime": 1510363700000
    ,"startTime": 1510363700000
    ,"status":true
},{
    "id": 126
    ,"title": "钢铁侠"
    ,"thumbnail":"http://cdn.zhmf.com//Upload/images/20170525/2746a177-e06d-4c7a-a9b2-c1a5194084ff.jpg"
    ,"platform":"web"
    ,"type":"普通海报"
    ,"label":"英雄"
    ,"hot":"888"
    ,"createTime": 1510362800000
    ,"startTime": 1510363700000
    ,"status":false
},{
    "id": 127
    ,"title": "泡妞许可证"
    ,"thumbnail":"http://cdn.zhmf.com//Upload/images/20170525/2746a177-e06d-4c7a-a9b2-c1a5194084ff.jpg"
    ,"platform":"pc"
    ,"type":"普通海报"
    ,"label":"魅力"
    ,"hot":"222"
    ,"createTime": 1510363400000
    ,"startTime": 1510363700000
    ,"status":true
},{
    "id": 128
    ,"title": "青春不散"
    ,"thumbnail":"http://cdn.zhmf.com//Upload/images/20170525/2746a177-e06d-4c7a-a9b2-c1a5194084ff.jpg"
    ,"platform":"微信"
    ,"type":"普通海报"
    ,"label":"青春"
    ,"hot":"666"
    ,"createTime": 1510363600000
    ,"startTime":  1510363700000
    ,"status":true
},{
    "id": 129
    ,"title": "早安"
    ,"thumbnail":"http://cdn.zhmf.com//Upload/images/20170525/2746a177-e06d-4c7a-a9b2-c1a5194084ff.jpg"
    ,"platform":"智汇魔方"
    ,"type":"Diy海报"
    ,"label":"问候"
    ,"hot":"999"
    ,"createTime": 1510363700000
    ,"startTime": 1510363700000
    ,"status":true
}]
}