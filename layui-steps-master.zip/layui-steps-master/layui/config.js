layui.config({
    version: 222222
    ,debug: true
    ,base: 'layui/extend/'
}).extend({
    steps:"steps/steps"
});


