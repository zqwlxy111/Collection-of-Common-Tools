# layui-steps
layui-steps 是一个 LayUI 实现的步骤条模板，可以切换步骤，跳转到指定步骤

<img src="https://img-blog.csdnimg.cn/20190410092802823.gif">
